package qqid

import (
	"context"
	"errors"
	"github.com/redis/go-redis/v9"
	"github.com/zeromicro/go-zero/core/logx"
	"strconv"
	"strings"
	"sync"
	"time"
)

var _client redis.UniversalClient
var _ctx = context.Background()
var _workerIdLock sync.Mutex

var _workerIdList []int32
var _loopCount int32 = 0
var _lifeIndex int32 = -1
var _token int32 = -1

var _WorkerIdLifeTimeSeconds int32 = 15
var _MaxLoopCount int32 = 20
var _SleepMillisecondEveryLoop int32 = 200
var _MaxWorkerId int32 = 0
var _MinWorkerId int32 = 0

var _RedisConnString = ""
var _RedisPassword = ""
var _RedisDB int = 0
var _RedisMasterName = ""

var _WorkerIdIndexKey = "Op:QqId:WorkerId:Index"
var _WorkerIdValueKeyPrefix = "Op:QqId:WorkerId:Value"
var _WorkerIdFlag = "Y"
var _Log = false

type RegisterConf struct {
	Address         string
	Password        string
	DB              int
	MasterName      string
	MaxWorkerId     int32
	MinWorkerId     int32
	TotalCount      int32
	LifeTimeSeconds int32
}

func Validate(workerId int32) int32 {
	for _, value := range _workerIdList {
		if value == workerId {
			return 1
		}
	}
	return 0
}

func UnRegister() {
	_client = newRedisClient()
	if _client == nil {
		return
	}
	defer func() {
		if _client != nil {
			_ = _client.Close()
		}
	}()

	myUnRegister()
}

func myUnRegister() {
	_workerIdLock.Lock()
	_lifeIndex = -1
	for _, value := range _workerIdList {
		if value > -1 {
			_client.Del(_ctx, _WorkerIdValueKeyPrefix+strconv.Itoa(int(value)))
		}
	}
	_workerIdList = []int32{}
	_workerIdLock.Unlock()
}

func autoUnRegister() {
	if len(_workerIdList) > 0 {
		myUnRegister()
	}
}

func RegisterMany(conf RegisterConf) []int32 {
	if conf.MaxWorkerId < 0 || conf.MinWorkerId > conf.MaxWorkerId {
		return []int32{-2}
	}

	if conf.TotalCount < 1 {
		return []int32{-1}
	} else if conf.TotalCount == 0 {
		conf.TotalCount = 1
	}
	_MaxWorkerId = conf.MaxWorkerId
	_MinWorkerId = conf.MinWorkerId

	_RedisConnString = conf.Address
	_RedisPassword = conf.Password
	_RedisDB = conf.DB
	_RedisMasterName = conf.MasterName
	_WorkerIdLifeTimeSeconds = conf.LifeTimeSeconds

	_client = newRedisClient()
	if _client == nil {
		return []int32{-1}
	}
	defer func() {
		if _client != nil {
			_ = _client.Close()
		}
	}()

	autoUnRegister()

	_lifeIndex++

	_workerIdList = make([]int32, conf.TotalCount)

	for key := range _workerIdList {
		_workerIdList[key] = -1
	}

	useExtendFunc := false

	for key := range _workerIdList {
		id := register(_lifeIndex)
		if id > -1 {
			useExtendFunc = true
			_workerIdList[key] = id
		} else {
			break
		}
	}
	if useExtendFunc {
		go extendLifeTime(_lifeIndex)
	}
	return _workerIdList

}

func RegisterOne(conf RegisterConf) int32 {
	if conf.MaxWorkerId < 0 || conf.MinWorkerId > conf.MaxWorkerId {
		return -2
	}
	_MaxWorkerId = conf.MaxWorkerId
	_MinWorkerId = conf.MinWorkerId
	_RedisConnString = conf.Address
	_RedisPassword = conf.Password
	_RedisDB = conf.DB
	_RedisMasterName = conf.MasterName
	_WorkerIdLifeTimeSeconds = conf.LifeTimeSeconds
	_loopCount = 0

	_client = newRedisClient()
	if _client == nil {
		return -3
	}

	defer func() {
		if _client != nil {
			_ = _client.Close()
		}
	}()

	autoUnRegister()
	_lifeIndex++
	var id = register(_lifeIndex)
	if id > -1 {
		_workerIdList = []int32{id}
		go extendLifeTime(_lifeIndex)
	}
	return id
}

func extendLifeTime(lifeIndex int32) {
	var myLifeIndex = lifeIndex
	for {
		time.Sleep(time.Duration(_WorkerIdLifeTimeSeconds/3) * time.Second)
		_workerIdLock.Lock()
		if myLifeIndex != _lifeIndex {
			break
		}
		if len(_workerIdList) < 1 {
			break
		}
		for _, value := range _workerIdList {
			if value > -1 {
				extendWorkerIdFlag(value)
			}
		}
		_workerIdLock.Unlock()
	}

}

func extendWorkerIdFlag(workerId int32) {
	var client = newRedisClient()
	if client == nil {
		return
	}
	defer func() {
		if client != nil {
			_ = client.Close()
		}
	}()
	client.Expire(_ctx, _WorkerIdValueKeyPrefix+strconv.Itoa(int(workerId)), time.Duration(_WorkerIdLifeTimeSeconds)*time.Second)
}

func newRedisClient() redis.UniversalClient {
	client := redis.NewUniversalClient(&redis.UniversalOptions{
		Addrs:      strings.Split(_RedisConnString, ","),
		Password:   _RedisPassword,
		DB:         _RedisDB,
		MasterName: _RedisMasterName,
		//PoolSize:        1000,
		//ReadTimeout:     time.Millisecond * time.Duration(100),
		//WriteTimeout:    time.Millisecond * time.Duration(100),
		//MinIdleConns:    100,
		//MaxIdleConns:    200,
		//MaxActiveConns:  1000,
		//ConnMaxIdleTime: time.Second * time.Duration(60),
	})
	return client
}

func register(lifeTime int32) int32 {
	_loopCount = 0
	return getNextWorkerId(lifeTime)
}

func getNextWorkerId(lifeTime int32) int32 {
	r, err := _client.Incr(_ctx, _WorkerIdIndexKey).Result()
	if err != nil {
		return -1
	}

	candidateId := int32(r)
	if candidateId < _MinWorkerId {
		candidateId = _MinWorkerId
		setWorkerIdIndex(_MinWorkerId)
	}

	if _Log {
		logx.Infof("Begin candidateId: %s\n", strconv.Itoa(int(candidateId)))
	}

	if candidateId > _MaxWorkerId {
		if canReset() {
			setWorkerIdIndex(_MinWorkerId - 1)
			endReset()
			_loopCount++

			if _loopCount > _MaxLoopCount {
				_loopCount = 0
				return -1
			}
			time.Sleep(time.Duration(_SleepMillisecondEveryLoop*_loopCount) * time.Millisecond)
			if _Log {
				logx.Info("canReset loop")
			}
			return getNextWorkerId(lifeTime)
		} else {
			time.Sleep(time.Duration(200) * time.Millisecond)
			if _Log {
				logx.Info("not canReset loop")
			}
			return getNextWorkerId(lifeTime)
		}
	}
	if _Log {
		logx.Infof("candidateId: %s\n", strconv.Itoa(int(candidateId)))
	}

	if isAvailable(candidateId) {
		if _Log {
			logx.Infof("AA: isAvailable: %s\n", strconv.Itoa(int(candidateId)))
		}
		setWorkerIdFlag(candidateId)
		_loopCount = 0
		return candidateId
	} else {
		if _Log {
			logx.Infof("BB: not isAvailable:", strconv.Itoa(int(candidateId)))
		}
		return getNextWorkerId(lifeTime)
	}
}

func setWorkerIdFlag(workerId int32) {
	_client.Set(_ctx, _WorkerIdValueKeyPrefix+strconv.Itoa(int(workerId)), _WorkerIdFlag, time.Duration(_WorkerIdLifeTimeSeconds)*time.Second)
}

func isAvailable(workerId int32) bool {
	r, err := _client.Get(_ctx, _WorkerIdValueKeyPrefix+strconv.Itoa(int(workerId))).Result()
	if _Log {
		logx.Infof("XX isAvailable: %s\n", r)
		logx.Infof("YY isAvailable: %s\n", err.Error())
	}
	if err != nil {
		if errors.Is(err, redis.Nil) {
			return true
		}
		return false
	}
	return r != _WorkerIdFlag
}

func endReset() {
	_client.Set(_ctx, _WorkerIdValueKeyPrefix+"Edit", 0, 0)
}

func setWorkerIdIndex(val int32) {
	_client.Set(_ctx, _WorkerIdIndexKey, val, 0)
}

func canReset() bool {
	r, err := _client.Incr(_ctx, _WorkerIdValueKeyPrefix+"Edit").Result()
	if err != nil {
		return false
	}
	if _Log {
		logx.Infof("canReset: %s", strconv.Itoa(int(r)))
	}
	return r != 1
}
