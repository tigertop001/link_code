package qqid

type IdGeneratorOptions struct {
	Method            uint16
	BaseTime          int64
	WorkerId          uint16
	WorkerIdBitLength byte
	SeqBitLength      byte
	MaxSeqNumber      uint32
	MinSeqNumber      uint32
	TopOverCostCount  uint32
}

func NewIdGeneratorOptions(workerId uint16) *IdGeneratorOptions {
	return &IdGeneratorOptions{
		Method:            1,
		WorkerId:          workerId,
		BaseTime:          1582136402000,
		WorkerIdBitLength: 6,
		SeqBitLength:      6,
		MaxSeqNumber:      0,
		MinSeqNumber:      5,
		TopOverCostCount:  2000,
	}
}
