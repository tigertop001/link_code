package qqid

import (
	"sync"
	"time"
)

var singletonMutex sync.Mutex
var idGenerator *DefaultIdGenerator

func SetIdGenerator(options *IdGeneratorOptions) {
	singletonMutex.Lock()
	idGenerator = NewDefaultIdGenerator(options)
	singletonMutex.Unlock()
}

func NextId() int64 {
	if idGenerator == nil {
		panic("Please initialize Yitter.IdGeneratorOptions first.")
	}
	return idGenerator.NewLong()
}
func ExtractTime(id int64) time.Time {
	return idGenerator.ExtractTime(id)
}
