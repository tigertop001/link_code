package qqid

type ISnowWorker interface {
	NextId() int64
}
