package config

import (
	"github.com/zeromicro/go-zero/zrpc"
)

type Config struct {
	zrpc.RpcServerConf
	IdRedis struct {
		Address         string
		Password        string
		MasterName      string
		DB              int
		MaxWorkerId     int32
		MinWorkerId     int32
		LifeTimeSeconds int32
	}
}
