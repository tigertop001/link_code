package svc

import (
	"operation-qq-id-domain/operation-qq-id-rpc/internal/config"
	"operation-qq-id-domain/operation-qq-id-rpc/internal/qqid"
	"time"
)

type ServiceContext struct {
	Config config.Config
	//QqIdGen *qqid.DefaultIdGenerator
}

func NewServiceContext(c config.Config) *ServiceContext {

	conf := qqid.RegisterConf{
		Address:         c.IdRedis.Address,
		Password:        c.IdRedis.Password,
		DB:              c.IdRedis.DB,
		MasterName:      c.IdRedis.MasterName,
		MaxWorkerId:     c.IdRedis.MaxWorkerId,
		MinWorkerId:     c.IdRedis.MinWorkerId,
		LifeTimeSeconds: c.IdRedis.LifeTimeSeconds,
	}
	workId := qqid.RegisterOne(conf)
	var options = qqid.NewIdGeneratorOptions(uint16(workId))
	options.WorkerIdBitLength = 6
	options.SeqBitLength = 10
	options.BaseTime = time.Date(2020, 2, 20, 2, 20, 2, 20, time.UTC).UnixNano() / 1e6
	qqid.SetIdGenerator(options)

	return &ServiceContext{
		Config: c,
		//QqIdGen: qqIdGen,
	}
}
