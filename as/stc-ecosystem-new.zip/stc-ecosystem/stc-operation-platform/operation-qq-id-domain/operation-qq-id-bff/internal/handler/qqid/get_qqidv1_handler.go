package qqid

import (
	"net/http"

	"github.com/zeromicro/go-zero/rest/httpx"
	"operation-qq-id-domain/operation-qq-id-bff/internal/logic/qqid"
	"operation-qq-id-domain/operation-qq-id-bff/internal/svc"
	"operation-qq-id-domain/operation-qq-id-bff/internal/types"
)

func GetQqidv1Handler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.Empty
		if err := httpx.Parse(r, &req); err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
			return
		}

		l := qqid.NewGetQqidv1Logic(r.Context(), svcCtx)
		resp, err := l.GetQqidv1(&req)
		if err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
