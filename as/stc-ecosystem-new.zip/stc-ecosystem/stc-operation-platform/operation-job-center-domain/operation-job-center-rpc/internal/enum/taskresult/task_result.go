package taskresult

const (
	Success uint8 = 1 + iota
	Failed
)
