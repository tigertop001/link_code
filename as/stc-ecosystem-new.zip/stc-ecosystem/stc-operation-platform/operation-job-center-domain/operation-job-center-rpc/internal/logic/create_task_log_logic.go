package logic

import (
	"context"

	"operation-job-center-domain/operation-job-center-rpc/internal/svc"
	"operation-job-center-domain/operation-job-center-rpc/jobcenter"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateTaskLogLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateTaskLogLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateTaskLogLogic {
	return &CreateTaskLogLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *CreateTaskLogLogic) CreateTaskLog(in *jobcenter.TaskLogInfo) (*jobcenter.BaseIDResp, error) {

	return &jobcenter.BaseIDResp{}, nil
}
