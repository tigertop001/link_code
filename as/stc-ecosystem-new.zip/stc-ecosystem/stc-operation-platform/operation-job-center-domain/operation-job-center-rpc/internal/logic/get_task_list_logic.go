package logic

import (
	"context"

	"operation-job-center-domain/operation-job-center-rpc/internal/svc"
	"operation-job-center-domain/operation-job-center-rpc/jobcenter"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetTaskListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetTaskListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetTaskListLogic {
	return &GetTaskListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *GetTaskListLogic) GetTaskList(in *jobcenter.TaskListReq) (*jobcenter.TaskListResp, error) {
	// todo: add your logic here and delete this line

	return &jobcenter.TaskListResp{}, nil
}
