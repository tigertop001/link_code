package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"operation-job-center-domain/operation-job-center-rpc/internal/model"
	"operation-job-center-domain/operation-job-center-rpc/internal/query"

	"operation-job-center-domain/operation-job-center-rpc/internal/svc"
	"operation-job-center-domain/operation-job-center-rpc/jobcenter"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateTaskLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateTaskLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateTaskLogic {
	return &CreateTaskLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *CreateTaskLogic) CreateTask(in *jobcenter.TaskInfo) (*jobcenter.BaseIDResp, error) {
	// TODO 输入值校验
	statusN := new(int32)
	*statusN = int32(*in.Status)
	sysTaskPo := &model.SysTask{
		Status:         statusN,
		Name:           *in.Name,
		TaskGroup:      *in.TaskGroup,
		CronExpression: *in.CronExpression,
		Pattern:        *in.Pattern,
		Payload:        *in.Payload,
	}
	sysTaskRepo := query.SysTask
	err := sysTaskRepo.WithContext(l.ctx).Create(sysTaskPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &jobcenter.BaseIDResp{
		Id:  uint64(sysTaskPo.ID),
		Msg: admini18nconst.CreateSuccess,
	}, nil
}
