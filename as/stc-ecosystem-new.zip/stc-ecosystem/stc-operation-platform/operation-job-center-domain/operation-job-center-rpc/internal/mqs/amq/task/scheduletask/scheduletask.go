package scheduletask

import (
	"fmt"
	"log"
	"operation-job-center-domain/operation-job-center-rpc/internal/svc"
)

type SchedulerTask struct {
	svcCtx *svc.ServiceContext
}

func NewSchedulerTask(svcCtx *svc.ServiceContext) *SchedulerTask {
	return &SchedulerTask{
		svcCtx: svcCtx,
	}
}

func (s *SchedulerTask) Start() {
	s.Register()
	if err := s.svcCtx.AsynqScheduler.Run(); err != nil {
		log.Fatal(fmt.Errorf("failed to start mqtask server, error: %v", err))
	}
}

func (s *SchedulerTask) Stop() {
	s.svcCtx.AsynqScheduler.Shutdown()
}
