package mqtask

import (
	"fmt"
	"github.com/hibiken/asynq"
	"log"
	"operation-job-center-domain/operation-job-center-rpc/internal/svc"
	"time"
)

type MQTask struct {
	svcCtx *svc.ServiceContext
	mux    *asynq.ServeMux
}

func NewMQTask(svcCtx *svc.ServiceContext) *MQTask {
	return &MQTask{
		svcCtx: svcCtx,
	}
}

func (m *MQTask) Start() {
	m.Register()
	if err := m.svcCtx.AsynqServer.Run(m.mux); err != nil {
		log.Fatal(fmt.Errorf("failed to start mqtask server, error: %v", err))
	}
}

func (m *MQTask) Stop() {
	time.Sleep(5 * time.Second)
	m.svcCtx.AsynqServer.Stop()
	m.svcCtx.AsynqServer.Shutdown()
}
