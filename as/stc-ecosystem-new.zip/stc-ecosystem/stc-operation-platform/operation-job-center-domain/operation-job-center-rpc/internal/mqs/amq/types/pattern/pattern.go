package pattern

const RecordHelloWorld = "hello_world"
