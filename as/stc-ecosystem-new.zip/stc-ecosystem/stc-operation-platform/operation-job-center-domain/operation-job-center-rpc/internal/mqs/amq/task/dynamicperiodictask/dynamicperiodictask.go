package dynamicperiodictask

import (
	"fmt"
	"log"
	"operation-job-center-domain/operation-job-center-rpc/internal/svc"
)

type DPTask struct {
	svcCtx *svc.ServiceContext
}

func NewDPTask(svcCtx *svc.ServiceContext) *DPTask {
	return &DPTask{
		svcCtx: svcCtx,
	}
}

func (d *DPTask) Start() {
	if err := d.svcCtx.AsynqPTM.Run(); err != nil {
		log.Fatal(fmt.Errorf("failed to start dptask server, error: %v", err))
	}
}

func (d *DPTask) Stop() {
	defer func() {
		if recover() != nil {
			log.Println("DPTask shuts down successfully")
		}
	}()
	d.svcCtx.AsynqPTM.Shutdown()
}
