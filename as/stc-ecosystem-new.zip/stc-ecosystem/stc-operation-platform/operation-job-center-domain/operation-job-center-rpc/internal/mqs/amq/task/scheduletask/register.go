package scheduletask

import (
	"github.com/hibiken/asynq"
	"operation-job-center-domain/operation-job-center-rpc/internal/mqs/amq/types/pattern"
)

func (s *SchedulerTask) Register() {
	s.svcCtx.AsynqScheduler.Register("@every 5s", asynq.NewTask(pattern.RecordHelloWorld, []byte("{\"name\": \"Jack (Scheduled Task every 5s)\"}")))
}
