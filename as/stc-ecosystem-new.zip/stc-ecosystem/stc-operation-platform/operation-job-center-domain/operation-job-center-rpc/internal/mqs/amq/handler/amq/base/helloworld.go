package base

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/hibiken/asynq"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"operation-job-center-domain/operation-job-center-rpc/internal/enum/taskresult"
	"operation-job-center-domain/operation-job-center-rpc/internal/model"
	"operation-job-center-domain/operation-job-center-rpc/internal/mqs/amq/types/pattern"
	"operation-job-center-domain/operation-job-center-rpc/internal/mqs/amq/types/payload"
	"operation-job-center-domain/operation-job-center-rpc/internal/svc"
	"time"
)

type HelloWorldHandler struct {
	svcCtx *svc.ServiceContext
	taskId uint64
}

func NewHelloWorldHandler(svcCtx *svc.ServiceContext) *HelloWorldHandler {
	var taskConfig model.SysTask
	err := svcCtx.DB.First(&taskConfig, "pattern = ?", pattern.RecordHelloWorld).Error
	if err != nil {
		return nil
	}
	return &HelloWorldHandler{
		svcCtx: svcCtx,
		taskId: uint64(taskConfig.ID),
	}
}

func (l *HelloWorldHandler) ProcessTask(ctx context.Context, t *asynq.Task) error {
	if l.taskId == 0 {
		logx.Errorw("failed to load task info")
		return errorxplus.NewInternalError(admini18nconst.DatabaseError)
	}

	var p payload.HelloWorldPayload
	if err := json.Unmarshal(t.Payload(), &p); err != nil {
		return errors.Join(err, fmt.Errorf("failed to umarshal the payload : %s", string(t.Payload())))
	}
	startTime := time.Now()
	fmt.Printf("Hi! %s \n", p.Name)

	finishTime := time.Now()

	taskIdN := new(int64)
	*taskIdN = int64(l.taskId)
	sysTaskLogPo := &model.SysTaskLog{
		StartedAt:    startTime,
		FinishedAt:   finishTime,
		Result:       int32(taskresult.Success),
		TaskTaskLogs: taskIdN,
	}
	err := l.svcCtx.DB.Create(sysTaskLogPo).Error
	if err != nil {
		return errorxplus.DefaultGormError(logx.WithContext(context.Background()), err,
			"failed to save task log to database")
	}

	return nil
}
