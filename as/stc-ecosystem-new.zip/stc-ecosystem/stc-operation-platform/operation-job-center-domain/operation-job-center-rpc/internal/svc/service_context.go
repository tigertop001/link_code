package svc

import (
	"github.com/hibiken/asynq"
	"github.com/redis/go-redis/v9"
	"github.com/zeromicro/go-zero/core/logx"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"operation-job-center-domain/operation-job-center-rpc/internal/config"
	"operation-job-center-domain/operation-job-center-rpc/internal/mqs/amq/types/periodicconfig"
	"operation-job-center-domain/operation-job-center-rpc/internal/query"
)

type ServiceContext struct {
	Config         config.Config
	DB             *gorm.DB
	Redis          redis.UniversalClient
	AsynqServer    *asynq.Server
	AsynqScheduler *asynq.Scheduler
	AsynqPTM       *asynq.PeriodicTaskManager
}

func NewServiceContext(c config.Config) *ServiceContext {
	db, err := gorm.Open(mysql.Open(c.DatabaseConf.Datasource), &gorm.Config{
		SkipDefaultTransaction: true,
		PrepareStmt:            true,
	})
	logx.Must(err)
	query.SetDefault(db)

	return &ServiceContext{
		Config:         c,
		DB:             db,
		AsynqServer:    c.AsynqConf.WithOriginalRedisConf(c.RedisConf).NewServer(),
		AsynqScheduler: c.AsynqConf.NewScheduler(),
		AsynqPTM:       c.AsynqConf.NewPeriodicTaskManager(periodicconfig.NewGormConfProvider(db)),
		Redis:          c.RedisConf.MustNewUniversalRedis(),
	}
}
