package addcommand

func AddCommandListInit() {
	AddCommand(func() string {
		return "1您"
	}, "1好", "1hi")

	AddCommand(func() string {
		return "2您"
	}, "2好", "2hi")
	AddCommand(func() string {
		return "3您"
	}, "3好", "3hi")
	AddCommand(func() string {
		return "6您"
	}, "6好", "6hi")
}
