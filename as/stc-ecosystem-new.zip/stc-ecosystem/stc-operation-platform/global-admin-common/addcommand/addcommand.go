package addcommand

type commandInfo struct {
	Arg    string
	Action func() string
	Desc   string
}

var Commands = []commandInfo{}

func AddCommand(fn func() string, arg, desc string) {
	Commands = append(Commands, commandInfo{Arg: arg, Desc: desc, Action: fn})
}
