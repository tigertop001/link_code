package main

import (
	"fmt"
	"global-admin-common/gormutils"
)

func main() {
	limit, offset := gormutils.PaginateLimitOffsetNum(100, 3)
	fmt.Println(limit)
	fmt.Println(offset)
}
