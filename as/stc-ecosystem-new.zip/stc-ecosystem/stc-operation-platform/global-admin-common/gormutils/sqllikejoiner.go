package gormutils

import (
	"database/sql"
	"golang.org/x/text/cases"
	"golang.org/x/text/language"
	"strings"
)

func SqlPlaceholderJoiner(raw *string, column string, expression *[]string, sqlLikeJoiner *[]interface{}) {
	if raw != nil && len(strings.TrimSpace(*raw)) > 0 {
		if path, ok := Escape(*raw); ok {
			*sqlLikeJoiner = append(*sqlLikeJoiner, sql.Named(column, path))
		} else {
			*sqlLikeJoiner = append(*sqlLikeJoiner, sql.Named(column, path))
		}
		*expression = append(*expression, SqlExpressionJoiner(column, "_"))
	}
}

func SqlExpressionJoiner(column, op string) string {
	var builder strings.Builder
	builder.WriteString(column)
	builder.WriteString(" ")
	builder.WriteString(op)
	builder.WriteString(" ")
	if "LIKE" == op {
		builder.WriteString("%@")
		builder.WriteString(ConvertToCamelCase(column, "_"))
		builder.WriteString("%")
	} else {
		builder.WriteString(ConvertToCamelCase(column, "_"))
	}

	builder.WriteString(" ")
	return builder.String()
}

func LikeExpPercentJoiner(column, SpliceSymbol string) string {
	var builder strings.Builder
	builder.WriteString(SpliceSymbol)
	builder.WriteString(column)
	builder.WriteString(SpliceSymbol)
	return builder.String()
}

func ConvertToCamelCase(input, spliter string) string {
	caseEn := cases.Title(language.Und, cases.NoLower)
	parts := strings.Split(input, spliter)
	for i := 1; i < len(parts); i++ {
		parts[i] = caseEn.String(parts[i])
	}
	return strings.Join(parts, "")
}
