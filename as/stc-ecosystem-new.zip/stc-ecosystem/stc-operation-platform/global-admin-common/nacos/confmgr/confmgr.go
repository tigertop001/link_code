package confmgr

import (
	"fmt"
	"github.com/nacos-group/nacos-sdk-go/v2/clients"
	"github.com/nacos-group/nacos-sdk-go/v2/clients/config_client"
	"github.com/nacos-group/nacos-sdk-go/v2/common/constant"
	"github.com/nacos-group/nacos-sdk-go/v2/vo"
	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/zrpc"
	"global-admin-common/filemgr"
	"global-admin-common/nacos"
	"strings"
	"sync"
)

var (
	nacosOnce    sync.Once
	configClient config_client.IConfigClient
)

type NacosConf struct {
	Addr        string   `json:",env=NACOS_ADDR"`
	Port        uint64   `json:",env=NACOS_PORT"`
	GrpcPort    uint64   `json:",env=NACOS_GRPC_PORT"`
	TimeoutMs   uint64   `json:",env=NACOS_TIMEOUT_MS"`
	Group       string   `json:",env=NACOS_GROUP"`
	DataID      string   `json:",env=NACOS_DATA_ID"`
	NamespaceID string   `json:",env=NACOS_NAMESPACE_ID"`
	ClusterName string   `json:",optional,env=NACOS_CLUSTER_NAME"`
	LogDir      string   `json:",env=NACOS_LOG_DIR"`
	CacheDir    string   `json:",env=NACOS_CACHE_DIR"`
	LogLevel    string   `json:",env=NACOS_LOG_LEVEL"`
	Username    string   `json:",optional,env=NACOS_USERNAME"`
	Password    string   `json:",optional,env=NACOS_PASSWORD"`
	ExtDataIDs  []string `json:",optional,env=ext_data_ids"`
}

func MustLoad(nacosConfigFilePath string, v interface{}, f interface{}) *NacosConf {
	var (
		err    error
		config string
	)

	var nacosConfig NacosConf

	conf.MustLoad(nacosConfigFilePath, &nacosConfig, conf.UseEnv())

	failOverFilePath := nacosConfig.CacheDir + "/" + "config/" + nacosConfig.DataID + constant.CONFIG_INFO_SPLITER + nacosConfig.Group + constant.CONFIG_INFO_SPLITER + nacosConfig.NamespaceID + "_failover"

	filemgr.CreateOrSilenceFailOverFile(failOverFilePath)
	err = nacosConfig.InitConfigClient()
	if err != nil {
		logx.Must(err)
	}
	config, err = nacosConfig.GetConfig()
	if err != nil {
		logx.Must(err)
	}
	err = conf.LoadFromYamlBytes([]byte(config), v)
	if err != nil {
		logx.Must(err)
	}
	return &nacosConfig
}

func (conf *NacosConf) NewZrpcClient(serverName, clientName string) zrpc.Client {
	var target string
	if len(strings.TrimSpace(conf.Username)) > 0 && len(strings.TrimSpace(conf.Password)) > 0 {
		target = fmt.Sprintf("nacos://%s:%s@%s:%d/%s?timeout=%s&namespace_id=%s&group_name=%s&app_name=%s&grpc=%d", conf.Username, conf.Password, conf.Addr, conf.Port, serverName, "10s", conf.NamespaceID, conf.Group, clientName, conf.GrpcPort)

	} else {
		target = fmt.Sprintf("nacos://%s:%d/%s?timeout=%s&namespace_id=%s&group_name=%s&app_name=%s&grpc=%d", conf.Addr, conf.Port, serverName, "10s", conf.NamespaceID, conf.Group, clientName, conf.GrpcPort)

	}
	return zrpc.MustNewClient(zrpc.RpcClientConf{
		Target: target,
	})
}

func (conf *NacosConf) InitConfigClient() (err error) {

	nacosOnce.Do(func() {
		sc := []constant.ServerConfig{
			*constant.NewServerConfig(conf.Addr, conf.Port, constant.WithContextPath("/nacos"), constant.WithGrpcPort(conf.GrpcPort)),
		}

		cc := *constant.NewClientConfig(
			constant.WithNamespaceId(conf.NamespaceID),
			constant.WithTimeoutMs(conf.TimeoutMs),
			constant.WithNotLoadCacheAtStart(true),
			constant.WithUsername(conf.Username),
			constant.WithPassword(conf.Password),
			constant.WithLogDir(conf.LogDir),
			constant.WithCacheDir(conf.CacheDir),
			constant.WithLogLevel(conf.LogLevel),
		)

		configClient, err = clients.NewConfigClient(
			vo.NacosClientParam{
				ClientConfig:  &cc,
				ServerConfigs: sc,
			},
		)

		if err != nil {
			logx.Must(err)
		}
	})
	return
}

func (conf *NacosConf) GetConfig() (string, error) {

	mainConfig, err := configClient.GetConfig(vo.ConfigParam{DataId: conf.DataID, Group: conf.Group})
	if err != nil {
		return "", err
	}

	if len(conf.ExtDataIDs) == 0 {
		return mainConfig, nil
	}

	var configMap = make(map[interface{}]interface{})
	mainMap, err := nacos.UnmarshalYamlToMap(mainConfig)
	if err != nil {
		return "", err
	}

	var extMap = make(map[interface{}]interface{})

	for k := range conf.ExtDataIDs {
		extConfig, errMsg := configClient.GetConfig(vo.ConfigParam{DataId: conf.ExtDataIDs[k], Group: conf.Group})
		if errMsg != nil {
			return "", errMsg
		}
		tmpExtMap, errMsg := nacos.UnmarshalYamlToMap(extConfig)
		if errMsg != nil {
			return "", errMsg
		}
		extMap = nacos.MergeMap(extMap, tmpExtMap)
	}

	configMap = nacos.MergeMap(configMap, extMap)
	configMap = nacos.MergeMap(configMap, mainMap)

	yamlString, err := nacos.MarshalObjectToYamlString(configMap)
	if err != nil {
		return "", err
	}
	return yamlString, nil
}

func (conf *NacosConf) Listen(onChange func(string, string, string, string)) error {
	return configClient.ListenConfig(vo.ConfigParam{
		DataId:   conf.DataID,
		Group:    conf.Group,
		OnChange: onChange,
	})
}
