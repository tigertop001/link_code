package smops

import (
	"errors"
	"github.com/elliotchance/pie/v2"
)

func PrimitiveTypesSliceNumConvert[T, U int | int8 | int16 | int32 | int64 | uint | uint8 | uint16 | uint32 | uint64](source []T) ([]U, error) {

	if len(source) == 0 {
		return nil, errors.New("slice empty")
	}
	return pie.Map(source, func(t T) U {
		return U(t)
	}), nil
}

func CustomTypesSliceNumConvert[T ~int | ~int8 | ~int16 | ~int32 | ~int64 | ~uint | ~uint8 | ~uint16 | ~uint32 | ~uint64]() {

}
