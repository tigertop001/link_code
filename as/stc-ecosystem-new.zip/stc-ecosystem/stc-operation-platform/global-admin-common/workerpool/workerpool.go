package main

import (
	"github.com/panjf2000/ants/v2"
	"github.com/zeromicro/go-zero/core/logx"
	"time"
)

const (
	AntsPoolSize   = 1 << 12
	ExpiryDuration = 10 * time.Second
	ReleaseTimeout = 1 << 3
	Nonblocking    = true
)

type (
	WorkerLTPool = ants.Pool
	WorkerSTPool = ants.Pool
)

func NewWorkerLTPool(size int, fn ...func(interface{})) *WorkerLTPool {
	opts := DefaultWorkerPoolOpts()
	opts.PreAlloc = true
	if len(fn) > 0 {
		opts.PanicHandler = fn[0]
	}
	pool, err := ants.NewPool(size, ants.WithOptions(*opts))
	if err != nil {
		logx.Must(err)
	}
	return pool
}

func NewWorkerSTPool(size int, fn ...func(interface{})) *WorkerSTPool {
	opts := DefaultWorkerPoolOpts()
	opts.PreAlloc = false
	if len(fn) > 0 {
		opts.PanicHandler = fn[0]
	}
	pool, err := ants.NewPool(size, ants.WithOptions(*opts))
	if err != nil {
		logx.Must(err)
	}
	return pool
}

func LTAntsRelease(wLtPool *WorkerLTPool) {
	err := wLtPool.ReleaseTimeout(time.Duration(ReleaseTimeout) * time.Second)
	if err != nil {
		wLtPool.Release()
	}
}

func STAntsRelease(sLtPool *WorkerLTPool) {
	err := sLtPool.ReleaseTimeout(time.Duration(ReleaseTimeout) * time.Second)
	if err != nil {
		sLtPool.Release()
	}
}

func TWorkerTaskSubmit(wLtPool *WorkerLTPool, fn func()) {
	err := wLtPool.Submit(fn)
	if err != nil {
		logx.Errorf("long worker pool err, detail: %s", err.Error())
	}
}

func SWorkerTaskSubmit(sLtPool *WorkerSTPool, fn func()) {
	err := sLtPool.Submit(fn)
	if err != nil {
		logx.Errorf("short worker pool err, detail: %s", err.Error())
	}
}

func DefaultWorkerPoolOpts() *ants.Options {
	return &ants.Options{
		ExpiryDuration: ExpiryDuration,
		PreAlloc:       false,
		Nonblocking:    true,
		PanicHandler: func(i interface{}) {
			logx.Errorf("goroutine pool panic: %v", i)
		},
	}

}
