package eventbus

import (
	"reflect"
	"sync"
	"testing"
)

func TestEventBus_subscribe(t *testing.T) {
	type fields struct {
		handlers     []handler
		processors   []processor
		handleLock   sync.Mutex
		dispatchLock sync.Mutex
	}
	type args struct {
		h handler
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		want    IDisposable
		wantErr bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			e := &EventBus{
				handlers:     tt.fields.handlers,
				processors:   tt.fields.processors,
				handleLock:   tt.fields.handleLock,
				dispatchLock: tt.fields.dispatchLock,
			}
			got, err := e.subscribe(tt.args.h)
			if (err != nil) != tt.wantErr {
				t.Errorf("subscribe() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("subscribe() got = %v, want %v", got, tt.want)
			}
		})
	}
}
