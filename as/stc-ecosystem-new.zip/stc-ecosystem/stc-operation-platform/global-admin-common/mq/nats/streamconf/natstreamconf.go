package streamconf

import (
	"errors"
	"github.com/nats-io/nats.go/jetstream"
	"github.com/zeromicro/go-zero/core/logx"
	"strings"
	"time"
)

const (
	NATS_REPLICAS = 3
	KB            = 1024
	MB            = KB * 1024
	GB            = MB * 1024
	MSG_PER_NUM   = 65536
)

type NatStreamConfig struct {
	StreamConfig *jetstream.StreamConfig
}

func NewStreamConfig(name string, subjects []string) *NatStreamConfig {
	if len(strings.TrimSpace(name)) == 0 {
		logx.Must(errors.New("stream config name not exists"))
	}

	streamconf := &jetstream.StreamConfig{
		Name:        name,
		Subjects:    subjects,
		Storage:     jetstream.FileStorage,
		Replicas:    NATS_REPLICAS,
		Retention:   jetstream.WorkQueuePolicy,
		Discard:     jetstream.DiscardNew,
		MaxMsgSize:  16 * KB,
		MaxMsgs:     16 * MSG_PER_NUM,
		MaxAge:      time.Duration(48) * time.Hour,
		Duplicates:  time.Duration(2) * time.Minute,
		AllowDirect: false,
		AllowRollup: false,
		DenyPurge:   true,
		DenyDelete:  true,
	}
	return &NatStreamConfig{
		StreamConfig: streamconf,
	}
}

func CustomerStreamConf(conf *jetstream.StreamConfig) *NatStreamConfig {
	return &NatStreamConfig{
		StreamConfig: conf,
	}
}
