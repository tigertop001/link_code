package nats

import (
	"context"
	"fmt"
	"github.com/nats-io/nats.go"
	"github.com/nats-io/nats.go/jetstream"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/mq/nats/clientconf"
	"global-admin-common/mq/nats/streamconf"
	"global-admin-common/utils/errorxplus"
	"strings"
)

type NatProducer struct {
	Conn *nats.Conn
}

type ProducerMsg struct {
	NatsMsgId string
	Subject   string
	PlayLoad  []byte
}

func NewNatProducer(connConf clientconf.StreamConnConf) (*NatProducer, error) {
	conn, err := connConf.NewStreamConn()
	if err != nil {
		return nil, errorxplus.NewApiInternalError(err.Error())
	}
	return &NatProducer{
		Conn: conn,
	}, nil
}

func (p *NatProducer) CreateOrDetectionStream(ctx context.Context, name string, subjects []string) (bool, error) {
	newJS, err := jetstream.New(p.Conn)
	if err != nil {
		return false, errorxplus.NewApiInternalError(err.Error())
	}

	cfg := streamconf.NewStreamConfig(name, subjects)
	_, err = newJS.CreateOrUpdateStream(ctx, *cfg.StreamConfig)
	if err != nil {
		logx.Errorw("stream config create or update stream failed", logx.Field("detail", err.Error()))
		return false, errorxplus.NewApiInternalError(err.Error())
	}
	return true, nil
}

func (p *NatProducer) Publish(ctx context.Context, natsMsgId, subject string, playLoad []byte) error {
	js, err := jetstream.New(p.Conn)
	if err != nil {
		return errorxplus.NewApiInternalError(err.Error())
	}
	var publishOpts []jetstream.PublishOpt
	if len(strings.TrimSpace(natsMsgId)) > 0 {
		publishOpts = append(publishOpts, jetstream.WithMsgID(natsMsgId))
	}
	pubAck, err := js.Publish(ctx, subject, playLoad, publishOpts...)
	if err != nil {
		return errorxplus.NewApiInternalError(err.Error())
	}
	if pubAck.Duplicate {
		logx.Errorw("pub msg duplicate")
		// TODO 加窗口上报统计告警
	}

	return nil
}

func (p *NatProducer) PublishMsgBatch(ctx nats.ContextOpt, producerMsgs *[]ProducerMsg, fullProcess bool) error {

	js, err := jetstream.New(p.Conn)
	if err != nil {
		return errorxplus.NewApiInternalError(err.Error())
	}
	if producerMsgs != nil && len(*producerMsgs) > 0 {
		for _, msg := range *producerMsgs {
			var publishOpts []jetstream.PublishOpt
			if len(strings.TrimSpace(msg.NatsMsgId)) > 0 {
				publishOpts = append(publishOpts, jetstream.WithMsgID(msg.NatsMsgId))
			}
			_, err = js.Publish(ctx, msg.Subject, msg.PlayLoad, publishOpts...)
			if err != nil {
				// TODO 已发消息统计，幂等
				logx.Errorw(fmt.Sprintf("msg %s pub error", msg.NatsMsgId), logx.Field("detail", fmt.Sprintf("msg %s pub error: %s\n", msg.NatsMsgId, err.Error())))
				if fullProcess {
					break
				}
				continue
			}
		}
	}

	return nil
}

func (p *NatProducer) PublishAsync(natsMsgId, subject string, playLoad []byte, ack bool) error {
	js, err := jetstream.New(p.Conn)
	if err != nil {
		return errorxplus.NewApiInternalError(err.Error())
	}

	var publishOpts []jetstream.PublishOpt

	if len(strings.TrimSpace(natsMsgId)) > 0 {
		publishOpts = append(publishOpts, jetstream.WithMsgID(natsMsgId))
	}

	pubAckFuture, err := js.PublishAsync(subject, playLoad, publishOpts...)
	if err != nil {
		return errorxplus.NewApiInternalError(err.Error())
	}
	if ack {
		switch v := pubAckFuture.(type) {
		case error:
			logx.Errorw("pub msg duplicate", logx.Field("detail", v.Error()))
		// TODO 加窗口上报统计告警 是否线性重新发送
		default:
			logx.Info(v)
		}
	}

	return nil
}

func (p *NatProducer) PublishAsyncBatch(producerMsgs *[]ProducerMsg, fullProcess bool) error {
	js, err := jetstream.New(p.Conn)
	if err != nil {
		return errorxplus.NewApiInternalError(err.Error())
	}

	if producerMsgs != nil && len(*producerMsgs) > 0 {
		for _, msg := range *producerMsgs {
			var publishOpts []jetstream.PublishOpt

			if len(strings.TrimSpace(msg.NatsMsgId)) > 0 {
				publishOpts = append(publishOpts, jetstream.WithMsgID(msg.NatsMsgId))
			}
			_, err := js.PublishAsync(msg.Subject, msg.PlayLoad, publishOpts...)
			if err != nil {
				// TODO 已发消息统计，幂等
				logx.Errorw(fmt.Sprintf("msg %s pub error", msg.NatsMsgId), logx.Field("detail", fmt.Sprintf("msg %s pub error: %s\n", msg.NatsMsgId, err.Error())))
				if fullProcess {
					break
				}
				continue
			}
		}
	}

	return nil
}

func (p *NatProducer) ClosePubConn() {
	if p.Conn != nil {
		err := p.Conn.Drain()
		if err != nil {
			logx.Errorw("pub conn close error", logx.Field("detal", err.Error()))
		}
	}
}
