package main

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/nats-io/nats.go"
	"github.com/nats-io/nats.go/jetstream"
	"time"
)

func main() {
	nc, _ := nats.Connect("nats://192.168.41.110:4222")
	defer nc.Drain()

	js, _ := jetstream.New(nc)

	cfg := jetstream.StreamConfig{
		Name:      "EVENTS",
		Retention: jetstream.InterestPolicy,
		Subjects:  []string{"events.>"},
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	stream, _ := js.CreateStream(ctx, cfg)
	fmt.Println("created the stream")

	js.Publish(ctx, "events.page_loaded", nil)
	js.Publish(ctx, "events.mouse_clicked", nil)
	ack, _ := js.Publish(ctx, "events.input_focused", nil)
	fmt.Println("published 3 messages")

	fmt.Printf("last message seq: %d\n", ack.Sequence)

	fmt.Println("# Stream info without any consumers")
	printStreamState(ctx, stream)

	cons, _ := stream.CreateOrUpdateConsumer(ctx, jetstream.ConsumerConfig{
		Durable:   "processor-1",
		AckPolicy: jetstream.AckExplicitPolicy,
	})

	js.Publish(ctx, "events.mouse_clicked", nil)
	js.Publish(ctx, "events.input_focused", nil)

	fmt.Println("\n# Stream info with one consumer")
	printStreamState(ctx, stream)

	msgs, _ := cons.Fetch(2)
	for msg := range msgs.Messages() {
		msg.DoubleAck(ctx)
	}

	fmt.Println("\n# Stream info with one consumer and acked messages")
	printStreamState(ctx, stream)

	cons2, _ := stream.CreateOrUpdateConsumer(ctx, jetstream.ConsumerConfig{
		Durable:   "processor-2",
		AckPolicy: jetstream.AckExplicitPolicy,
	})

	js.Publish(ctx, "events.input_focused", nil)
	js.Publish(ctx, "events.mouse_clicked", nil)

	msgs, _ = cons2.Fetch(2)

	var msgsMeta []*jetstream.MsgMetadata
	for msg := range msgs.Messages() {
		msg.DoubleAck(ctx)
		meta, _ := msg.Metadata()
		msgsMeta = append(msgsMeta, meta)
	}

	fmt.Printf("msg seqs %d and %d", msgsMeta[0].Sequence.Stream, msgsMeta[1].Sequence.Stream)

	fmt.Println("\n# Stream info with two consumers, but only one set of acked messages")
	printStreamState(ctx, stream)

	msg, _ := cons.Fetch(2)
	fmt.Println(msg)
	for msg := range msgs.Messages() {
		msg.DoubleAck(ctx)
	}

	fmt.Println("\n# Stream info with two consumers having both acked")
	printStreamState(ctx, stream)

	stream.CreateOrUpdateConsumer(ctx, jetstream.ConsumerConfig{
		Durable:       "processor-3",
		AckPolicy:     jetstream.AckExplicitPolicy,
		FilterSubject: "events.mouse_clicked",
	})
	js.Publish(ctx, "events.input_focused", nil)
	msgs, _ = cons.Fetch(1)
	aa := <-msgs.Messages()
	aa.Term()
	msgs, _ = cons2.Fetch(1)
	aa = <-msgs.Messages()
	aa.DoubleAck(ctx)

	fmt.Println("\n# Stream info with three consumers with interest from two")
	printStreamState(ctx, stream)

}

func printStreamState(ctx context.Context, stream jetstream.Stream) {
	info, _ := stream.Info(ctx)
	b, _ := json.MarshalIndent(info.State, "", " ")
	fmt.Println("inspecting stream info")
	fmt.Println(string(b))
}
