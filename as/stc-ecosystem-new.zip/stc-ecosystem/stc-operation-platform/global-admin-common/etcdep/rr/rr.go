package main

import (
	"fmt"
	"github.com/nats-io/nats.go"
	"time"
)

func main() {
	//url := os.Getenv("NATS_URL")
	//if url == "" {
	//	url = nats.DefaultURL
	//}

	nc, _ := nats.Connect("192.168.41.110:4222")
	defer nc.Drain()

	sub, _ := nc.Subscribe("greet.*", func(msg *nats.Msg) {

		name := msg.Subject[6:]
		msg.Respond([]byte("hello, " + name))
	})

	rep, _ := nc.Request("greet.joe1", nil, time.Second)
	fmt.Println(string(rep.Data))

	rep, _ = nc.Request("greet.sue2", nil, time.Second)
	fmt.Println(string(rep.Data))

	rep, _ = nc.Request("greet.bob3", nil, time.Second)
	fmt.Println(string(rep.Data))

	sub.Unsubscribe()

	_, err := nc.Request("greet.joe", nil, time.Second)
	fmt.Println(err)
}
