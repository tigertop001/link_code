package main

import (
	"global-admin-common/circle/pkga"
	"global-admin-common/circle/pkgb"
	"time"
)

func main() {
	a := new(pkga.A)

	a.B = new(pkgb.B)

	a.MyPrint()

	time.Sleep(time.Second * 2)
}
