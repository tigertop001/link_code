package trigger

type InitEventTrigger struct {
	pre              *int
	next             *int
	CurrentEventName string
	slot             []*InitEventTrigger
}

func (in *InitEventTrigger) EventProcess() {
	// TODO
}
