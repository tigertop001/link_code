package trigger

type EventTrigger interface {
	EventProcess()
}
