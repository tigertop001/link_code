package main

import (
	"context"
	"fmt"
	"global-admin-common/realtime/rtnews"
	"os"
	"os/signal"
	"time"
)

func main() {
	apikey := &rtnews.AblyConConf{
		Apikey:      "Qf-I5Q.m_FztA:0DyndiHmuG_mMt2KJvf47g2tP0LirL6P5VenAUV60V8",
		AutoConnect: true,
	}

	rs := rtnews.MustNewDuplexRS(apikey)
	rs.NewRTConnect()
	rs.NewDuplexRTChannel("get-started")

	ctx := context.Background()
	go func() {
		for {
			err := rs.RTPublish(ctx, "first", "HI Fanny 美眉😊!")
			if err != nil {
				fmt.Println("publish errors !!!")
			}
		}

	}()

	go func() {
		consumerQueue := &rtnews.RTConsumerQueue{
			Subject:    "first",
			RTConsumer: &MeiMeiConsumer{},
		}
		for {
			err := rs.RTSubscribe(ctx, consumerQueue)
			if err != nil {
				fmt.Println("subscribe errors !!!")
			}
		}

	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Kill, os.Interrupt)
	<-stop
	context.WithTimeout(ctx, time.Second*10)
	rs.RTCloseConn()
}
