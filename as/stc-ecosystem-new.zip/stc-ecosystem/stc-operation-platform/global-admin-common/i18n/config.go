package i18n

type Conf struct {
	Dir string `json:",env=I18N_DIR"`

	BundleFilePaths []string `json:",optional,env=BUNDLE_FILE_PATHS"`

	SupportLanguages []string `json:",optional,env=SUPPORT_LANGUAGES"`
}
