package main

import (
	"fmt"
	"global-admin-common/utils/encrypt"
)

func main() {
	fmt.Println(encrypt.BcryptEncrypt("key"))
}
