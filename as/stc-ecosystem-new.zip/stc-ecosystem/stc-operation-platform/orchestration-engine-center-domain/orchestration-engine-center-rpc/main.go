package main

import (
	"flag"
	"fmt"
	"orchestration-engine-center-domain/orchestration-engine-center-dependency/orchestration_engine_center"

	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/core/service"
	"github.com/zeromicro/go-zero/zrpc"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/config"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/server"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/svc"
)

var configFile = flag.String("f", "etc/conf.yaml", "the config file")

func main() {
	flag.Parse()

	var c config.Config
	conf.MustLoad(*configFile, &c)
	ctx := svc.NewServiceContext(c)

	s := zrpc.MustNewServer(c.RpcServerConf, func(grpcServer *grpc.Server) {
		orchestration_engine_center.RegisterOrchestration_Engine_CenterServer(grpcServer, server.NewOrchestrationEngineCenterServer(ctx))

		if c.Mode == service.DevMode || c.Mode == service.TestMode {
			reflection.Register(grpcServer)
		}
	})
	defer s.Stop()

	fmt.Printf("Starting rpc server at %s...\n", c.ListenOn)
	s.Start()
}
