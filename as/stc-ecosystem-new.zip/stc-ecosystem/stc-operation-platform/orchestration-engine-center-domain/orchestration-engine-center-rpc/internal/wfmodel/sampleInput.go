package wfmodel

type SampleInput struct {
	Message string `json:"message"`
}
