package svc

import (
	"github.com/zeromicro/go-zero/core/service"
	"go.uber.org/cadence/.gen/go/cadence/workflowserviceclient"
	"go.uber.org/zap"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/config"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/orchefactory"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/utils"
)

type ServiceContext struct {
	Config   config.Config
	Logger   *zap.Logger
	ClientFn func(string, string, string) workflowserviceclient.Interface
}

func NewServiceContext(c config.Config) *ServiceContext {
	var logger *zap.Logger
	switch c.Mode {
	case service.TestMode:
		logger = utils.MustBuildLogger(service.DevMode)
	case service.PreMode:
		logger = utils.MustBuildLogger(service.DevMode)
	case service.ProMode:
		logger = utils.MustBuildLogger(service.ProMode)
	default:
		logger = utils.MustBuildLogger(service.DevMode)
	}
	clientFn := orchefactory.BuildCadenceClient

	return &ServiceContext{
		Config:   c,
		Logger:   logger,
		ClientFn: clientFn,
	}
}
