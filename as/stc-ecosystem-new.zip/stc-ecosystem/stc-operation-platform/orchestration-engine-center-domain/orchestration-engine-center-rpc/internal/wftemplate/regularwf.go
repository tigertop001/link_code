package wftemplate

import (
	"go.uber.org/cadence/workflow"
	"go.uber.org/zap"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/aytemplate"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/wfmodel"
	"time"
)

func CadenceSampleWorkflow(ctx workflow.Context, input wfmodel.SampleInput) (string, error) {
	ao := workflow.ActivityOptions{
		ScheduleToStartTimeout: time.Minute,
		StartToCloseTimeout:    time.Minute,
	}
	ctx = workflow.WithActivityOptions(ctx, ao)

	logger := workflow.GetLogger(ctx)
	logger.Info("HelloWorldWorkflow started")

	var greetingMsg string
	err := workflow.ExecuteActivity(ctx, aytemplate.HelloWorldActivity, input).Get(ctx, &greetingMsg)
	if err != nil {
		logger.Error("HelloWorldActivity failed", zap.Error(err))
		return "", err
	}

	logger.Info("Workflow result", zap.String("greeting", greetingMsg))
	return greetingMsg, nil
}
