package logic

import (
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"go.uber.org/cadence/activity"
	"go.uber.org/cadence/workflow"
	"orchestration-engine-center-domain/orchestration-engine-center-dependency/orchestration_engine_center"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/aytemplate"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/orchefactory"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/svc"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/wftemplate"
)

type RegularWorkflowLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewRegularWorkflowLogic(ctx context.Context, svcCtx *svc.ServiceContext) *RegularWorkflowLogic {
	return &RegularWorkflowLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *RegularWorkflowLogic) RegularWorkflow(in *orchestration_engine_center.OrchestrationEngineReq) (*orchestration_engine_center.BaseResp, error) {

	var target orchefactory.WfStartConf
	//err := copier.Copy(&target, in)
	//if err != nil {
	//	return nil, errorxplus.NewInternalError(err.Error())
	//}
	target.DomainName = *in.DomainName
	target.TaskListName = *in.TaskListName
	target.ClientName = *in.ClientName
	target.CadenceService = *in.CadenceService

	worker := orchefactory.BuildCadenceWorker(l.svcCtx.ClientFn, l.svcCtx.Config, l.svcCtx.Logger, target)
	worker.RegisterWorkflowWithOptions(wftemplate.CadenceSampleWorkflow, workflow.RegisterOptions{Name: *in.WorkflowType})
	worker.RegisterActivityWithOptions(aytemplate.HelloWorldActivity, activity.RegisterOptions{Name: *in.ActivityType})
	err := worker.Start()
	if err != nil {
		return nil, errorxplus.NewInternalError(err.Error())
	}
	return &orchestration_engine_center.BaseResp{
		Msg: admini18nconst.CreateSuccess,
	}, nil
}
