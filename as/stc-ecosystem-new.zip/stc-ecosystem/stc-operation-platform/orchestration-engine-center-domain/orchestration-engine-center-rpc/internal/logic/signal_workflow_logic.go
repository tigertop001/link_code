package logic

import (
	"context"
	"orchestration-engine-center-domain/orchestration-engine-center-dependency/orchestration_engine_center"

	"github.com/zeromicro/go-zero/core/logx"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/svc"
)

type SignalWorkflowLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewSignalWorkflowLogic(ctx context.Context, svcCtx *svc.ServiceContext) *SignalWorkflowLogic {
	return &SignalWorkflowLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *SignalWorkflowLogic) SignalWorkflow(in *orchestration_engine_center.OrchestrationEngineReq) (*orchestration_engine_center.BaseResp, error) {
	// todo: add your logic here and delete this line

	return &orchestration_engine_center.BaseResp{}, nil
}
