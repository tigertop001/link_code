package logic

import (
	"context"
	"orchestration-engine-center-domain/orchestration-engine-center-dependency/orchestration_engine_center"

	"github.com/zeromicro/go-zero/core/logx"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/svc"
)

type ParallelWorkflowLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewParallelWorkflowLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ParallelWorkflowLogic {
	return &ParallelWorkflowLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *ParallelWorkflowLogic) ParallelWorkflow(in *orchestration_engine_center.OrchestrationEngineReq) (*orchestration_engine_center.BaseResp, error) {
	// todo: add your logic here and delete this line

	return &orchestration_engine_center.BaseResp{}, nil
}
