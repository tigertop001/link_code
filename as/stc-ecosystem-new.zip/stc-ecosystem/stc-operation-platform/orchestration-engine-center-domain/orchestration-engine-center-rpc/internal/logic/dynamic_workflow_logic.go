package logic

import (
	"context"
	"orchestration-engine-center-domain/orchestration-engine-center-dependency/orchestration_engine_center"

	"github.com/zeromicro/go-zero/core/logx"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/svc"
)

type DynamicWorkflowLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDynamicWorkflowLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DynamicWorkflowLogic {
	return &DynamicWorkflowLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *DynamicWorkflowLogic) DynamicWorkflow(in *orchestration_engine_center.OrchestrationEngineReq) (*orchestration_engine_center.BaseResp, error) {
	// todo: add your logic here and delete this line

	return &orchestration_engine_center.BaseResp{}, nil
}
