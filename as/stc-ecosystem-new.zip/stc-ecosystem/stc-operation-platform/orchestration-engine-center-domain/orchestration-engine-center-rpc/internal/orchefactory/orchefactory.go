package orchefactory

import (
	"github.com/uber-go/tally"
	apiv1 "github.com/uber/cadence-idl/go/proto/api/v1"
	"go.uber.org/cadence/.gen/go/cadence/workflowserviceclient"
	"go.uber.org/cadence/compatibility"
	"go.uber.org/cadence/worker"
	"go.uber.org/yarpc"
	"go.uber.org/yarpc/transport/grpc"
	"go.uber.org/zap"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/config"
)

type WfStartConf struct {
	DomainName     string
	TaskListName   string
	ClientName     string
	CadenceService string
	WorkflowType   string
}

func BuildCadenceClient(clientName, cadenceService, hostPort string) workflowserviceclient.Interface {
	dispatcher := yarpc.NewDispatcher(yarpc.Config{
		Name: clientName,
		Outbounds: yarpc.Outbounds{
			cadenceService: {Unary: grpc.NewTransport().NewSingleOutbound(hostPort)},
		},
	})
	if err := dispatcher.Start(); err != nil {
		panic("Failed to start dispatcher: " + err.Error())
	}

	clientConfig := dispatcher.ClientConfig(cadenceService)

	return compatibility.NewThrift2ProtoAdapter(
		apiv1.NewDomainAPIYARPCClient(clientConfig),
		apiv1.NewWorkflowAPIYARPCClient(clientConfig),
		apiv1.NewWorkerAPIYARPCClient(clientConfig),
		apiv1.NewVisibilityAPIYARPCClient(clientConfig),
	)
}

func BuildCadenceWorker(clientFn func(string, string, string) workflowserviceclient.Interface, config config.Config, logger *zap.Logger, in WfStartConf) worker.Worker {

	ins := clientFn(in.ClientName, in.CadenceService, config.CadenceConf.HostPort)
	workerOptions := worker.Options{
		Logger:       logger,
		MetricsScope: tally.NewTestScope(in.TaskListName, nil),
	}
	return worker.New(
		ins,
		in.DomainName,
		in.TaskListName,
		workerOptions,
	)

}
