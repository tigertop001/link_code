package aytemplate

import (
	"context"
	"fmt"
	"go.uber.org/cadence/activity"
	"orchestration-engine-center-domain/orchestration-engine-center-rpc/internal/wfmodel"
)

func HelloWorldActivity(ctx context.Context, input wfmodel.SampleInput) (string, error) {
	logger := activity.GetLogger(ctx)
	logger.Info("HelloWorldActivity started")
	return fmt.Sprintf("Hello, %s!", input.Message), nil
}
