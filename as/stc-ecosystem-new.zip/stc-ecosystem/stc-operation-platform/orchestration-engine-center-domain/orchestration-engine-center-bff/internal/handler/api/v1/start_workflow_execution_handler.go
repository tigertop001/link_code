package v1

import (
	"net/http"

	"github.com/zeromicro/go-zero/rest/httpx"
	"orchestration-engine-center-domain/orchestration-engine-center-bff/internal/logic/api/v1"
	"orchestration-engine-center-domain/orchestration-engine-center-bff/internal/svc"
	"orchestration-engine-center-domain/orchestration-engine-center-bff/internal/types"
)

func StartWorkflowExecutionHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.WfExecRequest
		if err := httpx.Parse(r, &req); err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
			return
		}

		l := v1.NewStartWorkflowExecutionLogic(r.Context(), svcCtx)
		resp, err := l.StartWorkflowExecution(&req)
		if err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
