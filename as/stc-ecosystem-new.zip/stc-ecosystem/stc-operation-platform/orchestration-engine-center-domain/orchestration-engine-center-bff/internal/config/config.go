package config

import (
	"github.com/zeromicro/go-zero/rest"
	"global-admin-common/i18n"
)

type Config struct {
	rest.RestConf
	CadenceConf struct {
		HostPort string
	}
	I18nConf i18n.Conf
}
