package utils

import (
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/service"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

func MustBuildLogger(model string) *zap.Logger {
	var config zap.Config
	switch model {
	case service.TestMode:
		config = zap.NewDevelopmentConfig()
	case service.PreMode:
		config = zap.NewProductionConfig()
	case service.ProMode:
		config = zap.NewProductionConfig()
	default:
		config = zap.NewDevelopmentConfig()
	}
	config.Level.SetLevel(zapcore.InfoLevel)
	logger, err := config.Build()
	logx.Must(err)
	return logger
}
