package svc

import (
	"github.com/zeromicro/go-zero/core/service"
	"global-admin-common/i18n"
	"go.uber.org/cadence/.gen/go/cadence/workflowserviceclient"
	"go.uber.org/zap"
	"orchestration-engine-center-domain/orchestration-engine-center-bff/internal/config"
	i18n2 "orchestration-engine-center-domain/orchestration-engine-center-bff/internal/i18n"
	"orchestration-engine-center-domain/orchestration-engine-center-bff/internal/orchefactory"
	"orchestration-engine-center-domain/orchestration-engine-center-bff/internal/utils"
)

type ServiceContext struct {
	Config   config.Config
	Trans    *i18n.Translator
	Logger   *zap.Logger
	ClientFn func(string, string, string) workflowserviceclient.Interface
}

func NewServiceContext(c config.Config) *ServiceContext {
	var logger *zap.Logger
	switch c.Mode {
	case service.TestMode:
		logger = utils.MustBuildLogger(service.DevMode)
	case service.PreMode:
		logger = utils.MustBuildLogger(service.DevMode)
	case service.ProMode:
		logger = utils.MustBuildLogger(service.ProMode)
	default:
		logger = utils.MustBuildLogger(service.DevMode)
	}
	clientFn := orchefactory.BuildCadenceClient

	var trans *i18n.Translator

	if c.I18nConf.Dir != "" {
		trans = i18n.NewTranslatorFromFile(c.I18nConf)
	} else {
		trans = i18n.NewTranslator(i18n2.LocaleFS)
	}
	trans.AddLanguagesByConf(c.I18nConf, i18n2.LocaleFS)

	return &ServiceContext{
		Config:   c,
		Logger:   logger,
		ClientFn: clientFn,
		Trans:    trans,
	}
}
