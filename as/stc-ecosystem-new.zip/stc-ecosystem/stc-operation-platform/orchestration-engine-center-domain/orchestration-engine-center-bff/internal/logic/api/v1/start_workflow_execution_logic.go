package v1

import (
	"context"
	"github.com/google/uuid"
	"go.uber.org/cadence/.gen/go/shared"
	"go.uber.org/zap"
	"orchestration-engine-center-domain/orchestration-engine-center-bff/internal/orchefactory"
	"orchestration-engine-center-domain/orchestration-engine-center-bff/internal/svc"
	"orchestration-engine-center-domain/orchestration-engine-center-bff/internal/types"
	"time"

	"github.com/zeromicro/go-zero/core/logx"
)

type StartWorkflowExecutionLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewStartWorkflowExecutionLogic(ctx context.Context, svcCtx *svc.ServiceContext) *StartWorkflowExecutionLogic {
	return &StartWorkflowExecutionLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *StartWorkflowExecutionLogic) StartWorkflowExecution(req *types.WfExecRequest) (resp *types.BaseMsgResp, err error) {

	cadenceClient := orchefactory.BuildCadenceClient(*req.ClientName, *req.CadenceService, l.svcCtx.Config.CadenceConf.HostPort)
	logger := l.svcCtx.Logger
	domain := req.DomainName
	taskListName := req.TaskListName
	workflowID := uuid.New().String()
	requestID := uuid.New().String()
	iExecutionTimeout := new(int32)
	*iExecutionTimeout = int32(*req.ExecutionTimeout)
	iCloseTimeout := new(int32)
	*iCloseTimeout = int32(*req.CloseTimeout)
	workflowType := req.WorkflowType
	input := []byte(*req.Payload)
	wfReq := shared.StartWorkflowExecutionRequest{
		Domain:     domain,
		WorkflowId: &workflowID,
		WorkflowType: &shared.WorkflowType{
			Name: workflowType,
		},
		TaskList: &shared.TaskList{
			Name: taskListName,
		},
		Input:                               input,
		ExecutionStartToCloseTimeoutSeconds: iExecutionTimeout,
		TaskStartToCloseTimeoutSeconds:      iCloseTimeout,
		RequestId:                           &requestID,
	}

	ctx, cancel := context.WithTimeout(context.Background(), time.Minute)
	defer cancel()
	wfResp, err := cadenceClient.StartWorkflowExecution(ctx, &wfReq)
	if err != nil {
		logger.Error("Failed to create workflow", zap.Error(err))
		panic("Failed to create workflow.")
	}

	logger.Info("successfully started HelloWorld workflow", zap.String("runID", wfResp.GetRunId()))
	return &types.BaseMsgResp{
		Msg: l.svcCtx.Trans.Trans(l.ctx, wfResp.GetRunId()),
	}, nil
}
