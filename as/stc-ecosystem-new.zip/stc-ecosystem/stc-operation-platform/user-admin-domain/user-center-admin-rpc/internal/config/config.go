package config

import (
	"github.com/zeromicro/go-zero/zrpc"
	"global-admin-common/config"
	"global-admin-common/plugins/casbin"
)

type Config struct {
	zrpc.RpcServerConf
	DatabaseConf struct {
		Datasource string
	}
	CasbinConf casbin.CasbinConf
	RedisConf  config.RedisConf
}
