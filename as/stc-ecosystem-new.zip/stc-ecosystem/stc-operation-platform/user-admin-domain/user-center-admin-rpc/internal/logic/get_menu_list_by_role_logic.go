package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetMenuListByRoleLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetMenuListByRoleLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetMenuListByRoleLogic {
	return &GetMenuListByRoleLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: menu
func (l *GetMenuListByRoleLogic) GetMenuListByRole(in *usercenter.BaseMsg) (*usercenter.MenuInfoList, error) {

	sysRoleRepo := query.SysRole
	roleResult, err := sysRoleRepo.WithContext(l.ctx).Where(sysRoleRepo.Code.In(strings.Split(in.Msg, ",")...)).Find()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	var roleIds []int64
	for _, v := range roleResult {
		roleIds = append(roleIds, v.ID)
	}
	sysMenuRepo := query.SysMenu
	roleMenuRepo := query.RoleMenu
	var MenuRoleUns []model.MenuRoleUn
	err = sysMenuRepo.WithContext(l.ctx).Select(sysMenuRepo.ALL, roleMenuRepo.RoleID).Join(roleMenuRepo, roleMenuRepo.MenuID.EqCol(sysMenuRepo.ID)).
		Where(sysMenuRepo.Disabled.Not(), roleMenuRepo.RoleID.In(roleIds...)).Scan(&MenuRoleUns)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	resp := &usercenter.MenuInfoList{}
	for _, m := range MenuRoleUns {
		uId := new(uint64)
		*uId = uint64(m.ID)
		uMenuType := new(uint32)
		*uMenuType = uint32(m.MenuType)
		uMenuLevel := new(uint32)
		*uMenuLevel = uint32(m.MenuLevel)
		uParentID := new(uint64)
		*uParentID = uint64(*m.ParentID)
		uSort := new(uint32)
		*uSort = uint32(m.Sort)
		uDynamicLevel := new(uint32)
		*uDynamicLevel = uint32(*m.DynamicLevel)
		resp.Data = append(resp.Data, &usercenter.MenuInfo{
			Id:          uId,
			CreatedAt:   pointy.GetPointer(m.CreatedAt.UnixMilli()),
			UpdatedAt:   pointy.GetPointer(m.UpdatedAt.UnixMilli()),
			MenuType:    uMenuType,
			Level:       uMenuLevel,
			ParentId:    uParentID,
			Path:        m.Path,
			Name:        &m.Name,
			Redirect:    m.Redirect,
			Component:   m.Component,
			Sort:        uSort,
			ServiceName: m.ServiceName,
			Meta: &usercenter.Meta{
				Title:              &m.Title,
				Icon:               &m.Icon,
				HideMenu:           m.HideMenu,
				HideBreadcrumb:     m.HideBreadcrumb,
				IgnoreKeepAlive:    m.IgnoreKeepAlive,
				HideTab:            m.HideTab,
				FrameSrc:           m.FrameSrc,
				CarryParam:         m.CarryParam,
				HideChildrenInMenu: m.HideChildrenInMenu,
				Affix:              m.Affix,
				DynamicLevel:       uDynamicLevel,
				RealPath:           m.RealPath,
			},
		})
	}

	resp.Total = uint64(len(resp.Data))
	return resp, nil
}
