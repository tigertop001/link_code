package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/smops"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type DeletePositionLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDeletePositionLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeletePositionLogic {
	return &DeletePositionLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: position
func (l *DeletePositionLogic) DeletePosition(in *usercenter.IDsReq) (*usercenter.BaseResp, error) {

	iIds, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.Ids)
	if err != nil {
		return nil, err
	}
	var total int64
	sysUserRepo := query.SysUser
	sysPositionRepo := query.SysPosition
	userPositionRepo := query.UserPosition
	subQuery := userPositionRepo.WithContext(l.ctx).Select(userPositionRepo.UserID).
		Join(sysPositionRepo, sysPositionRepo.ID.EqCol(userPositionRepo.PositionID)).
		Where(sysPositionRepo.ID.In(iIds...))

	err = sysUserRepo.WithContext(l.ctx).Select(sysUserRepo.ID.Count()).Where(subQuery, sysUserRepo.DeletedAt.IsNull()).Scan(&total)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	if total == 0 {
		return nil, errorxplus.NewInvalidArgumentError("position userExistError")
	}
	_, err = sysPositionRepo.WithContext(l.ctx).Where(sysPositionRepo.ID.In(iIds...)).Delete()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.DeleteSuccess}, nil
}
