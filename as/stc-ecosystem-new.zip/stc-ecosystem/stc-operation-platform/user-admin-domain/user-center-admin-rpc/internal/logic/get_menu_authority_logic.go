package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type GetMenuAuthorityLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetMenuAuthorityLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetMenuAuthorityLogic {
	return &GetMenuAuthorityLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: authority
func (l *GetMenuAuthorityLogic) GetMenuAuthority(in *usercenter2.IDReq) (*usercenter2.RoleMenuAuthorityResp, error) {

	roleMenuRepo := query.RoleMenu

	menus, err := roleMenuRepo.WithContext(l.ctx).Select(roleMenuRepo.MenuID).Where(roleMenuRepo.RoleID.Eq(int64(in.Id))).Find()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	var menuIds []uint64
	for _, menu := range menus {
		menuIds = append(menuIds, uint64(menu.MenuID))
	}

	return &usercenter2.RoleMenuAuthorityResp{
		MenuId: menuIds,
	}, nil
}
