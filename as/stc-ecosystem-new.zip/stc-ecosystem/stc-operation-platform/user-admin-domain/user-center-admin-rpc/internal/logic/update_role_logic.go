package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateRoleLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateRoleLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateRoleLogic {
	return &UpdateRoleLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: role
func (l *UpdateRoleLogic) UpdateRole(in *usercenter.RoleInfo) (*usercenter.BaseResp, error) {
	sysRoleTx := query.Use(l.svcCtx.DB)
	err := sysRoleTx.Transaction(func(tx *query.Query) error {
		origin, err := tx.SysRole.WithContext(l.ctx).Where(tx.SysRole.ID.Eq(int64(*in.Id))).First()
		if err != nil {
			return err
		}

		sysRolePo := &model.SysRole{}

		if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
			sysRolePo.Name = *in.Name
		}
		if in.Code != nil && len(strings.TrimSpace(*in.Code)) > 0 {
			sysRolePo.Code = *in.Code
		}
		if in.DefaultRouter != nil && len(strings.TrimSpace(*in.DefaultRouter)) > 0 {
			sysRolePo.DefaultRouter = *in.DefaultRouter
		}
		if in.Remark != nil && len(strings.TrimSpace(*in.Remark)) > 0 {
			sysRolePo.Remark = *in.Remark
		}
		if in.Sort != nil {
			sysRolePo.Sort = int32(*in.Sort)
		}
		_, err = tx.SysRole.WithContext(l.ctx).Where(tx.SysRole.ID.Eq(int64(*in.Id))).Updates(sysRolePo)
		if err != nil {
			return err
		}
		if in.Code != nil && origin.Code != *in.Code {
			_, err := tx.CasbinRule.WithContext(l.ctx).Where(query.CasbinRule.V0.Eq(origin.Code)).Update(query.CasbinRule.V0, *in.Code)
			if err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.UpdateSuccess}, nil
}
