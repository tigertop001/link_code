package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type DeleteMenuLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDeleteMenuLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteMenuLogic {
	return &DeleteMenuLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: menu
func (l *DeleteMenuLogic) DeleteMenu(in *usercenter.IDReq) (*usercenter.BaseResp, error) {
	sysMenuRepo := query.SysMenu
	count, err := sysMenuRepo.WithContext(l.ctx).Where(sysMenuRepo.ParentID.Eq(int64(in.Id))).Count()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	if count > 0 {
		logx.Errorw("delete menu failed, please check its children had been deleted",
			logx.Field("menuId", in.Id))
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	_, err = sysMenuRepo.WithContext(l.ctx).Where(sysMenuRepo.ID.Eq(int64(in.Id))).Delete()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.DeleteSuccess}, nil
}
