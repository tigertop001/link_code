package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type DeleteTokenLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDeleteTokenLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteTokenLogic {
	return &DeleteTokenLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: token
func (l *DeleteTokenLogic) DeleteToken(in *usercenter.UUIDsReq) (*usercenter.BaseResp, error) {
	sysTokenRepo := query.SysToken
	_, err := sysTokenRepo.WithContext(l.ctx).Where(sysTokenRepo.ID.In(in.Ids...)).Delete()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	return &usercenter.BaseResp{Msg: admini18nconst.DeleteSuccess}, nil
}
