package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/config"
	"global-admin-common/enum/common"
	"global-admin-common/msg/logmsg"
	"global-admin-common/utils/errorxplus"
	"time"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type BlockUserAllTokenLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewBlockUserAllTokenLogic(ctx context.Context, svcCtx *svc.ServiceContext) *BlockUserAllTokenLogic {
	return &BlockUserAllTokenLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: token
func (l *BlockUserAllTokenLogic) BlockUserAllToken(in *usercenter.UUIDReq) (*usercenter.BaseResp, error) {
	sysTokenRepo := query.SysToken
	_, err := sysTokenRepo.WithContext(l.ctx).Where(sysTokenRepo.UUID.Eq(in.Id)).UpdateSimple(sysTokenRepo.Status.Value(int32(common.StatusBanned)), sysTokenRepo.UpdatedAt.Value(time.Now()))
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	tokenData, err := sysTokenRepo.WithContext(l.ctx).Where(sysTokenRepo.UUID.Eq(in.Id), sysTokenRepo.Status.Eq(int32(common.StatusBanned)), sysTokenRepo.ExpiredAt.Gt(time.Now())).Find()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	for _, v := range tokenData {
		expiredTime := v.ExpiredAt.Sub(time.Now())
		if expiredTime > 0 {
			err = l.svcCtx.Redis.Set(l.ctx, config.RedisTokenPrefix+v.Token, "1", expiredTime).Err()
			if err != nil {
				logx.Errorw(logmsg.RedisError, logx.Field("detail", err.Error()))
				return nil, errorxplus.NewInternalError(admini18nconst.RedisError)
			}
		}

	}
	return &usercenter.BaseResp{Msg: admini18nconst.UpdateSuccess}, nil
}
