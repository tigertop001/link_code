package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetOauthProviderByIdLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetOauthProviderByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetOauthProviderByIdLogic {
	return &GetOauthProviderByIdLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: oauthprovider
func (l *GetOauthProviderByIdLogic) GetOauthProviderById(in *usercenter.IDReq) (*usercenter.OauthProviderInfo, error) {

	sysOauthProviderRepo := query.SysOauthProvider
	result, err := sysOauthProviderRepo.WithContext(l.ctx).Where(sysOauthProviderRepo.ID.Eq(int64(in.Id))).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	uId := new(uint64)
	*uId = uint64(result.ID)
	uAuthStyle := new(uint64)
	*uAuthStyle = uint64(result.AuthStyle)
	return &usercenter.OauthProviderInfo{
		Id:           uId,
		CreatedAt:    pointy.GetPointer(result.CreatedAt.UnixMilli()),
		UpdatedAt:    pointy.GetPointer(result.UpdatedAt.UnixMilli()),
		Name:         &result.Name,
		ClientId:     &result.ClientID,
		ClientSecret: &result.ClientSecret,
		RedirectUrl:  &result.RedirectURL,
		Scopes:       &result.Scopes,
		AuthUrl:      &result.AuthURL,
		TokenUrl:     &result.TokenURL,
		AuthStyle:    uAuthStyle,
		InfoUrl:      &result.InfoURL,
	}, nil
}
