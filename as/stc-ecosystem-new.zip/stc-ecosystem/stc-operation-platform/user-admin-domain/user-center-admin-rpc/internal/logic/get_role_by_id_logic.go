package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetRoleByIdLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetRoleByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetRoleByIdLogic {
	return &GetRoleByIdLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: role
func (l *GetRoleByIdLogic) GetRoleById(in *usercenter.IDReq) (*usercenter.RoleInfo, error) {
	sysRoleRepo := query.SysRole
	result, err := sysRoleRepo.WithContext(l.ctx).Where(sysRoleRepo.ID.Eq(int64(in.Id))).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	uId := new(uint64)
	*uId = uint64(result.ID)
	uSort := new(uint32)
	*uSort = uint32(result.Sort)
	uStatus := new(uint32)
	*uStatus = uint32(*result.Status)
	return &usercenter.RoleInfo{
		Id:            uId,
		CreatedAt:     pointy.GetPointer(result.CreatedAt.UnixMilli()),
		UpdatedAt:     pointy.GetPointer(result.UpdatedAt.UnixMilli()),
		Status:        uStatus,
		Name:          &result.Name,
		Code:          &result.Code,
		DefaultRouter: &result.DefaultRouter,
		Remark:        &result.Remark,
		Sort:          uSort,
	}, nil
}
