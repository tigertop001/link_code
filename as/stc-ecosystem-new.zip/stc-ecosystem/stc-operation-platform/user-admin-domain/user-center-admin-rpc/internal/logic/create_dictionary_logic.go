package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type CreateDictionaryLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateDictionaryLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateDictionaryLogic {
	return &CreateDictionaryLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// Dictionary management
func (l *CreateDictionaryLogic) CreateDictionary(in *usercenter2.DictionaryInfo) (*usercenter2.BaseIDResp, error) {
	sysDictionaryPo := &model.SysDictionary{}
	if in.Status != nil {
		uStatus := new(int32)
		*uStatus = int32(*in.Status)
		sysDictionaryPo.Status = uStatus
	}
	if in.Title != nil && len(strings.TrimSpace(*in.Title)) > 0 {
		sysDictionaryPo.Title = *in.Title
	}

	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysDictionaryPo.Name = *in.Name
	}
	if in.Desc != nil && len(strings.TrimSpace(*in.Desc)) > 0 {
		sysDictionaryPo.Desc = in.Desc
	}

	sysDictionaryRepo := query.SysDictionary
	err := sysDictionaryRepo.WithContext(l.ctx).Create(sysDictionaryPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter2.BaseIDResp{
		Id:  uint64(sysDictionaryPo.ID),
		Msg: admini18nconst.CreateSuccess,
	}, nil
}
