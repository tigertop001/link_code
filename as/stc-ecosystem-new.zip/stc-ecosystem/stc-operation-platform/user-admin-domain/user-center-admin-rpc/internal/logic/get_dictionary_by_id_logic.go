package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type GetDictionaryByIdLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetDictionaryByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetDictionaryByIdLogic {
	return &GetDictionaryByIdLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: dictionary
func (l *GetDictionaryByIdLogic) GetDictionaryById(in *usercenter.IDReq) (*usercenter.DictionaryInfo, error) {

	sysDictionaryRepo := query.SysDictionary
	result, err := sysDictionaryRepo.WithContext(l.ctx).Where(sysDictionaryRepo.ID.Eq(int64(in.Id))).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	uId := new(uint64)
	*uId = uint64(result.ID)
	uStatus := new(uint32)
	*uStatus = uint32(*result.Status)
	return &usercenter.DictionaryInfo{
		Id:        uId,
		CreatedAt: pointy.GetPointer(result.CreatedAt.UnixMilli()),
		UpdatedAt: pointy.GetPointer(result.UpdatedAt.UnixMilli()),
		Status:    uStatus,
		Title:     &result.Title,
		Name:      &result.Name,
		Desc:      result.Desc,
	}, nil
}
