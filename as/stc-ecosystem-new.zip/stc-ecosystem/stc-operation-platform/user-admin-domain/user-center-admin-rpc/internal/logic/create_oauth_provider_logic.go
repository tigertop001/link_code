package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type CreateOauthProviderLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateOauthProviderLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateOauthProviderLogic {
	return &CreateOauthProviderLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// OauthProvider management
func (l *CreateOauthProviderLogic) CreateOauthProvider(in *usercenter2.OauthProviderInfo) (*usercenter2.BaseIDResp, error) {
	sysOauthProviderPo := &model.SysOauthProvider{}
	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysOauthProviderPo.Name = *in.Name
	}
	if in.ClientId != nil && len(strings.TrimSpace(*in.ClientId)) > 0 {
		sysOauthProviderPo.ClientID = *in.ClientId
	}
	if in.ClientSecret != nil && len(strings.TrimSpace(*in.ClientSecret)) > 0 {
		sysOauthProviderPo.ClientSecret = *in.ClientSecret
	}
	if in.RedirectUrl != nil && len(strings.TrimSpace(*in.RedirectUrl)) > 0 {
		sysOauthProviderPo.RedirectURL = *in.RedirectUrl
	}
	if in.Scopes != nil && len(strings.TrimSpace(*in.Scopes)) > 0 {
		sysOauthProviderPo.Scopes = *in.Scopes
	}
	if in.AuthUrl != nil && len(strings.TrimSpace(*in.AuthUrl)) > 0 {
		sysOauthProviderPo.AuthURL = *in.AuthUrl
	}
	if in.TokenUrl != nil && len(strings.TrimSpace(*in.TokenUrl)) > 0 {
		sysOauthProviderPo.TokenURL = *in.TokenUrl
	}
	if in.AuthStyle != nil {
		uAuthStyle := new(int64)
		*uAuthStyle = int64(*in.AuthStyle)
		sysOauthProviderPo.AuthStyle = *uAuthStyle
	}
	if in.InfoUrl != nil && len(strings.TrimSpace(*in.InfoUrl)) > 0 {
		sysOauthProviderPo.InfoURL = *in.InfoUrl
	}

	err := query.SysOauthProvider.WithContext(l.ctx).Create(sysOauthProviderPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	return &usercenter2.BaseIDResp{Id: uint64(sysOauthProviderPo.ID), Msg: admini18nconst.CreateSuccess}, nil
}
