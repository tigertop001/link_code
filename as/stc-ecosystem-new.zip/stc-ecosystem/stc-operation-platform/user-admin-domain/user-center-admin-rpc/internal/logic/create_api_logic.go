package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateApiLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateApiLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateApiLogic {
	return &CreateApiLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// API management
func (l *CreateApiLogic) CreateApi(in *usercenter.ApiInfo) (*usercenter.BaseIDResp, error) {

	sysApiPo := &model.SysAPI{}
	if in.Path != nil && len(strings.TrimSpace(*in.Path)) > 0 {
		sysApiPo.Path = *in.Path
	}
	if in.Description != nil && len(strings.TrimSpace(*in.Description)) > 0 {
		sysApiPo.Description = *in.Description
	}
	if in.ApiGroup != nil && len(strings.TrimSpace(*in.ApiGroup)) > 0 {
		sysApiPo.APIGroup = *in.ApiGroup
	}
	if in.Method != nil && len(strings.TrimSpace(*in.Method)) > 0 {
		sysApiPo.Method = *in.Method
	}
	if in.IsRequired != nil {
		sysApiPo.IsRequired = *in.IsRequired
	}
	if in.ServiceName != nil && len(strings.TrimSpace(*in.ServiceName)) > 0 {
		sysApiPo.ServiceName = *in.ServiceName
	}
	sysApIRepo := query.SysAPI
	err := sysApIRepo.WithContext(l.ctx).Create(sysApiPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseIDResp{
		Id:  uint64(sysApiPo.ID),
		Msg: admini18nconst.CreateSuccess,
	}, nil
}
