package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/smops"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type DeleteApiLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDeleteApiLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteApiLogic {
	return &DeleteApiLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: api
func (l *DeleteApiLogic) DeleteApi(in *usercenter2.IDsReq) (*usercenter2.BaseResp, error) {

	ids, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.Ids)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	sysApiRepo := query.SysAPI

	_, err = sysApiRepo.WithContext(l.ctx).Where(sysApiRepo.ID.In(ids...)).Delete()

	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter2.BaseResp{Msg: admini18nconst.DeleteSuccess}, nil
}
