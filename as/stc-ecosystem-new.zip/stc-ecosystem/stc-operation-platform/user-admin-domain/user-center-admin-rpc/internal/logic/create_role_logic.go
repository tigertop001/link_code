package logic

import (
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
	usercenter "user-admin-domain/user-grpc-admin-dependency/usercenter"
)

type CreateRoleLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateRoleLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateRoleLogic {
	return &CreateRoleLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// Role management
func (l *CreateRoleLogic) CreateRole(in *usercenter.RoleInfo) (*usercenter.BaseIDResp, error) {

	sysRolePo := &model.SysRole{}
	if in.Status != nil {
		uStatus := new(int32)
		*uStatus = int32(*in.Status)
		sysRolePo.Status = uStatus
	}

	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysRolePo.Name = *in.Name
	}
	if in.Code != nil && len(strings.TrimSpace(*in.Code)) > 0 {
		sysRolePo.Code = *in.Code
	}
	if in.DefaultRouter != nil && len(strings.TrimSpace(*in.DefaultRouter)) > 0 {
		sysRolePo.DefaultRouter = *in.DefaultRouter
	}
	if in.Remark != nil && len(strings.TrimSpace(*in.Remark)) > 0 {
		sysRolePo.Remark = *in.Remark
	}
	if in.Sort != nil {
		uSort := new(int32)
		*uSort = int32(*in.Sort)
		sysRolePo.Status = uSort
	}

	sysRoleRepo := query.SysRole
	err := sysRoleRepo.WithContext(l.ctx).Create(sysRolePo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseIDResp{Id: uint64(sysRolePo.ID), Msg: admini18nconst.CreateSuccess}, nil
}
