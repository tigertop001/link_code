package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetUserByUsernameLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetUserByUsernameLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetUserByUsernameLogic {
	return &GetUserByUsernameLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: user
func (l *GetUserByUsernameLogic) GetUserByUsername(in *usercenter.UsernameReq) (*usercenter.UserInfo, error) {
	sysUserRepo := query.SysUser
	userResult, err := sysUserRepo.WithContext(l.ctx).Where(sysUserRepo.Username.Eq(in.Username)).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	var sysRoles []*model.SysRole
	if userResult != nil && len(userResult.ID) > 0 {
		sysRoleRepo := query.SysRole
		userRoleRepo := query.UserRole
		sysRoles, err = sysRoleRepo.WithContext(l.ctx).Select(sysRoleRepo.ALL, userRoleRepo.UserID).
			Join(userRoleRepo, userRoleRepo.RoleID.EqCol(sysRoleRepo.ID)).Where(userRoleRepo.UserID.In(userResult.ID)).Find()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		uDepartmentId := new(uint64)
		*uDepartmentId = uint64(*userResult.DepartmentID)
		uStatus := new(uint32)
		*uStatus = uint32(*userResult.Status)
		return &usercenter.UserInfo{
			Nickname:     &userResult.Nickname,
			Password:     &userResult.Password,
			RoleIds:      GetRoleIds(sysRoles),
			RoleCodes:    GetRoleCodes(sysRoles),
			Mobile:       userResult.Mobile,
			Email:        userResult.Email,
			Status:       uStatus,
			Id:           &userResult.ID,
			Username:     &userResult.Username,
			HomePath:     &userResult.HomePath,
			Description:  userResult.Description,
			DepartmentId: uDepartmentId,
			CreatedAt:    pointy.GetPointer(userResult.CreatedAt.UnixMilli()),
			UpdatedAt:    pointy.GetPointer(userResult.UpdatedAt.UnixMilli()),
		}, nil
	}
	return nil, errorxplus.DefaultGormError(l.Logger, err, in)
}

func GetRoleCodes(roles []*model.SysRole) []string {
	var codes []string
	for _, v := range roles {
		codes = append(codes, v.Code)
	}
	return codes
}

func GetPositionIds(sysPositions []*model.SysPosition) []uint64 {
	var ids []uint64
	for _, v := range sysPositions {
		ids = append(ids, uint64(v.ID))
	}
	return ids
}
