package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/smops"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type DeleteDepartmentLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDeleteDepartmentLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteDepartmentLogic {
	return &DeleteDepartmentLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: department
func (l *DeleteDepartmentLogic) DeleteDepartment(in *usercenter2.IDsReq) (*usercenter2.BaseResp, error) {

	result, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.Ids)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	sysDepartmentRepo := query.SysDepartment

	dCount, err := sysDepartmentRepo.WithContext(l.ctx).Where(sysDepartmentRepo.ParentID.In(result...)).Count()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	if dCount > 0 {
		logx.Errorw("delete department failed, please check its children had been deleted",
			logx.Field("departmentId", in.Ids))
		return nil, errorxplus.NewInvalidArgumentError("department.deleteDepartmentChildrenFirst")
	}

	sysUserRepo := query.SysUser
	uCount, err := sysUserRepo.WithContext(l.ctx).Where(sysUserRepo.DepartmentID.In(result...)).Count()

	if uCount > 0 {
		logx.Errorw("delete department failed, there are users belongs to the department", logx.Field("departmentId", in.Ids))
		return nil, errorxplus.NewInvalidArgumentError("department.deleteDepartmentUserFirst")
	}

	_, err = sysDepartmentRepo.WithContext(l.ctx).Where(sysDepartmentRepo.ID.In(result...)).Delete()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter2.BaseResp{Msg: admini18nconst.DeleteSuccess}, nil
}
