package model

type MenuRoleUn struct {
	SysMenu
	RoleMenu
}
