package main

import (
	"flag"
	"fmt"
	"github.com/zeromicro/go-zero/core/service"
	"user-admin-domain/user-apms-admin-api/internal/cron"

	"user-admin-domain/user-apms-admin-api/internal/config"
	"user-admin-domain/user-apms-admin-api/internal/handler"
	"user-admin-domain/user-apms-admin-api/internal/svc"

	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/rest"
)

var configFile = flag.String("f", "etc/conf.yaml", "the config filemgr")

func main() {
	flag.Parse()

	var c config.Config
	conf.MustLoad(*configFile, &c, conf.UseEnv())

	server := rest.MustNewServer(c.RestConf, rest.WithCors(c.CROSConf.Address))
	defer server.Stop()

	ctx := svc.NewServiceContext(c)
	handler.RegisterHandlers(server, ctx)

	fmt.Printf("Starting server at %s:%d...\n", c.Host, c.Port)

	group := service.ServiceGroup{}
	group.Add(server)
	if ctx.Config.ProjectConf.SyncEnabled {
		group.Add(cron.SyncHandler{
			SvcCtx:    ctx,
			Done:      make(chan struct{}, 1),
			FinishJob: make(chan struct{}, 1),
		})
	}
	defer group.Stop()
	server.Start()
}
