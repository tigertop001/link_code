package permission

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-apms-admin-api/internal/model"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetPermissionListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetPermissionListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetPermissionListLogic {
	return &GetPermissionListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetPermissionListLogic) GetPermissionList(req *types.PermissionListReq) (resp *types.PermissionListResp, err error) {
	db := l.svcCtx.DB
	if req.UserId != nil && len(strings.TrimSpace(*req.UserId)) > 0 {
		db = db.Where("userId = ? ", *req.UserId)
	}
	if req.Method != nil && len(strings.TrimSpace(*req.Method)) > 0 {
		db = db.Where("method Like ? ", "%"+*req.Method+"%")
	}
	if req.Path != nil && len(strings.TrimSpace(*req.Path)) > 0 {
		db = db.Where("path Like ? ", "%"+*req.Path+"%")
	}

	total := new(int64)
	err = db.Count(total).Error
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	} else {
		resp.Data.Total = uint64(*total)
	}

	resp.Msg = l.svcCtx.Trans.Trans(l.ctx, admini18nconst.Success)

	var apmsPermission []model.ApmsPermission
	offset := (req.Page - 1) * req.PageSize
	err = db.Offset(int(offset)).Limit(int(req.PageSize)).Find(&apmsPermission).Error
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}
	for _, v := range apmsPermission {
		uBalance := new(uint64)
		*uBalance = uint64(v.Balance)
		resp.Data.Data = append(resp.Data.Data,
			types.PermissionInfo{
				BaseUUIDInfo: types.BaseUUIDInfo{
					Id:        pointy.GetPointer(v.ID),
					CreatedAt: pointy.GetPointer(v.CreatedAt.UnixMilli()),
					UpdatedAt: pointy.GetPointer(v.UpdatedAt.UnixMilli()),
				},
				State:       v.State,
				UserId:      pointy.GetPointer(v.UserID),
				Method:      &v.Method,
				Path:        &v.Path,
				Balance:     uBalance,
				ServiceName: &v.ServiceName,
				ExpiredAt:   pointy.GetPointer(v.ExpiredAt.UnixMilli()),
			})
	}
	return resp, nil
}
