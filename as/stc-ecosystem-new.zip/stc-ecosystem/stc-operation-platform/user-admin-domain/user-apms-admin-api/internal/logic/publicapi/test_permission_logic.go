package publicapi

import (
	"context"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type TestPermissionLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewTestPermissionLogic(ctx context.Context, svcCtx *svc.ServiceContext) *TestPermissionLogic {
	return &TestPermissionLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *TestPermissionLogic) TestPermission() (resp *types.BaseMsgResp, err error) {
	return &types.BaseMsgResp{
		Code: 0,
		Msg:  "success",
	}, nil

}
