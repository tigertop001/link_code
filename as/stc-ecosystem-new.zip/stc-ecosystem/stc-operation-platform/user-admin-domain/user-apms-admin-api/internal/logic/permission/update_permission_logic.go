package permission

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"time"
	"user-admin-domain/user-apms-admin-api/internal/logic/operationlog"
	"user-admin-domain/user-apms-admin-api/internal/model"
	"user-admin-domain/user-apms-admin-api/internal/query"
	"user-admin-domain/user-apms-admin-api/internal/utils/permdata"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdatePermissionLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewUpdatePermissionLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdatePermissionLogic {
	return &UpdatePermissionLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *UpdatePermissionLogic) UpdatePermission(req *types.PermissionInfo) (resp *types.BaseMsgResp, err error) {

	apmsPermissionRepo := query.ApmsPermission

	check, err := apmsPermissionRepo.WithContext(l.ctx).Where(apmsPermissionRepo.ID.In(*req.Id)).Last()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}

	apmsPermissionPo := new(model.ApmsPermission)
	if req.State != nil {
		apmsPermissionPo.State = req.State
	}
	if req.UserId != nil && len(strings.TrimSpace(*req.UserId)) > 0 {
		apmsPermissionPo.UserID = *req.UserId
	}
	if req.Method != nil && len(strings.TrimSpace(*req.Method)) > 0 {
		apmsPermissionPo.Method = *req.Method
	}

	if req.Path != nil && len(strings.TrimSpace(*req.Path)) > 0 {
		apmsPermissionPo.Path = *req.Path
	}
	if req.Balance != nil {
		apmsPermissionPo.Balance = int64(*req.Balance)
	}
	if req.ExpiredAt != nil {

		apmsPermissionPo.ExpiredAt = time.UnixMilli(*req.ExpiredAt)
	}
	if req.ServiceName != nil && len(strings.TrimSpace(*req.ServiceName)) > 0 {
		apmsPermissionPo.ServiceName = *req.ServiceName
	}

	_, err = apmsPermissionRepo.WithContext(l.ctx).Where(apmsPermissionRepo.ID.Eq(*req.Id)).Updates(apmsPermissionPo)

	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}
	// update redis
	err = permdata.SetUserApiBalance(l.svcCtx.Redis, *req.UserId, *req.Method, *req.Path, *req.ServiceName, *req.Balance)
	if err != nil {
		return nil, err
	}

	operatorId := new(string)
	if l.ctx.Value("userId") == nil {
		*operatorId = ""
		logx.Error("userid absent")
	} else {
		*operatorId = l.ctx.Value("userId").(string)
	}
	if req.Balance != nil {
		operatorId := l.ctx.Value("userId").(string)
		var remark string
		diff := int(*req.Balance) - int(check.Balance)

		if diff > 0 {
			remark = "Increase"
		} else {
			remark = "Decrease"
		}

		_, err = operationlog.NewCreateOperationLogLogic(l.ctx, l.svcCtx).CreateOperationLog(&types.OperationLogInfo{
			UserId:       req.UserId,
			OperatorId:   &operatorId,
			PermissionId: req.Id,
			Change:       &diff,
			Remark:       &remark,
		})

		if err != nil {
			return nil, err
		}
	}
	return &types.BaseMsgResp{Msg: l.svcCtx.Trans.Trans(l.ctx, admini18nconst.UpdateSuccess)}, nil
}
