package permission

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-apms-admin-api/internal/query"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetPermissionByIdLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetPermissionByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetPermissionByIdLogic {
	return &GetPermissionByIdLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetPermissionByIdLogic) GetPermissionById(req *types.UUIDReq) (resp *types.PermissionInfoResp, err error) {
	apmsPermissionRepo := query.ApmsPermission

	data, err := apmsPermissionRepo.WithContext(l.ctx).Where(apmsPermissionRepo.ID.Eq(req.Id)).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}
	uBalance := new(uint64)
	*uBalance = uint64(data.Balance)
	return &types.PermissionInfoResp{
		BaseDataInfo: types.BaseDataInfo{
			Code: 0,
			Msg:  l.svcCtx.Trans.Trans(l.ctx, admini18nconst.Success),
		},
		Data: types.PermissionInfo{
			BaseUUIDInfo: types.BaseUUIDInfo{
				Id:        pointy.GetPointer(data.ID),
				CreatedAt: pointy.GetPointer(data.CreatedAt.UnixMilli()),
				UpdatedAt: pointy.GetPointer(data.UpdatedAt.UnixMilli()),
			},
			State:       data.State,
			UserId:      pointy.GetPointer(data.UserID),
			Method:      &data.Method,
			Path:        &data.Path,
			ServiceName: &data.ServiceName,
			ExpiredAt:   pointy.GetPointer(data.ExpiredAt.UnixMilli()),
			Balance:     uBalance,
		},
	}, nil
}
