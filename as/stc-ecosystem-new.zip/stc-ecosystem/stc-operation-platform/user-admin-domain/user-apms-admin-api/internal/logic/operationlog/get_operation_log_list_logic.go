package operationlog

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-apms-admin-api/internal/model"
	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetOperationLogListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetOperationLogListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetOperationLogListLogic {
	return &GetOperationLogListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetOperationLogListLogic) GetOperationLogList(req *types.OperationLogListReq) (resp *types.OperationLogListResp, err error) {

	db := l.svcCtx.DB
	if req.UserId != nil && len(strings.TrimSpace(*req.UserId)) > 0 {
		db = db.Where("userId = ?", *req.UserId)
	}

	if req.OperatorId != nil && len(strings.TrimSpace(*req.OperatorId)) > 0 {
		db = db.Where("operatorId = ?", *req.OperatorId)
	}

	if req.ServiceName != nil && len(strings.TrimSpace(*req.ServiceName)) > 0 {
		serviceNameSubQuery := db.Select("id").Where("service_name LIKE ?", "%"+*req.ServiceName+"%").Table("apms_permission")
		db = db.Where("permission_id IN ()", serviceNameSubQuery)
	}
	if req.Path != nil && len(strings.TrimSpace(*req.Path)) > 0 {
		pathSubQuery := db.Select("id").Where("path LIKE ?", "%"+*req.Path+"%").Table("apms_permission")

		db = db.Where("permission_id IN ()", pathSubQuery)
	}

	total := new(int64)
	err = db.Count(total).Error
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	} else {
		resp.Data.Total = uint64(*total)
	}
	var apmsLog []model.ApmsOperationLog
	offset := (req.Page - 1) * req.PageSize
	err = db.Offset(int(offset)).Limit(int(req.PageSize)).Find(&apmsLog).Error
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}
	resp.Msg = l.svcCtx.Trans.Trans(l.ctx, admini18nconst.Success)

	for _, v := range apmsLog {
		changeInt := int(v.Change)
		resp.Data.Data = append(resp.Data.Data,
			types.OperationLogInfo{
				BaseUUIDInfo: types.BaseUUIDInfo{
					Id:        pointy.GetPointer(v.ID),
					CreatedAt: pointy.GetPointer(v.CreatedAt.UnixMilli()),
					UpdatedAt: pointy.GetPointer(v.UpdatedAt.UnixMilli()),
				},
				UserId:       pointy.GetPointer(v.UserID),
				OperatorId:   pointy.GetPointer(v.OperatorID),
				PermissionId: pointy.GetPointer(v.PermissionID),
				Change:       &changeInt,
				Remark:       v.Remark,
			})
	}
	return resp, nil
}
