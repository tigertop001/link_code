package permission

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-apms-admin-api/internal/query"
	"user-admin-domain/user-apms-admin-api/internal/utils/permdata"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type DeletePermissionLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewDeletePermissionLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeletePermissionLogic {
	return &DeletePermissionLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *DeletePermissionLogic) DeletePermission(req *types.UUIDsReq) (resp *types.BaseMsgResp, err error) {
	err = query.Q.Transaction(func(tx *query.Query) error {
		check, err := tx.ApmsPermission.WithContext(l.ctx).Where(tx.ApmsPermission.ID.In(req.Ids...)).Find()
		if err != nil {
			return errorxplus.DefaultGormError(l.Logger, err, req)
		}
		_, err = tx.ApmsPermission.WithContext(l.ctx).Where(tx.ApmsPermission.ID.In(req.Ids...)).Delete()
		if err != nil {
			return errorxplus.DefaultGormError(l.Logger, err, req)
		}
		for _, v := range check {
			err := permdata.DelUserApiBalance(l.svcCtx.Redis, v.UserID, v.Method, v.Path, v.ServiceName)
			if err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return &types.BaseMsgResp{Msg: l.svcCtx.Trans.Trans(l.ctx, admini18nconst.DeleteSuccess)}, nil
}
