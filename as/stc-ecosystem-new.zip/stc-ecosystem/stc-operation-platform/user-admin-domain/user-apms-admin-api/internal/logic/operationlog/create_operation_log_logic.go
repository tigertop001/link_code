package operationlog

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-apms-admin-api/internal/model"
	"user-admin-domain/user-apms-admin-api/internal/query"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateOperationLogLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCreateOperationLogLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateOperationLogLogic {
	return &CreateOperationLogLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *CreateOperationLogLogic) CreateOperationLog(req *types.OperationLogInfo) (resp *types.BaseMsgResp, err error) {

	apmsOperationLog := new(model.ApmsOperationLog)

	if req.UserId != nil && len(strings.TrimSpace(*req.UserId)) > 0 {
		apmsOperationLog.UserID = *req.UserId
	}

	if req.OperatorId != nil && len(strings.TrimSpace(*req.OperatorId)) > 0 {
		apmsOperationLog.OperatorID = *req.OperatorId
	}

	if req.Change != nil {
		apmsOperationLog.Change = int64(*req.Change)
	}

	if req.Remark != nil && len(strings.TrimSpace(*req.Remark)) > 0 {
		apmsOperationLog.Remark = req.Remark
	}

	if req.PermissionId != nil && len(strings.TrimSpace(*req.PermissionId)) > 0 {
		apmsOperationLog.PermissionID = *req.PermissionId
	}

	apmsOperationLogRepo := query.ApmsOperationLog
	err = apmsOperationLogRepo.WithContext(l.ctx).Create(apmsOperationLog)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}

	return &types.BaseMsgResp{
		Msg: l.svcCtx.Trans.Trans(l.ctx, admini18nconst.Success),
	}, nil
}
