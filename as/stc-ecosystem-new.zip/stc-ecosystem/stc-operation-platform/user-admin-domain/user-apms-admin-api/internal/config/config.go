package config

import (
	"github.com/zeromicro/go-zero/rest"
	"github.com/zeromicro/go-zero/zrpc"
	"global-admin-common/config"
	"global-admin-common/plugins/casbin"
)

type Config struct {
	rest.RestConf
	CROSConf           config.CROSConf
	CasbinDatabaseConf config.DatabaseConf
	RedisConf          config.RedisConf
	CasbinConf         casbin.CasbinConf
	UserCenterRpc      zrpc.RpcClientConf
	ProjectConf        ProjectConf
	Auth               struct {
		AccessSecret string
		AccessExpire int64
	}

	DatabaseConf struct {
		Datasource string
	}
}

type ProjectConf struct {
	SyncTime    int    `json:",default=60"`
	Batch       uint64 `json:",default=100"`
	BatchTime   int    `json:",default=100"`
	SyncEnabled bool   `json:",default=false"`
	ServiceName string `json:",optional"`
}
