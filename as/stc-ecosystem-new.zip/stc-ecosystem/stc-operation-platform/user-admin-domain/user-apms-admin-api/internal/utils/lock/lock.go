package lock

import (
	"context"
	"errors"
	"fmt"
	"github.com/redis/go-redis/v9"
	"global-admin-common/config"
	"time"
)

func IsLock(r redis.UniversalClient, userId string) bool {
	err := r.Get(context.Background(), GetLockKey(userId)).Err()
	if errors.Is(err, redis.Nil) {
		return false
	}
	return true
}

func Lock(r redis.UniversalClient, userId string) error {
	err := r.Set(context.Background(), GetLockKey(userId), true, 2*time.Minute).Err()
	return err
}

func UnLock(r redis.UniversalClient, userId string) error {
	err := r.Del(context.Background(), GetLockKey(userId)).Err()
	return err
}

func GetLockKey(userId string) string {
	return fmt.Sprintf("%sLOCK:%s", config.RedisApiPermissionCountPrefix, userId)
}
