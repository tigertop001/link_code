package cron

import (
	"context"
	"errors"
	"fmt"
	"github.com/redis/go-redis/v9"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/gormutils"
	"global-admin-common/utils/errorxplus"
	"time"
	"user-admin-domain/user-apms-admin-api/internal/model"
	"user-admin-domain/user-apms-admin-api/internal/query"
	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/utils/lock"
	"user-admin-domain/user-apms-admin-api/internal/utils/permdata"
)

type SyncHandler struct {
	Done      chan struct{}
	FinishJob chan struct{}
	SvcCtx    *svc.ServiceContext
}

func (l SyncHandler) Start() {

	var pageSize uint64 = 100

	logx.Info("sync job started")

	go func() {
		var stopFlag bool

		for {
			if stopFlag {
				logx.Info("sync job stopped")
				return
			}

			logx.Info("sync database data ...")

			pageSize = l.SvcCtx.Config.ProjectConf.Batch

			permissionRepo := query.ApmsPermission
			ctx := context.Background()

			total, err := permissionRepo.WithContext(ctx).Count()
			if err != nil {
				err = errorxplus.DefaultGormError(logx.WithContext(ctx), err, nil)
				logx.Must(err)
			}

			var apmsPermissions []model.ApmsPermission

			for i := 1; i <= int(total)/int(pageSize)+1; i++ {
				err := l.SvcCtx.DB.WithContext(ctx).
					Where(permissionRepo.Balance.Gt(0)).
					Where(permissionRepo.State.Is(true)).
					Scopes(gormutils.Paginate(i, int(pageSize))).Find(&apmsPermissions).Error
				if err != nil {
					err = errorxplus.DefaultGormError(logx.WithContext(ctx), err, nil)
					logx.Must(err)
				}

				for _, v := range apmsPermissions {
					balance, err := permdata.GetUserApiBalance(l.SvcCtx.Redis, v.UserID, v.Method, v.Path, v.ServiceName)
					if err != nil && !errors.Is(err, redis.Nil) {
						logx.Must(fmt.Errorf("redis error: %s", err.Error()))
					} else if errors.Is(err, redis.Nil) {
						err := permdata.SetUserApiBalance(l.SvcCtx.Redis, v.UserID, v.Method, v.Path, v.ServiceName, uint64(v.Balance))
						if err != nil {
							logx.Must(fmt.Errorf("redis error: %s", err.Error()))
						}
					}

					if time.Since(v.ExpiredAt).Seconds() > 0 {
						err := permdata.DelUserApiBalance(l.SvcCtx.Redis, v.UserID, v.Method, v.Path, v.ServiceName)
						if err != nil {
							logx.Must(fmt.Errorf("redis error: %s", err.Error()))
						}

						if *v.State {
							count, err := permissionRepo.WithContext(ctx).Where(permissionRepo.UserID.Eq(v.UserID)).Count()
							if err != nil {
								logx.Must(fmt.Errorf("redis error: %s", err.Error()))
							}
							if count > 0 {
								_, err := permissionRepo.WithContext(ctx).Where(permissionRepo.UserID.Eq(v.UserID)).Update(permissionRepo.State, false)
								if err != nil {
									logx.Must(errorxplus.DefaultGormError(logx.WithContext(ctx), err, nil))
								}
							}
						}
					} else {
						if lock.IsLock(l.SvcCtx.Redis, v.UserID) {
							time.Sleep(3 * time.Second)
						} else {
							err = lock.Lock(l.SvcCtx.Redis, v.UserID)
							logx.Must(err)
						}

						if int64(balance) < v.Balance {
							_, err := permissionRepo.WithContext(ctx).Where(permissionRepo.UserID.Eq(v.UserID)).Update(permissionRepo.Balance, balance)
							if err != nil {
								logx.Must(errorxplus.DefaultGormError(logx.WithContext(ctx), err, nil))
							}
						} else if int64(balance) > v.Balance {
							if err := permdata.SetUserApiBalance(l.SvcCtx.Redis, v.UserID, v.Method, v.Path, v.ServiceName, uint64(v.Balance)); err != nil {
								logx.Must(fmt.Errorf("redis error: %s", err.Error()))
							}
						}
						_ = lock.UnLock(l.SvcCtx.Redis, v.UserID)
					}
					time.Sleep(10 * time.Microsecond)
				}
				time.Sleep(time.Duration(l.SvcCtx.Config.ProjectConf.BatchTime) * time.Second)
				l.FinishJob <- struct{}{}

			}
			select {
			case <-l.Done:
				stopFlag = true
			case <-l.FinishJob:
			}
			logx.Info("finish sync")
			time.Sleep(time.Duration(l.SvcCtx.Config.ProjectConf.SyncTime) * time.Minute)
		}

	}()
}

func (l SyncHandler) Stop() {
	l.Done <- struct{}{}
	defer close(l.Done)
	defer close(l.FinishJob)
}
