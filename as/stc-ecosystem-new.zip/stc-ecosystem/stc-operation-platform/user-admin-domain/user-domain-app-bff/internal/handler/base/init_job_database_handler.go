package base

import (
	"net/http"

	"github.com/zeromicro/go-zero/rest/httpx"
	"user-admin-domain/user-domain-app-bff/internal/logic/base"
	"user-admin-domain/user-domain-app-bff/internal/svc"
)

func InitJobDatabaseHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		l := base.NewInitJobDatabaseLogic(r.Context(), svcCtx)
		resp, err := l.InitJobDatabase()
		if err != nil {
			err = svcCtx.Trans.TransError(r.Context(), err)
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
