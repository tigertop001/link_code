package dictionary

import (
	"net/http"

	"github.com/zeromicro/go-zero/rest/httpx"
	"user-admin-domain/user-domain-app-bff/internal/logic/dictionary"
	"user-admin-domain/user-domain-app-bff/internal/svc"
	"user-admin-domain/user-domain-app-bff/internal/types"
)

func CreateDictionaryHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.DictionaryInfo
		if err := httpx.Parse(r, &req); err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
			return
		}

		l := dictionary.NewCreateDictionaryLogic(r.Context(), svcCtx)
		resp, err := l.CreateDictionary(&req)
		if err != nil {
			err = svcCtx.Trans.TransError(r.Context(), err)
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
