package middleware

import (
	"github.com/go-saas/saas"
	"github.com/go-saas/saas/data"
	"net/http"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/tim/contrib"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/tim/mtguard"
)

type TenantGuardMiddleware struct {
	TenantStore saas.TenantStore
	MtgOption   *mtguard.SOption
}

func NewTenantGuardMiddleware() *TenantGuardMiddleware {

	SOption := &mtguard.SOption{
		HmtOpt:  mtguard.NewDefaultWebMultiTenancyOption(),
		Ef:      mtguard.DefaultErrorFormatter,
		Resolve: nil,
	}

	return &TenantGuardMiddleware{
		MtgOption: SOption,
	}
}

func (m *TenantGuardMiddleware) Handle(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		// TODO redis获取租户配置 -》redis 数据来源通过监听方式实时存储最新租户信息
		tenantStore := saas.NewMemoryTenantStore(
			[]saas.TenantConfig{
				//{ID: "tenantA", Name: "tenantA"},
				//{ID: "tenantB", Name: "tenantB"},
			})

		var trOpt []saas.ResolveOption
		df := []saas.TenantResolveContrib{
			contrib.NewCookieTenantResolveContrib(m.MtgOption.HmtOpt.TenantKey, r),
			contrib.NewFormTenantResolveContrib(m.MtgOption.HmtOpt.TenantKey, r),
			contrib.NewHeaderTenantResolveContrib(m.MtgOption.HmtOpt.TenantKey, r),
			contrib.NewQueryTenantResolveContrib(m.MtgOption.HmtOpt.TenantKey, r),
		}

		if m.MtgOption.HmtOpt.DomainFormat != "" {
			df = append(df, contrib.NewDomainTenantResolveContrib(m.MtgOption.HmtOpt.DomainFormat, r))
		}
		df = append(df, saas.NewTenantNormalizerContrib(tenantStore))
		trOpt = append(trOpt, saas.AppendContribs(df...))
		trOpt = append(trOpt, m.MtgOption.Resolve...)

		tenantConfigProvider := saas.NewDefaultTenantConfigProvider(saas.NewDefaultTenantResolver(trOpt...), tenantStore)
		tenantConfig, ctx, err := tenantConfigProvider.Get(r.Context())
		if err != nil {
			m.MtgOption.Ef(w, err)
		}

		newContext := saas.NewCurrentTenant(ctx, tenantConfig.ID, tenantConfig.Name)
		newContext = data.NewMultiTenancyDataFilter(newContext)
		next(w, r.WithContext(newContext))
	}
}
