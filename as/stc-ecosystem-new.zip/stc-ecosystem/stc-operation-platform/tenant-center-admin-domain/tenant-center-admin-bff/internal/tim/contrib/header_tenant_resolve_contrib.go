package contrib

import (
	"github.com/go-saas/saas"
	"net/http"
)

type HeaderTenantResolveContrib struct {
	Key     string
	request *http.Request
}

func NewHeaderTenantResolveContrib(key string, r *http.Request) *HeaderTenantResolveContrib {
	return &HeaderTenantResolveContrib{
		Key:     key,
		request: r,
	}
}

func (h *HeaderTenantResolveContrib) Name() string {
	return "Header"
}

func (h *HeaderTenantResolveContrib) Resolve(ctx *saas.Context) error {
	v := h.request.Header.Get(h.Key)
	if v == "" {
		return nil
	}
	ctx.TenantIdOrName = v
	return nil
}
