package contrib

import (
	"github.com/go-saas/saas"
	"net/http"
)

type QueryTenantResolveContrib struct {
	Key     string
	request *http.Request
}

func NewQueryTenantResolveContrib(key string, r *http.Request) *QueryTenantResolveContrib {
	return &QueryTenantResolveContrib{
		Key:     key,
		request: r,
	}
}

func (q *QueryTenantResolveContrib) Name() string {
	return "Query"
}

func (q *QueryTenantResolveContrib) Resolve(ctx *saas.Context) error {
	v := q.request.URL.Query().Get(q.Key)
	if v == "" {
		return nil
	}
	ctx.TenantIdOrName = v
	return nil
}
