package mtguard

import (
	"errors"
	"github.com/go-saas/saas"
	"net/http"
)

type ErrorFormatter func(w http.ResponseWriter, err error)

var (
	DefaultErrorFormatter ErrorFormatter = func(w http.ResponseWriter, err error) {
		if errors.Is(err, saas.ErrTenantNotFound) {
			http.Error(w, "Not Found", http.StatusNotFound)
		} else {
			http.Error(w, err.Error(), http.StatusInternalServerError)
		}
	}
)

type SOption struct {
	HmtOpt  *WebMultiTenancyOption
	Ef      ErrorFormatter
	Resolve []saas.ResolveOption
}

type Option func(*SOption)

func WithMultiTenancyOption(opt *WebMultiTenancyOption) Option {
	return func(o *SOption) {
		o.HmtOpt = opt
	}
}

func WithErrorFormatter(e ErrorFormatter) Option {
	return func(o *SOption) {
		o.Ef = e
	}
}

func WithResolveOption(opts ...saas.ResolveOption) Option {
	return func(o *SOption) {
		o.Resolve = opts
	}
}

func DefaultMultiTenantOption(options ...Option) *SOption {
	opt := &SOption{
		HmtOpt:  NewDefaultWebMultiTenancyOption(),
		Ef:      DefaultErrorFormatter,
		Resolve: nil,
	}

	for _, o := range options {
		o(opt)
	}
	return opt
}
