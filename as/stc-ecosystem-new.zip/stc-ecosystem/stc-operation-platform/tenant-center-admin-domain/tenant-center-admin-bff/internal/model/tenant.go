package model

import (
	"gorm.io/gorm"
	"time"
)

const TableNameTenant = "tenant"

type Tenant struct {
	ID          string `sql:"type:char(36)" json:"id"`
	Name        string `sql:"column:name;index;size:255;"`
	DisplayName string `sql:"column:display_name;index;size:255;"`
	Region      string `sql:"column:region;index;size:255;"`
	Logo        string
	PlanKey     string
	SeparateDb  bool           `sql:"column:separate_db"`
	CreatedAt   time.Time      `sql:"column:created_at;index;"`
	UpdatedAt   time.Time      `sql:"column:updated_at;index;"`
	DeletedAt   gorm.DeletedAt `sql:"column:deleted_at;index;"`
	Conn        []TenantConn   `sql:"foreignKey:TenantId"`
}

func (*Tenant) TableName() string {
	return TableNameTenant
}
