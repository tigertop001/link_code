package model

import "time"

const TableNameTenantConn = "tenant_conn"

type TenantConn struct {
	//column:tenant_id;type:char(36);primaryKey;size:36;
	TenantId string `gorm:"column:tenant_id;type:char(36);primary_key;size:36;"`
	//key of connection string
	Key string `gorm:"column:key;type:char(100);primary_key;size:100;"`
	//connection string
	Value     string    `gorm:"column:value;size:1000;"`
	CreatedAt time.Time `gorm:"column:created_at;index;"`
	UpdatedAt time.Time `gorm:"column:updated_at;index;"`
}

func (*TenantConn) TableName() string {
	return TableNameTenantConn
}
