package tenant

import (
	"context"

	"tenant-center-admin-domain/tenant-center-admin-bff/internal/svc"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetTenantByIdReqLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetTenantByIdReqLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetTenantByIdReqLogic {
	return &GetTenantByIdReqLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetTenantByIdReqLogic) GetTenantByIdReq(req *types.GetTenantByIdReq) (resp *types.BaseMsgResp, err error) {
	// todo: add your logic here and delete this line

	return
}
