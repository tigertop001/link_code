package dtmsrv

import (
	"database/sql"
	"github.com/dtm-labs/client/dtmcli"
	"github.com/dtm-labs/client/dtmcli/dtmimp"
	"github.com/dtm-labs/client/dtmcli/logger"
	"github.com/dtm-labs/client/workflow"
	"github.com/lithammer/shortuuid/v3"
	dtmCodec "global-admin-common/addcommand"
)

type commandInfo struct {
	Arg    string
	Action func() string
	Desc   string
}

var Commands = []commandInfo{}

func AddCommand(arg, desc string, fn func() string) {
	Commands = append(Commands, commandInfo{Arg: arg, Desc: desc, Action: fn})
}

var db *sql.DB

func AddCommands() {
	AddCommand("http_worflow_saga_barrier", "trans_orchestration", func() string {
		wfName := "hi_dtm"
		err := workflow.Register(wfName, func(wf *workflow.Workflow, data []byte) error {
			req := dtmCodec.MustUnmarshalReqGrpc(data)

			_, err := wf.NewBranch().OnRollback(func(bb *dtmcli.BranchBarrier) error {
				err := bb.CallWithDB(db, func(tx *sql.Tx) error {
					_, err := wf.NewRequest().SetBody(req).Post("discover://" + "/TransOutRevert")
					return err
				})
				if err != nil {
					return err
				}
				return nil
			}).NewRequest().SetBody(req).Post("discover://" + "/TransOut")
			if err != nil {
				return err
			}
			_, err = wf.NewBranch().OnRollback(func(bb *dtmcli.BranchBarrier) error {
				err = bb.CallWithDB(db, func(tx *sql.Tx) error {
					_, err := wf.NewRequest().SetBody(req).Post("discover://" + "/SagaBTransInCom")
					return err
				})
				if err != nil {
					return err
				}
				return nil
			}).NewRequest().SetBody(req).Post("discover://" + "/SagaBTransIn")
			if err != nil {
				return err
			}
			return nil
		})
		if err != nil {
			return "failed"
		}
		req := &ReqHTTP{Amount: 30, TransInResult: dtmcli.ResultFailure}
		gid := shortuuid.New()
		err = workflow.Execute(wfName, gid, dtmimp.MustMarshal(req))
		logger.Infof("result is: %v", err)
		return gid
	})
	AddCommand("hi2", "hi2", func() string {
		return "hi2"
	})
}

type ReqHTTP struct {
	Amount        int64
	TransInResult string
}
