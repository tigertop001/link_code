package tenant

import (
	"github.com/dtm-labs/client/dtmcli/logger"
	"github.com/dtm-labs/client/workflow"
	"github.com/zeromicro/go-zero/rest/httpx"
	"io"
	"net/http"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/svc"
)

func GetDtmResumeHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		wrapHttpBody, err := io.ReadAll(r.Body)
		logger.FatalIfError(err)
		err = workflow.ExecuteByQS(r.URL.Query(), wrapHttpBody)
		if err != nil {
			if err != nil {
				err = svcCtx.Trans.TransError(r.Context(), err)
				httpx.ErrorCtx(r.Context(), w, err)
			} else {
				httpx.OkJsonCtx(r.Context(), w, string(wrapHttpBody))
			}
		}
	}
}
