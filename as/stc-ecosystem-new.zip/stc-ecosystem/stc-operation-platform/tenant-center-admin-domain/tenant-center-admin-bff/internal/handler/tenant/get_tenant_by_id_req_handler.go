package tenant

import (
	"net/http"

	"github.com/zeromicro/go-zero/rest/httpx"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/logic/tenant"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/svc"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/types"
)

func GetTenantByIdReqHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.GetTenantByIdReq
		if err := httpx.Parse(r, &req); err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
			return
		}

		l := tenant.NewGetTenantByIdReqLogic(r.Context(), svcCtx)
		resp, err := l.GetTenantByIdReq(&req)
		if err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
