package svc

import (
	"github.com/zeromicro/go-zero/rest"
	"global-admin-common/i18n"
	"global-admin-common/nacos/confmgr"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/config"
	i18n2 "tenant-center-admin-domain/tenant-center-admin-bff/internal/i18n"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/middleware"
	tenantcenterclient "tenant-center-admin-domain/tenant-center-admin-dependency/tenantcenter_client"
)

type ServiceContext struct {
	Config          config.Config
	TenantGuard     rest.Middleware
	TenantCenterRpc tenantcenterclient.Tenantcenter
	Trans           *i18n.Translator
}

func NewServiceContext(c config.Config, nc *confmgr.NacosConf) *ServiceContext {
	trans := i18n.NewTranslator(i18n2.LocaleFS)
	return &ServiceContext{
		Config:          c,
		TenantGuard:     middleware.NewTenantGuardMiddleware().Handle,
		TenantCenterRpc: tenantcenterclient.NewTenantcenter(nc.NewZrpcClient(c.TenantCenterRpc, c.Name)),
		Trans:           trans,
	}
}
