package config

import (
	"github.com/zeromicro/go-zero/rest"
	"global-admin-common/config"
)

type Config struct {
	rest.RestConf
	TenantCenterRpc string
	DtmGrpcConf     config.DtmGrpcConf
	DatabaseConf    struct {
		Datasource string
	}
}
