package dtmsrv

import (
	"database/sql"
	"github.com/dtm-labs/client/dtmcli"
	"github.com/dtm-labs/client/dtmcli/dtmimp"
	"github.com/dtm-labs/client/dtmcli/logger"
	"github.com/dtm-labs/client/dtmgrpc/dtmgimp"
	"github.com/dtm-labs/client/workflow"
	"github.com/dtm-labs/dtm-examples/busi"
	"github.com/lithammer/shortuuid/v3"
)

func MustUnmarshalReqGrpc(data []byte) *busi.ReqGrpc {
	var req busi.ReqGrpc
	dtmgimp.MustProtoUnmarshal(data, &req)
	return &req
}

func MustUnmarshalReqHTTP(data []byte) *busi.ReqHTTP {
	var req busi.ReqHTTP
	dtmimp.MustUnmarshal(data, &req)
	return &req
}

/*
*

		customx := func(wf *wftemplate.Workflow) {
		         xxxx
		  }
		 custom = append(custom, customx)

	   Register(name string, handler WfFunc, custom ...func(wf *Workflow))

*
*/
func TenantWorkflow(transInfo string, wfName string, db *sql.DB) string {
	// Todo 把WfFunc或WfFunc2提取出来， func(wf *Workflow)) 提取出来
	err := workflow.Register(wfName, func(wf *workflow.Workflow, data []byte) error {
		req := MustUnmarshalReqGrpc(data)
		wf.NewBranch().OnRollback(func(bb *dtmcli.BranchBarrier) error {
			err := bb.CallWithDB(db, func(tx *sql.Tx) error {
				_, err := busi.BusiCli.TransOutRevertBSaga(wf.Context, req)
				return err
			})
			if err != nil {
				return err
			}
			return nil
		})
		_, err := busi.BusiCli.TransOutBSaga(wf.Context, req)
		if err != nil {
			return err
		}
		wf.NewBranch().OnRollback(func(bb *dtmcli.BranchBarrier) error {
			err := bb.CallWithDB(db, func(tx *sql.Tx) error {
				_, err := busi.BusiCli.TransInRevertBSaga(wf.Context, req)
				return err
			})
			if err != nil {
				return err
			}
			return nil
		})
		_, err = busi.BusiCli.TransInBSaga(wf.Context, req)
		return err
	})
	logger.FatalIfError(err)

	req := &busi.ReqGrpc{Amount: 30}
	gid := shortuuid.New()
	err = workflow.Execute(wfName, gid, dtmgimp.MustProtoMarshal(req))
	logger.FatalIfError(err)
	return gid
}
