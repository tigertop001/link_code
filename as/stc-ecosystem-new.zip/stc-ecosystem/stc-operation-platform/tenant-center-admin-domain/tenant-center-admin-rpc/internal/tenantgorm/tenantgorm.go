package tenantgorm

import (
	"context"
	"database/sql"
	"fmt"
	"github.com/go-saas/saas"
	"github.com/go-saas/saas/data"
	sgorm "github.com/go-saas/saas/gorm"
	mysql2 "github.com/go-sql-driver/mysql"
	"github.com/zeromicro/go-zero/core/logx"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

type SqlDbCache struct {
	cache *saas.Cache[string, *sgorm.DbWrap]
}

func NewSqlDbCache() (*SqlDbCache, func()) {
	c := saas.NewCache[string, *sgorm.DbWrap]()
	return &SqlDbCache{cache: c}, func() {
		defer func() {
			if err := c.Flush(); err != nil {
				logx.Errorw("db cache flush error", logx.Field("detail", err.Error()))
			}
		}()
	}
}

func ClientProviderGormFunc(cache *saas.Cache[string, *sgorm.DbWrap], fuc func(s string) error) saas.ClientProviderFunc[*gorm.DB] {
	return func(ctx context.Context, s string) (*gorm.DB, error) {
		client, _, err := cache.GetOrSet(s, func() (*sgorm.DbWrap, error) {

			if fuc != nil {
				if err := fuc(s); err != nil {
					return nil, err
				}
			}
			var client *gorm.DB
			var err error
			db, err := sql.Open("mysql", s)
			if err != nil {
				return nil, err
			}
			client, err = gorm.Open(mysql.New(mysql.Config{
				Conn: db,
			}))
			return sgorm.NewDbWrap(client), err
		})
		if err != nil {
			return nil, err
		}
		return client.WithContext(ctx).Debug(), err
	}
}

type EnsureDbExistFunc func(string) error

func EnsureDbExistGormFunc(s string) error {
	dsn, err := mysql2.ParseDSN(s)
	if err != nil {
		return err
	}
	dbname := dsn.DBName
	dsn.DBName = ""

	db, err := sql.Open("mysql", dsn.FormatDSN())
	if err != nil {
		return err
	}
	_, err = db.ExecContext(context.Background(), fmt.Sprintf("CREATE DATABASE IF NOT EXISTS `%s`", dbname))
	if err != nil {
		return err
	}
	return db.Close()
}

func ConnstrGen(dataSource string) saas.ConnStrGenerator {
	var connStrGen saas.ConnStrGenerator
	dd, err := mysql2.ParseDSN(dataSource)
	if err != nil {
		panic(err)
	}

	hostDbName := dd.DBName
	dd.DBName = hostDbName + "-%s"
	connStrGen = saas.NewConnStrGenerator(dd.FormatDSN())
	return connStrGen
}

func GormDbProvider(dataSource string) sgorm.DbProvider {
	DBConCache := saas.NewCache[string, *sgorm.DbWrap](saas.WithCapacity(512))
	defer func() {
		if err := DBConCache.Flush(); err != nil {
			logx.Errorw("db conn cache", logx.Field("detail", err))
		}
	}()

	EnsureDbExist := EnsureDbExistGormFunc

	conn := make(data.ConnStrings, 1)
	conn.SetDefault(dataSource)

	ClientProvider := sgorm.ClientProviderFunc(ClientProviderGormFunc(DBConCache, EnsureDbExist))
	tenantStore := &TenantStore{DbProvider: sgorm.NewDbProvider(conn, ClientProvider)}

	mr := saas.NewMultiTenancyConnStrResolver(tenantStore, conn)
	return sgorm.NewDbProvider(mr, ClientProvider)
}
