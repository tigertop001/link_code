package tenantgorm

import (
	"context"
	"errors"
	"github.com/go-saas/saas"
	sgorm "github.com/go-saas/saas/gorm"
	"gorm.io/gorm"
	"tenant-center-admin-domain/tenant-center-admin-rpc/internal/model"
	"time"
)

type Tenant struct {
	ID          string `sql:"type:char(36)" json:"id"`
	Name        string `sql:"column:name;index;size:255;"`
	DisplayName string `sql:"column:display_name;index;size:255;"`
	Region      string `sql:"column:region;index;size:255;"`
	Logo        string
	PlanKey     string
	CreatedAt   time.Time      `sql:"column:created_at;index;"`
	UpdatedAt   time.Time      `sql:"column:updated_at;index;"`
	DeletedAt   gorm.DeletedAt `sql:"column:deleted_at;index;"`

	//connection
	Conn []TenantConn `sql:"foreignKey:TenantId"`
}

type TenantConn struct {
	TenantId string `sql:"column:tenant_id;primary_key;size:36;"`
	//key of connection string
	Key string `sql:"column:key;primary_key;size:100;"`
	//connection string
	Value     string    `sql:"column:value;size:1000;"`
	CreatedAt time.Time `sql:"column:created_at;index;"`
	UpdatedAt time.Time `sql:"column:updated_at;index;"`
}

type TenantStore struct {
	DbProvider sgorm.DbProvider
}

func (t *TenantStore) GetByNameOrId(ctx context.Context, nameOrId string) (*saas.TenantConfig, error) {
	ctx = saas.NewCurrentTenant(ctx, "", "")
	db := t.DbProvider.Get(ctx, "")
	var tenant model.Tenant
	err := db.Model(&model.Tenant{}).Preload("Conn").Where("id = ? OR name = ?", nameOrId, nameOrId).First(&tenant).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, saas.ErrTenantNotFound
		} else {
			return nil, err
		}
	}
	ret := saas.NewTenantConfig(tenant.ID, tenant.Name, tenant.Region, tenant.PlanKey)

	for _, conn := range tenant.Conn {
		ret.Conn[conn.Key] = conn.Value
	}
	return ret, nil
}

var _ saas.TenantStore = (*TenantStore)(nil)
