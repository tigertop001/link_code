package model

import "time"

const TableNameTenantConn = "tenant_conn"

type TenantConn struct {
	// sql:"column:id;type:char(36);primaryKey" json:"id"
	TenantId  string    `gorm:"column:tenant_id;type:char(36);primaryKey;size:36;"`
	Key       string    `gorm:"column:key;type:char(100);primaryKey;size:100;"`
	Value     string    `gorm:"column:value;size:1000;"`
	CreatedAt time.Time `gorm:"column:created_at;index;"`
	UpdatedAt time.Time `gorm:"column:updated_at;index;"`
}

func (*TenantConn) TableName() string {
	return TableNameTenantConn
}
