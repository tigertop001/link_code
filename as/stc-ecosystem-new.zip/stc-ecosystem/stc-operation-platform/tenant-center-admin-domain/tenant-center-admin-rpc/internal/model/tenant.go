package model

import (
	"gorm.io/gorm"
	"time"
)

const TableNameTenant = "tenant"

type Tenant struct {
	ID          string `gorm:"column:id;type:char(36);primaryKey;size:36;"`
	Name        string `gorm:"column:name;index;size:255;"`
	DisplayName string `gorm:"column:display_name;index;size:255;"`
	Region      string `gorm:"column:region;index;size:255;"`
	Logo        string
	PlanKey     string
	SeparateDb  bool           `gorm:"column:separate_db"`
	CreatedAt   time.Time      `gorm:"column:created_at;index;"`
	UpdatedAt   time.Time      `gorm:"column:updated_at;index;"`
	DeletedAt   gorm.DeletedAt `gorm:"column:deleted_at;index;"`
	Conn        []TenantConn   `gorm:"foreignKey:TenantId"`
}

func (*Tenant) TableName() string {
	return TableNameTenant
}
