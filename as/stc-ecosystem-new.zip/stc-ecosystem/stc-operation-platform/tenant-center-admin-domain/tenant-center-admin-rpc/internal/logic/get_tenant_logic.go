package logic

import (
	"context"
	"tenant-center-admin-domain/tenant-center-admin-dependency/tenantcenter"

	"github.com/zeromicro/go-zero/core/logx"
	"tenant-center-admin-domain/tenant-center-admin-rpc/internal/svc"
)

type GetTenantLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetTenantLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetTenantLogic {
	return &GetTenantLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *GetTenantLogic) GetTenant(in *tenantcenter.GetTenantReq) (*tenantcenter.GetTenantResp, error) {
	// todo: add your logic here and delete this line

	return &tenantcenter.GetTenantResp{}, nil
}
