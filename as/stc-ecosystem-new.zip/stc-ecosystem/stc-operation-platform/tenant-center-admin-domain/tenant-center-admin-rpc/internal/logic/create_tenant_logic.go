package logic

import (
	"context"
	"fmt"
	"github.com/go-saas/saas"
	"github.com/go-saas/saas/data"
	"github.com/go-saas/saas/seed"
	"tenant-center-admin-domain/tenant-center-admin-dependency/tenantcenter"
	"tenant-center-admin-domain/tenant-center-admin-rpc/internal/model"

	"github.com/zeromicro/go-zero/core/logx"
	"tenant-center-admin-domain/tenant-center-admin-rpc/internal/svc"
)

type CreateTenantLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateTenantLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateTenantLogic {
	return &CreateTenantLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *CreateTenantLogic) CreateTenant(in *tenantcenter.CreateTenantReq) (*tenantcenter.CreateTenantResp, error) {

	ctx := saas.NewCurrentTenant(l.ctx, "", "")
	db := l.svcCtx.DbProvider.Get(ctx, "")
	fmt.Println("aaa")
	t := &model.Tenant{
		ID:          in.Name,
		Name:        in.Name,
		DisplayName: in.DisplayName,
		Region:      in.Region,
		SeparateDb:  in.SeparateDb,
	}
	if in.SeparateDb {
		t3Conn, _ := l.svcCtx.ConnStrGen.Gen(ctx, saas.NewBasicTenantInfo(t.ID, t.Name))
		t.Conn = []model.TenantConn{
			{Key: data.Default, Value: t3Conn},
		}
	}
	err := db.Model(t).Create(t).Error
	if err != nil {
		logx.Errorw("db create failed.", logx.Field("detail", err.Error()))
		panic(err)
	}
	err = l.svcCtx.Seeder.Seed(context.Background(), seed.AddTenant(t.ID))
	if err != nil {
		panic(err)
	}
	return &tenantcenter.CreateTenantResp{}, nil
}
