package i18n

import (
	"context"
	"embed"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/nicksnyder/go-i18n/v2/i18n"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/utils/errcode"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/parse"
	"golang.org/x/text/language"
	"google.golang.org/grpc/status"
	"net/http"
	"path/filepath"
	"strings"
)

//go:embed locale/*.json
var LocaleFS embed.FS

type Translator struct {
	bundle       *i18n.Bundle
	localizer    map[language.Tag]*i18n.Localizer
	supportLangs []language.Tag
}

func (l *Translator) NewBundle(file embed.FS) {
	bundle := i18n.NewBundle(language.Chinese)
	bundle.RegisterUnmarshalFunc("json", json.Unmarshal)
	_, err := bundle.LoadMessageFileFS(file, "locale/zh.json")
	logx.Must(err)
	_, err = bundle.LoadMessageFileFS(file, "locale/en.json")
	logx.Must(err)
	l.bundle = bundle
}

func (l *Translator) AddBundleFromEmbeddedFS(file embed.FS, path string) error {

	if _, err := l.bundle.LoadMessageFileFS(file, path); err != nil {
		return err
	}
	return nil
}

func (l *Translator) NewBundleFromFile(conf Conf) {
	bundle := i18n.NewBundle(language.Chinese)
	filePath, err := filepath.Abs(conf.Dir)
	logx.Must(err)
	bundle.RegisterUnmarshalFunc("json", json.Unmarshal)
	_, err = bundle.LoadMessageFile(filepath.Join(filePath, "locale/zh.json"))
	logx.Must(err)

	_, err = bundle.LoadMessageFile(filepath.Join(filePath, "locale/en.json"))
	logx.Must(err)

	l.bundle = bundle
}

func (l *Translator) AddBundleFromFile(path string) error {
	if _, err := l.bundle.LoadMessageFile(path); err != nil {
		return err
	}
	return nil
}

func (l *Translator) NewTranslator() {
	l.supportLangs = append(l.supportLangs, language.Chinese)
	l.supportLangs = append(l.supportLangs, language.English)
	l.localizer = make(map[language.Tag]*i18n.Localizer)
	l.localizer[language.Chinese] = i18n.NewLocalizer(l.bundle, language.Chinese.String())
	l.localizer[language.English] = i18n.NewLocalizer(l.bundle, language.English.String())
}

func (l *Translator) AddLanguageSupport(lang language.Tag) {
	l.supportLangs = append(l.supportLangs, lang)
	l.localizer[lang] = i18n.NewLocalizer(l.bundle, lang.String())
}

func (l *Translator) AddLanguagesByConf(conf Conf, fs embed.FS) {
	if len(conf.SupportLanguages) > 0 {
		if len(conf.SupportLanguages) != len(conf.BundleFilePaths) {
			logx.Must(errors.New("the i18n config of SupportLanguages is not the same as BundleFilePaths, please check the confmgr"))
		} else {
			for i, v := range conf.SupportLanguages {
				l.AddLanguageSupport(parse.ParseTags(v)[0])
				if conf.Dir == "" {
					err := l.AddBundleFromEmbeddedFS(fs, conf.BundleFilePaths[i])
					if err != nil {
						logx.Must(fmt.Errorf("failed to load files from %s for i18n, please check the "+
							"confmgr, error: %s", conf.BundleFilePaths[i], err.Error()))
					}
				} else {
					err := l.AddBundleFromFile(filepath.Join(conf.Dir, conf.BundleFilePaths[i]))
					if err != nil {
						logx.Must(fmt.Errorf("failed to load files from %s for i18n, please check the "+
							"confmgr, error: %s", filepath.Join(conf.Dir, conf.BundleFilePaths[i]), err.Error()))
					}
				}
			}
		}
	}
}

func (l *Translator) Trans(ctx context.Context, msgId string) string {
	if ctx.Value("lang") == nil {
		ctx = context.WithValue(ctx, "lang", "zh")
	}
	message, err := l.MatchLocalizer(ctx.Value("lang").(string)).LocalizeMessage(&i18n.Message{ID: msgId})
	if err != nil {
		return msgId
	}

	if message == "" {
		return msgId
	}

	return message
}

func (l *Translator) MatchLocalizer(lang string) *i18n.Localizer {
	tags := parse.ParseTags(lang)
	for _, v := range tags {
		if val, ok := l.localizer[v]; ok {
			return val
		}
	}

	return l.localizer[language.Chinese]
}

func (l *Translator) TransError(ctx context.Context, err error) error {
	if ctx.Value("lang") == nil {
		ctx = context.WithValue(ctx, "lang", "zh")
	}
	lang := ctx.Value("lang").(string)
	if errcode.IsGrpcError(err) {
		message, e := l.MatchLocalizer(lang).LocalizeMessage(&i18n.Message{ID: strings.Split(err.Error(), "desc = ")[1]})
		if e != nil || message == "" {
			message = err.Error()
		}
		return status.Error(status.Code(err), message)
	} else if codeErr, ok := err.(*errorxplus.CodeError); ok {
		message, e := l.MatchLocalizer(lang).LocalizeMessage(&i18n.Message{ID: codeErr.Error()})
		if e != nil || message == "" {
			message = codeErr.Error()
		}
		return errorxplus.NewCodeError(codeErr.Code, message)
	} else if apiErr, ok := err.(*errorxplus.ApiError); ok {
		message, e := l.MatchLocalizer(lang).LocalizeMessage(&i18n.Message{ID: apiErr.Error()})
		if e != nil {
			message = apiErr.Error()
		}
		return errorxplus.NewApiError(apiErr.Code, message)
	} else {
		return errorxplus.NewApiError(http.StatusInternalServerError, err.Error())
	}
}

func NewTranslator(file embed.FS) *Translator {
	trans := &Translator{}
	trans.NewBundle(file)
	trans.NewTranslator()
	return trans
}

// NewTranslatorFromFile returns a translator by FS.
func NewTranslatorFromFile(conf Conf) *Translator {
	trans := &Translator{}
	trans.NewBundleFromFile(conf)
	trans.NewTranslator()
	return trans
}
