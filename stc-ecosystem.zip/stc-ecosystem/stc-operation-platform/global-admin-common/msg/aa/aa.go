package aa

import "fmt"

func main() {
	var target = fmt.Sprintf("nacos://%s:%s@%s:%d/%s?timeout=%s&namespace_id=%s&group_name=%s&app_name=%s&grpc=%d", conf.Username, conf.Password, conf.Addr, conf.Port, serverName, "10s", conf.NamespaceID, conf.Group, clientName, conf.GrpcPort)

}
