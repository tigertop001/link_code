package main

import (
	"fmt"
	"github.com/segmentio/ksuid"
)

func main() {
	kq := ksuid.New()
	sequence := ksuid.Sequence{Seed: ksuid.New()}
	next, err := sequence.Next()
	if err != nil {
		fmt.Println("错误")
	}
	fmt.Println(next.String())
	fmt.Println(kq.String())
	fmt.Println(kq.Timestamp())
	fmt.Println(kq.Time())
	fmt.Println(kq.Payload())
	fmt.Println(kq.Bytes())
}
