package main

import (
	"context"
	"github.com/nats-io/nats.go"
	"log"
	"net"
	"os"
	"os/signal"
	"time"
)

func main() {
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Kill, os.Interrupt)
	//nc, err := nats.Connect("192.168.41.110", nats.DontRandomize())
	//if err != nil {
	//	log.Fatal(err)
	//}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	var err error
	var nc *nats.Conn

	cd := &customDialer{
		ctx:             ctx,
		connectTimeout:  10 * time.Second,
		connectTimeWait: 1 * time.Second,
	}

	opts := []nats.Option{
		nats.SetCustomDialer(cd),
		nats.ReconnectWait(2 * time.Second),
		nats.ReconnectHandler(func(conn *nats.Conn) {
			log.Println("Reconnected to ", conn.ConnectedUrl())
		}),
		nats.ClosedHandler(func(conn *nats.Conn) {
			log.Println("NATS connection is closed.")
		}),
		nats.NoReconnect(),
	}

	go func() {
		nc, err = nats.Connect("192.168.41.110:4222", opts...)
	}()

	//if err != nil {
	//	log.Fatal(err)
	//}

WaitForEstablishedConnection:
	for {
		if err != nil {
			log.Fatal(err)
		}

		select {
		case <-ctx.Done():
			break WaitForEstablishedConnection
		default:

		}

		if nc == nil || !nc.IsConnected() {
			log.Println("Connection not ready")
			time.Sleep(200 * time.Millisecond)
			continue
		}
		break WaitForEstablishedConnection

	}

	if ctx.Err() != nil {
		log.Fatal(ctx.Err())
	}

	for {
		if nc.IsClosed() {
			break
		}
		if err := nc.Publish("hello", []byte("world")); err != nil {
			log.Println(err)
			time.Sleep(1 * time.Second)
			continue
		}
		log.Println("Published message")
		time.Sleep(1 * time.Second)
	}

	if err := nc.Drain(); err != nil {
		log.Println(err)
	}
	log.Println("Disconnected")

	<-stop

	//defer nc.Close()
}

type customDialer struct {
	ctx             context.Context
	nc              *nats.Conn
	connectTimeout  time.Duration
	connectTimeWait time.Duration
}

func (c *customDialer) Dial(network, address string) (net.Conn, error) {
	ctx, cancel := context.WithTimeout(c.ctx, c.connectTimeout)
	defer cancel()

	for {
		log.Println("Attempting to connect to", address)
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}

		select {
		case <-c.ctx.Done():
			return nil, c.ctx.Err()
		default:
			d := &net.Dialer{}
			if conn, err := d.DialContext(ctx, network, address); err == nil {
				log.Println("Connected to NATS successfully")
				return conn, nil
			} else {
				time.Sleep(c.connectTimeWait)
			}
		}
	}

}
