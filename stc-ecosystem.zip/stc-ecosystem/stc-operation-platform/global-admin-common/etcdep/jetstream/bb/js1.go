package main

import (
	"encoding/json"
	"fmt"
	"github.com/nats-io/nats.go"
	"log"
)

const (
	natsAddr = "nats://192.168.41.110"
	natsPot  = "4222"
)

var (
	Nc *nats.Conn
	Jc *nats.JetStreamContext
	KB = 1024
	MB = KB * 1024
	GB = MB * 1024
)

func init() {
	natsUrl := fmt.Sprintf("%s:%s", natsAddr, natsPot)
	nc, err := nats.Connect(natsUrl, nats.Name())
	if err != nil {
		log.Fatal(err)
	}
	Nc = nc
	jc, err := nc.JetStream()
	if err != nil {
		panic(err)
	}

	Jc = &jc
}

func CreateStream(jc nats.JetStreamContext, cfg *nats.StreamConfig) (*nats.StreamInfo, error) {
	streamInfo, err := jc.AddStream(cfg)
	if err != nil {
		panic(err)
	}
	return streamInfo, nil
}

func ShowStreamInfo(si *nats.StreamInfo) error {
	b, _ := json.MarshalIndent(si, "", " ")
	fmt.Println(string(b))
	return nil
}

func main() {
	defer Nc.Close()
	defer Nc.Drain()
	cfg := &nats.StreamConfig{
		Name: "HELLO",
		Subjects: []string{
			"hi.world",
		},
		MaxBytes: int64(GB * 1),
		Discard:  nats.DiscardOld,
		MaxMsgs:  3,
	}
	si, err := CreateStream(*Jc, cfg)
	if err != nil {
		panic(err)
	}
	producer := *Jc
	producer.Publish("hi.world", []byte("1"))
	producer.Publish("hi.world", []byte("2"))
	producer.Publish("hi.world", []byte("3"))
	producer.Publish("hi.world", []byte("4"))
	si, err = producer.StreamInfo("HELLO")
	if err != nil {
		panic(err)
	}
	ShowStreamInfo(si)
	cfg.Discard = nats.DiscardNew
	_, err = producer.UpdateStream(cfg)
	if err != nil {
		panic(err)
	}
	producer.Publish("hi.world", []byte("5"))
	producer.Publish("hi.world", []byte("6"))
}
