package main

import "fmt"

func main() {
	for _, k := range []int{1, 2, 3, 4, 5} {
		fmt.Println(k << 2)
	}
}
