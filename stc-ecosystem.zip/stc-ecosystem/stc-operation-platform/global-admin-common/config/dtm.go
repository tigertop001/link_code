package config

import (
	"github.com/dtm-labs/client/workflow"
	"google.golang.org/grpc"
)

type DtmGrpcConf struct {
	Host      string   `json:",optional,env=DTM_GRPC_HOST"`
	Target    string   `json:",optional,env=DTM_GRPC_TARGET"`
	Endpoints []string `json:",optional,env=DTM_GRPC_ENDPOINTS"`
}

type DtmHttpConf struct {
	Host      string   `json:",optional,env=DTM_HTTP_HOST"`
	Target    string   `json:",optional,env=DTM_HTTP_TARGET"`
	Endpoints []string `json:",optional,env=DTM_HTTP_ENDPOINTS"`
}

func (d DtmGrpcConf) NewWorkflowGrpcInit(grpcServer *grpc.Server) {
	workflow.InitGrpc(d.Host, d.Target, grpcServer)
}

func (d DtmHttpConf) NewWorkflowHttpInit() {
	workflow.InitHTTP(d.Host, d.Target)
}
