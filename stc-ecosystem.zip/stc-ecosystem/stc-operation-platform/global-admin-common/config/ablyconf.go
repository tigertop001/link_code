package config

import "github.com/ably/ably-go/ably"

type AblyConnConf struct {
	Apikey        string              `json:",env=ABLY_KEY"`
	AutoConnect   bool                `json:",optional,env=ABLY_AUTOCONNECT"`
	ClientOptions []ably.ClientOption `json:",optional,env=ABLY_CLIENT_OPTIONS"`
}
