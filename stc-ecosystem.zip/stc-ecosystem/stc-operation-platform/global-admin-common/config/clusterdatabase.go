package config

import (
	"github.com/pkg/errors"
	"github.com/zeromicro/go-zero/core/logx"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"gorm.io/plugin/dbresolver"
	"time"
)

type ClusterDatabaseConf struct {
	MasterEndpoints []string `json:",optional,env=DATABASE_MASTER_ENDPOINTS"`
	SlaveEndpoints  []string `json:",optional,env=DATABASE_SLAVE_ENDPOINTS"`
	DatabaseConf
}

func (c ClusterDatabaseConf) clusterSingleConfig(dns string) mysql.Config {
	return mysql.Config{
		DSN:                       dns,
		DefaultStringSize:         256,
		DisableDatetimePrecision:  true,
		DontSupportRenameIndex:    true,
		DontSupportRenameColumn:   true,
		SkipInitializeWithVersion: false,
	}
}

func (c ClusterDatabaseConf) NewNoCacheClusterDriver() *gorm.DB {

	dbMasterNums := len(c.MasterEndpoints)
	dbSlaveNums := len(c.SlaveEndpoints)

	if dbMasterNums < 1 {

		logx.Must(errors.New("errors: cluster master db nums is 0"))
	}

	mysqlConfig := c.clusterSingleConfig(c.MasterEndpoints[0])
	db, err := gorm.Open(mysql.New(mysqlConfig), &gorm.Config{
		DryRun: c.DryRun,
		Logger: logger.New(writer{}, logger.Config{
			SlowThreshold:             1 * time.Second,
			Colorful:                  true,
			IgnoreRecordNotFoundError: false,
			LogLevel:                  getLevel(c.LogMode),
		}),
	})
	logx.Must(err)

	if dbMasterNums > 1 && dbSlaveNums < 1 {
		var sources []gorm.Dialector
		for i := 1; i < dbMasterNums; i++ {
			sources = append(sources, mysql.New(c.clusterSingleConfig(c.MasterEndpoints[i])))
		}
		if err := db.Use(dbresolver.Register(dbresolver.Config{
			Sources:           sources,
			Policy:            dbresolver.RandomPolicy{},
			TraceResolverMode: true,
		})); err != nil {
			logx.Must(errors.Wrapf(err, "errors: cluster master db register failed. errors stack trace: %s", err.Error()))
		}
	}
	if dbMasterNums > 1 && dbSlaveNums > 1 {
		var sources []gorm.Dialector
		for i := 1; i < dbMasterNums; i++ {
			sources = append(sources, mysql.New(c.clusterSingleConfig(c.MasterEndpoints[i])))
		}

		var replicas []gorm.Dialector
		for i := 0; i < dbSlaveNums; i++ {
			replicas = append(replicas, mysql.New(c.clusterSingleConfig(c.SlaveEndpoints[i])))
		}

		if err := db.Use(dbresolver.Register(dbresolver.Config{
			Sources:           sources,
			Replicas:          replicas,
			Policy:            dbresolver.RandomPolicy{},
			TraceResolverMode: true,
		})); err != nil {
			logx.Must(errors.Wrapf(err, "cluser master slave db register. error stack trace: %s", err.Error()))
		}

	}

	sqlDB, err := db.DB()
	logx.Must(err)

	if c.MaxIdleConn < 1 {
		c.MaxIdleConn = int(DefaultIdleConn)
	}

	if c.MaxOpenConn < 1 {
		c.MaxOpenConn = int(DefaultMaxOpenConn)
	}

	if c.ConnMaxIdleTime < 1 {
		c.ConnMaxIdleTime = int(DefaultMaxIdleTime)
	}

	if c.ConnMaxLifetime < 1 {
		c.ConnMaxLifetime = int(DefaultConnMaxLifetime)
	}
	sqlDB.SetMaxIdleConns(c.MaxIdleConn)
	sqlDB.SetMaxOpenConns(c.MaxOpenConn)
	sqlDB.SetConnMaxIdleTime(time.Duration(c.ConnMaxLifetime) * time.Hour)
	sqlDB.SetConnMaxLifetime(time.Duration(c.ConnMaxLifetime) * time.Hour)
	return db

}
