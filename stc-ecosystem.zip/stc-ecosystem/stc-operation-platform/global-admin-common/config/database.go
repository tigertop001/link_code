package config

import (
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"time"
)

var (
	DefaultMaxOpenConn     uint64 = 200
	DefaultIdleConn        uint64 = 20
	DefaultMaxIdleTime     uint64 = 24
	DefaultConnMaxLifetime uint64 = 1
)

type DatabaseConf struct {
	Host             string `json:",env=DATABASE_HOST"`
	Port             int    `json:",env=DATABASE_PORT"`
	Username         string `json:",default=root,env=DATABASE_USERNAME"`
	Password         string `json:",optional,env=DATABASE_PASSWORD"`
	DBName           string `json:",default=simple_admin,env=DATABASE_DBNAME"`
	SSLMode          string `json:",optional,env=DATABASE_SSL_MODE"`
	Type             string `json:",default=mysql,options=[mysql,tidb,clickhouse],env=DATABASE_TYPE"`
	CacheTime        int    `json:",optional,default=10,env=DATABASE_CACHE_TIME"`
	DBPath           string `json:",optional,env=DATABASE_DBPATH"`
	MysqlConfig      string `json:",optional,env=DATABASE_MYSQL_CONFIG"`
	TidbConfig       string `json:",optional,env=DATABASE_TIDB_CONFIG"`
	ClickhouseConfig string `json:",optional,env=DATABASE_CLICKHOUSE_CONFIG"`
	LogMode          string `json:",default=error"`
	MaxOpenConn      int    `json:",optional,default=100,env=DATABASE_MAX_OPEN_CONN"`
	MaxIdleConn      int    `json:",optional,default=100,env=DATABASE_MAX_IDLE_CONN"`
	ConnMaxIdleTime  int    `json:",optional,default=100,env=CONN_MAX_IDLE_TIME"`
	ConnMaxLifetime  int    `json:",optional,default=100,env=CONN_MAX_LIFE_TIME"`
	ReadTimeout      int    `json:",option,default=10,env=READ_TIMEOUT"`
	WriteTimeout     int    `json:",option,default=20,env=WRITE_TIMEOUT"`
	DryRun           bool   `json:",option,default=true,env=DRY_RUN"`
}

func (g DatabaseConf) NewNoCacheDriver() *gorm.DB {
	mysqlConfig := mysql.Config{
		DSN:                       g.GetDSN(),
		DefaultStringSize:         256,
		DisableDatetimePrecision:  true,
		DontSupportRenameIndex:    true,
		DontSupportRenameColumn:   true,
		SkipInitializeWithVersion: false,
	}
	db, err := gorm.Open(mysql.New(mysqlConfig), &gorm.Config{
		DryRun: g.DryRun,
		Logger: logger.New(writer{}, logger.Config{
			SlowThreshold:             1 * time.Second,
			Colorful:                  true,
			IgnoreRecordNotFoundError: false,
			LogLevel:                  getLevel(g.LogMode),
		}),
	})

	logx.Must(err)

	sqlDB, err := db.DB()
	logx.Must(err)

	if g.MaxIdleConn < 1 {
		g.MaxIdleConn = int(DefaultIdleConn)
	}

	if g.MaxOpenConn < 1 {
		g.MaxOpenConn = int(DefaultMaxOpenConn)
	}

	if g.ConnMaxIdleTime < 1 {
		g.ConnMaxIdleTime = int(DefaultMaxIdleTime)
	}

	if g.ConnMaxLifetime < 1 {
		g.ConnMaxLifetime = int(DefaultConnMaxLifetime)
	}
	sqlDB.SetMaxIdleConns(g.MaxIdleConn)
	sqlDB.SetMaxOpenConns(g.MaxOpenConn)
	sqlDB.SetConnMaxIdleTime(time.Duration(g.ConnMaxLifetime) * time.Hour)
	sqlDB.SetConnMaxLifetime(time.Duration(g.ConnMaxLifetime) * time.Hour)

	return db

}

func (g DatabaseConf) MysqlDSN() string {
	return fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?%s", g.Username, g.Password, g.Host, g.Port, g.DBName, g.MysqlConfig)
}

func (g DatabaseConf) ClickhouseDSN() string {
	return fmt.Sprintf("tcp://%s:%d?database=%s&username=%s&password=%s&read_timeout=%d&write_timeout=%d", g.Host, g.Port, g.DBName, g.Username, g.Password, g.ReadTimeout, g.WriteTimeout)
}

func (g DatabaseConf) TidbDSN() string {
	return fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8mb4&tls=register-tidb-tls", g.Host, g.Port, g.Username, g.Password, g.DBName)
}

func (g DatabaseConf) GetDSN() string {
	switch g.Type {
	case "mysql":
		return g.MysqlDSN()
	case "tidb":
		return g.TidbDSN()
	case "clickhouse":
		return g.ClickhouseDSN()
	default:
		return "mysql"
	}
}

func getLevel(logMode string) logger.LogLevel {
	var level logger.LogLevel
	switch logMode {
	case "info":
		level = logger.Info
	case "warn":
		level = logger.Warn
	case "error":
		level = logger.Error
	case "silent":
		level = logger.Silent
	default:
		level = logger.Error

	}
	return level
}
