package rtnews

import (
	"context"
	"errors"
	"fmt"
	"github.com/ably/ably-go/ably"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/realtime/rtnews/trigger"
	"strings"
)

type DuplexRS struct {
	duplexRT        *ably.Realtime
	duplexRTChannel *ably.RealtimeChannel
}

type RTConsumerQueue struct {
	Subject    string
	RTConsumer RTConsumerHandler
}

type RTConsumerHandler interface {
	RTConsumerHandleMessage(message *ably.Message) error
}

func MustNewDuplexRS(c *AblyConConf) *DuplexRS {

	if len(strings.TrimSpace(c.Apikey)) == 0 {
		logx.Must(errors.New("real time secret key not exist"))
	}
	var clientOptions []ably.ClientOption
	clientOptions = append(clientOptions, ably.WithKey(c.Apikey), ably.WithAutoConnect(c.AutoConnect))
	if c.ClientOptions != nil || len(c.ClientOptions) > 0 {
		clientOptions = append(clientOptions, c.ClientOptions...)
	}

	duplexRT, err := ably.NewRealtime(clientOptions...)
	logx.Must(err)

	return &DuplexRS{
		duplexRT: duplexRT,
	}
}

func (d *DuplexRS) NewRTConnect() {
	d.duplexRT.Connection.OnAll(func(change ably.ConnectionStateChange) {
		// TODO 事件处理
		switch change.Event {
		case ably.ConnectionEventInitialized:
			initTrigger := &trigger.InitEventTrigger{CurrentEventName: change.Current.String()}
			initTrigger.EventProcess()
		case ably.ConnectionEventClosed:
			closedConnTrigger := &trigger.ClosedConnEventTrigger{
				CurrentEventName: change.Current.String(),
			}
			closedConnTrigger.EventProcess()
		}
	})
	d.duplexRT.Connect()
}

func (d *DuplexRS) NewDuplexRTChannel(channelName string, options ...ably.ChannelOption) {

	realtimeChannel := d.duplexRT.Channels.Get(channelName)
	d.duplexRTChannel = realtimeChannel
}

func (d *DuplexRS) RTPublish(ctx context.Context, topic string, playload interface{}) error {

	if err := d.duplexRTChannel.Publish(ctx, topic, playload); err != nil {
		return err
	}
	return nil
}

func (d *DuplexRS) RTSubscribe(ctx context.Context, rTConsumerQueue *RTConsumerQueue) error {
	fn, err := d.duplexRTChannel.Subscribe(ctx, rTConsumerQueue.Subject, func(message *ably.Message) {

		err := rTConsumerQueue.RTConsumer.RTConsumerHandleMessage(message)
		if err != nil {
			logx.Errorf("error handling message: %v", err)
		}

	})
	defer fn()
	if err != nil {

		return err
	}
	return nil
}

func (d *DuplexRS) RTCloseConn() {

	d.duplexRT.Connection.On(ably.ConnectionEventClosed, func(change ably.ConnectionStateChange) {
		fmt.Println("Closed the connection to Ably.")
	})
	d.duplexRT.Close()
}
