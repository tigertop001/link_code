package rtnews

import "github.com/ably/ably-go/ably"

type AblyConConf struct {
	Apikey        string              `json:",env=ABLY_KEY"`
	AutoConnect   bool                `json:",env=ABLY_AUTOCONNECT"`
	ClientOptions []ably.ClientOption `json:",optional,env=ABLY_CLIENT_OPTIONS"`
}
