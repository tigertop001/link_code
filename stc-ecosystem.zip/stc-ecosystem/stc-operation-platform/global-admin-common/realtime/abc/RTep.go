package main

import (
	"fmt"
	"github.com/ably/ably-go/ably"
)

type MeiMeiConsumer struct {
	QueueOptions []*struct{}
}

func (m *MeiMeiConsumer) RTConsumerHandleMessage(msg *ably.Message) error {
	// TODO 具体的业务处理
	fmt.Printf("Received message : '%v' \n", msg.Data)
	return nil
}
