package addcommand

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestAddCommandTest(t *testing.T) {

	t.Run("test case", func(t *testing.T) {
		AddCommandListInit()
		for _, command := range Commands {
			// command.Arg, command.Action
			command.Action()
			t.Logf("%v\n\n: %v\n\n", "a", "b")
		}
		t.Log(len(Commands))
	})
	assert.Greater(t, len(Commands), 0)
}
