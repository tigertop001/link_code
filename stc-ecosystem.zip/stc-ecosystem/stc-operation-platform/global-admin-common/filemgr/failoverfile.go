package filemgr

import (
	"github.com/zeromicro/go-zero/core/logx"
	"os"
)

func CheckFailOverFileStat(filePath string) (bool, error) {
	_, err := os.Stat(filePath)
	if err == nil {
		return true, nil
	}

	if os.IsNotExist(err) {
		return false, nil
	}
	return false, nil
}

func CreateOrSilenceFailOverFile(filePath string) {
	stat, err := CheckFailOverFileStat(filePath)
	if err != nil {
		logx.Error("check file stat failed")
	}
	if !stat {
		_, err := os.Create(filePath)
		if err != nil {
			logx.Error("create file failed")
		}
	}
}
