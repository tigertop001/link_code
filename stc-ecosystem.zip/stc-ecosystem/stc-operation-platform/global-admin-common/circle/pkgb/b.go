package pkgb

import (
	"fmt"
	"global-admin-common/circle/pkga"
)

type B struct {
	C *pkga.CS
}

func (b *B) MyPrint() {
	fmt.Println("我打印了 B")
}
