package pkga

import (
	"fmt"
)

type MyInterface interface {
	MyPrint()
}
type A struct {
	C *CS
	//B *pkgb.B
	B MyInterface
}

func (b *A) MyPrint() {
	fmt.Println("我打印了 B")
}
