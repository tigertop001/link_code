package asynq

import (
	"fmt"
	"github.com/hibiken/asynq"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/stores/redis"
	"global-admin-common/config"
	"time"
)

type AsynqConf struct {
	Addr         string `json:",default=127.0.0.1:6379"`
	Username     string `json:",optional"`
	Pass         string `json:",optional"`
	DB           int    `json:",optional,default=0"`
	Concurrency  int    `json:",optional,default=20"`
	SyncInterval int    `json:",optional,default=10"`
	Enable       bool   `json:",default=true"`
}

func (c *AsynqConf) WithRedisConf(r redis.RedisConf) *AsynqConf {
	c.Pass = r.Pass
	c.Addr = r.Host
	c.DB = 0
	return c
}

func (c *AsynqConf) WithOriginalRedisConf(r config.RedisConf) *AsynqConf {
	c.Pass = r.Pass
	c.Addr = r.Host
	c.Username = r.Username
	c.DB = r.Db
	return c
}

func (c *AsynqConf) NewRedisOpt() *asynq.RedisClientOpt {
	return &asynq.RedisClientOpt{
		Network:  "tcp",
		Addr:     c.Addr,
		Username: c.Username,
		Password: c.Pass,
		DB:       c.DB,
	}
}

func (c *AsynqConf) NewClient() *asynq.Client {
	if c.Enable {
		return asynq.NewClient(c.NewRedisOpt())
	} else {
		return nil
	}
}

func (c *AsynqConf) NewServer() *asynq.Server {
	if c.Enable {
		return asynq.NewServer(
			c.NewRedisOpt(),
			asynq.Config{
				IsFailure: func(err error) bool {
					fmt.Printf("failed to exec asynq task, err : %+v \n", err)
					return true
				},
				Concurrency: c.Concurrency,
			},
		)
	} else {
		return nil
	}
}

func (c *AsynqConf) NewScheduler() *asynq.Scheduler {
	if c.Enable {
		return asynq.NewScheduler(c.NewRedisOpt(), &asynq.SchedulerOpts{Location: time.Local})
	} else {
		return nil
	}
}

func (c *AsynqConf) NewPeriodicTaskManager(provider asynq.PeriodicTaskConfigProvider) *asynq.PeriodicTaskManager {
	if c.Enable {
		mgr, err := asynq.NewPeriodicTaskManager(
			asynq.PeriodicTaskManagerOpts{
				SchedulerOpts:              &asynq.SchedulerOpts{Location: time.Local},
				RedisConnOpt:               c.NewRedisOpt(),
				PeriodicTaskConfigProvider: provider,
				SyncInterval:               time.Duration(c.SyncInterval) * time.Second,
			})
		logx.Must(err)
		return mgr
	} else {
		return nil
	}
}
