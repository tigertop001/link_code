package errorxplus

import (
	"errors"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/admini18nconst"
	"global-admin-common/msg/logmsg"
	"gorm.io/gorm"
)

func DefaultGormError(logger logx.Logger, err error, detail any) error {

	if err != nil {
		switch {
		case errors.Is(err, gorm.ErrDuplicatedKey):
			logger.Errorw(err.Error(), logx.Field("detail", detail))
			return NewInvalidArgumentError(admini18nconst.TargetNotFound)
		case errors.Is(err, gorm.ErrInvalidData):
			logger.Errorw(err.Error(), logx.Field("detail", detail))
			return NewInvalidArgumentError(admini18nconst.InvalidDataError)
		case errors.Is(err, gorm.ErrInvalidField):
			logger.Errorw(err.Error(), logx.Field("detail", detail))
			return NewInvalidArgumentError(admini18nconst.InvalidFieldError)
		case errors.Is(err, gorm.ErrInvalidValue):
			logger.Errorw(err.Error(), logx.Field("detail", detail))
			return NewInvalidArgumentError(admini18nconst.InvalidValueError)
		case errors.Is(err, gorm.ErrInvalidTransaction):
			logger.Errorw(err.Error(), logx.Field("detail", detail))
			return NewInvalidArgumentError(admini18nconst.InvalidTransactionError)
		default:
			logger.Errorw(logmsg.DatabaseError, logx.Field("detail", err.Error()))
			return NewInternalError(admini18nconst.DatabaseError)
		}
	}
	return err
}
