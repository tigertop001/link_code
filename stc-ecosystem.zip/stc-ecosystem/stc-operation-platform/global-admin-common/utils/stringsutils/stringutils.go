package stringsutils

import (
	"errors"
	"strings"
)

func ConvertMidStrings(raw, prefix, suffix, target string) (string, error) {
	if len(raw) == 0 {
		return "", errors.New("empty val")
	}
	var builder strings.Builder
	pIndex := strings.Index(raw, prefix)
	sIndex := strings.Index(raw, suffix)
	builder.WriteString(raw[:pIndex])
	builder.WriteString(target)
	builder.WriteString(raw[sIndex:])
	return builder.String(), nil
}
