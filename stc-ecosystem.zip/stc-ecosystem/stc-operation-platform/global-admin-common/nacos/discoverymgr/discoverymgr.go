package discoverymgr

import (
	"fmt"
	"github.com/nacos-group/nacos-sdk-go/v2/common/constant"
	"github.com/zeromicro/go-zero/rest"
	"github.com/zeromicro/go-zero/zrpc"
	"global-admin-common/nacos"
	"global-admin-common/nacos/confmgr"
	"log"
)

func MustRegister(nacosConfig *confmgr.NacosConf, rpcConfig *zrpc.RpcServerConf) {
	sc := []constant.ServerConfig{
		*constant.NewServerConfig(nacosConfig.Addr, nacosConfig.Port, constant.WithContextPath("/nacos"), constant.WithGrpcPort(nacosConfig.GrpcPort)),
	}

	// create ClientConfig
	cc := *constant.NewClientConfig(
		constant.WithNamespaceId(nacosConfig.NamespaceID),
		constant.WithTimeoutMs(nacosConfig.TimeoutMs),
		constant.WithNotLoadCacheAtStart(true),
		constant.WithLogDir(nacosConfig.LogDir),
		constant.WithCacheDir(nacosConfig.CacheDir),
		constant.WithUsername(nacosConfig.Username),
		constant.WithPassword(nacosConfig.Password),
		constant.WithLogLevel(nacosConfig.LogLevel),
	)

	opts := nacos.NewNacosConfig(rpcConfig.Name, rpcConfig.ListenOn, sc, &cc, nacos.WithGroup(nacosConfig.Group))
	err := nacos.RegisterService(opts)
	if err != nil {
		log.Fatalf("register service failed: %s", err)
	}
}

func MustRegisterAPI(nacosConfig *confmgr.NacosConf, apiConfig *rest.RestConf) {

	sc := []constant.ServerConfig{
		*constant.NewServerConfig(nacosConfig.Addr, nacosConfig.Port, constant.WithContextPath("/nacos"), constant.WithGrpcPort(nacosConfig.GrpcPort)),
	}

	// create ClientConfig
	cc := *constant.NewClientConfig(
		constant.WithNamespaceId(nacosConfig.NamespaceID),
		constant.WithTimeoutMs(nacosConfig.TimeoutMs),
		constant.WithClusterName(nacosConfig.ClusterName),
		constant.WithNotLoadCacheAtStart(true),
		constant.WithLogDir(nacosConfig.LogDir),
		constant.WithCacheDir(nacosConfig.CacheDir),
		constant.WithUsername(nacosConfig.Username),
		constant.WithPassword(nacosConfig.Password),
		constant.WithLogLevel(nacosConfig.LogLevel),
	)
	listenOn := fmt.Sprintf("%v:%v", apiConfig.Host, apiConfig.Port)
	opts := nacos.NewNacosConfig(apiConfig.Name, listenOn, sc, &cc, nacos.WithGroup(nacosConfig.Group), nacos.WithClusterName(nacosConfig.ClusterName))
	err := nacos.RegisterService(opts)
	if err != nil {
		log.Fatalf("register service failed: %s", err)
	}
}
