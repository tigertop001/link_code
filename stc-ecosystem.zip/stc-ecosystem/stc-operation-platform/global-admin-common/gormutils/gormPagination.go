package gormutils

import (
	"gorm.io/gorm"
)

func Paginate(page, pageSize int) func(db *gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		if page <= 0 {
			page = 1
		}
		switch {
		case pageSize > 100:
			pageSize = 100
		case pageSize <= 0:
			pageSize = 10
		}

		offset := (page - 1) * pageSize
		return db.Offset(offset).Limit(pageSize)
	}
}

func PaginateLimitOffsetNum(sPage, sPageSize int) (limit, offset int) {
	var page int
	var pageSize int
	if sPage <= 0 {
		page = 1
	} else {
		page = sPage
	}
	switch {
	case sPageSize > 100:
		pageSize = 100
	case sPageSize <= 0:
		pageSize = 10
	default:
		pageSize = sPageSize
	}

	offset = (page - 1) * pageSize

	return pageSize, offset
}
