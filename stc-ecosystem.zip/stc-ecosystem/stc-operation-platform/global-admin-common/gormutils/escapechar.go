package gormutils

import (
	"strings"
)

func Escape(w string) (string, bool) {
	var n int
	for i := range w {
		if c := w[i]; c == '%' || c == '_' || c == '\\' {
			n++
		}
	}
	// No characters to escape.
	if n == 0 {
		return w, false
	}
	var b strings.Builder
	b.Grow(len(w) + n)
	for _, c := range w {
		if c == '%' || c == '_' || c == '\\' {
			b.WriteByte('\\')
		}
		b.WriteRune(c)
	}
	return b.String(), true
}

func sqlNameJoiner(raw *string, sqlLikeJoiner *[]interface{}) *[]interface{} {
	if raw != nil && len(strings.TrimSpace(*raw)) == 0 {
		if path, ok := Escape(*raw); ok {
			*sqlLikeJoiner = append(*sqlLikeJoiner, path)
		} else {
			*sqlLikeJoiner = append(*sqlLikeJoiner, path)
		}
	}
	return sqlLikeJoiner
}
