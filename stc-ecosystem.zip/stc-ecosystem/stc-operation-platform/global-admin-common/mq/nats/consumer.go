package nats

import (
	"context"
	"errors"
	"github.com/nats-io/nats.go"
	"github.com/nats-io/nats.go/jetstream"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/mq/nats/clientconf"
	"global-admin-common/mq/nats/streamconf"
	"global-admin-common/utils/errorxplus"
	"google.golang.org/appengine/log"
	"strings"
	"time"
)

type (
	NatsConsumer struct {
		Stream         *jetstream.Stream
		Context        context.Context
		ConsumerStream *jetstream.Consumer
	}

	NatsConsMsgHandler interface {
		HandleNatsMsg(*jetstream.Msg) error
	}

	NatsConsumerMangager struct {
		ConsumerName       string
		FilterSubject      string
		NatsConsMsgHandler NatsConsMsgHandler
	}
)

func NewNatsConsumer(ctx context.Context, name string, subjects []string, connConf clientconf.StreamConnConf) (*NatsConsumer, error) {
	conn, err := connConf.NewStreamConn()
	if err != nil {
		return nil, errorxplus.NewApiInternalError(err.Error())
	}
	newJS, err := jetstream.New(conn)
	if newJS != nil {
		cfg := streamconf.NewStreamConfig(name, subjects)
		stream, err := newJS.CreateOrUpdateStream(ctx, *cfg.StreamConfig)
		if err != nil {
			logx.Errorw("stream config create or update stream failed", logx.Field("detail", err.Error()))
			return nil, errorxplus.NewApiInternalError(err.Error())
		}
		return &NatsConsumer{
			Stream:  &stream,
			Context: ctx,
		}, nil
	}

	if err != nil {
		return nil, errorxplus.NewApiInternalError(err.Error())
	}

	return nil, errorxplus.NewApiInternalError("stream create or find errors")
}

func (c *NatsConsumer) NewConsumerProcessor(consumerName, filterSubject string) (*NatsConsumer, error) {

	if len(strings.TrimSpace(consumerName)) == 0 {
		return nil, errorxplus.NewApiInternalError("consumerName empty errors")
	}

	if len(strings.TrimSpace(filterSubject)) == 0 {
		return nil, errorxplus.NewApiInternalError("filterSubject empty errors")
	}

	consumeStream := *c.Stream
	var elasticRetry []time.Duration
	for _, qos := range []int{1, 2, 4, 6, 8} {
		elasticRetry = append(elasticRetry, time.Duration(qos<<2)*time.Second)
	}
	updateConsumer, err := consumeStream.CreateOrUpdateConsumer(c.Context, jetstream.ConsumerConfig{
		Name:              consumerName,
		FilterSubject:     filterSubject,
		AckPolicy:         jetstream.AckExplicitPolicy,
		MaxAckPending:     1000,
		MaxDeliver:        6,
		BackOff:           elasticRetry,
		ReplayPolicy:      jetstream.ReplayInstantPolicy,
		DeliverPolicy:     jetstream.DeliverAllPolicy,
		MaxWaiting:        1000,
		MaxRequestExpires: time.Duration(32) * time.Second,
		MaxRequestBatch:   1000,
	})
	if err != nil {
		return nil, errorxplus.NewApiInternalError("build consumer errors")
	}
	c.ConsumerStream = &updateConsumer
	return c, nil
}

func (c *NatsConsumer) NatsPullConsumeMsg(mgr *NatsConsumerMangager) error {

	consumer := *c.ConsumerStream
	if consumer != nil {
		_, err := consumer.Consume(func(msg jetstream.Msg) {
			err := mgr.NatsConsMsgHandler.HandleNatsMsg(&msg)
			if err != nil {
				log.Errorf(c.Context, " msg %s consume failed", msg.Subject())
				err = msg.Nak()
				if err != nil {
					// TODO 不另开goroutine,当大量消息失败的时候,启动大量goroutin,耗费资源,做好统计和告警
					logx.Errorw("msg consume nak fail.", logx.Field("detail", err.Error()))
				}
			}
			err = msg.DoubleAck(c.Context)
			if err != nil {
				// TODO 不另开goroutine,当大量消息失败的时候,启动大量goroutin,耗费资源,做好统计和告警
				logx.Errorw("msg consume nak fail.", logx.Field("detail", err.Error()))

			}
		}, jetstream.ConsumeErrHandler(func(consumeCtx jetstream.ConsumeContext, err error) {
			// TODO 异常告警, 消息重放
			logx.Errorw("msg consume fail.", logx.Field("detail", err.Error()))
		}))
		consumer.Consume(func(msg jetstream.Msg) {})
		if err != nil {
			return errorxplus.NewApiInternalError(err.Error())
		}
		return nil
	}
	return nil
}

func (c *NatsConsumer) DeleteProcessingConsumer(consumer string) {
	jsStream := *c.Stream
	err := jsStream.DeleteConsumer(c.Context, consumer)
	if err != nil || errors.Is(nats.ErrConsumerNotFound, err) {
		logx.Errorw("delete consumer not found", logx.Field("detail", err))
	}
}
