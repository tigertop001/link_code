package main

import (
	"context"
	"fmt"
	"github.com/nats-io/nats.go/jetstream"
	"global-admin-common/mq/nats"
	"global-admin-common/mq/nats/clientconf"
	"os"
	"os/signal"
)

type EpConsumer struct {
}

func (receiver *EpConsumer) HandleNatsMsg(msg *jetstream.Msg) error {
	data := *msg
	fmt.Println("123 ==>> HandleNatsMsg")
	fmt.Printf("handle nats msg %s\n", string(data.Data()))
	fmt.Println("321 ==>> HandleNatsMsg")
	return nil
}

func main() {
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, os.Interrupt, os.Kill)
	var seeds []string
	seeds = append(seeds, "nats://192.168.41.110:4222")
	connStarter := clientconf.NewStreamConnConf(seeds)
	ctx := context.Background()

	producer, err := nats.NewNatProducer(connStarter)
	if err != nil {
		fmt.Println(err)
	}
	var subjects []string
	subjects = append(subjects, "fanny.>")
	_, err = producer.CreateOrDetectionStream(ctx, "HIBF", subjects)
	if err != nil {
		fmt.Println(err)
		return
	}

	err = producer.Publish(ctx, "013044cceb1da5f6d132", "stc.hi", []byte("Hello, nats"))
	if err != nil {
		fmt.Println(err)
	}
	//ctx context.Context, name string, subjects []string, connConf clientconf.StreamConnConf

	consumer, err := nats.NewNatsConsumer(ctx, "HIBF", subjects, connStarter)
	if err != nil {
		fmt.Println(err)
	}
	newConsumer, err := consumer.NewConsumerProcessor("fanny-55", "fanny.*")
	if err != nil {
		fmt.Println(err)
	}
	abc := *newConsumer.ConsumerStream
	fetchResult, _ := abc.Fetch(3)
	for msg := range fetchResult.Messages() {
		fmt.Printf("received %q\n", msg.Subject())
		msg.Ack()
	}
	mgr := &nats.NatsConsumerMangager{
		NatsConsMsgHandler: &EpConsumer{},
	}

	err = newConsumer.NatsPullConsumeMsg(mgr)
	if err != nil {
		fmt.Println(err)
	}
	<-stop
	fmt.Println("consumer stop")
}
