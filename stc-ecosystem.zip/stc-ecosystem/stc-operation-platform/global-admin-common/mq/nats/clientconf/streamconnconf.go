package clientconf

import (
	"github.com/nats-io/nats.go"
	"global-admin-common/utils/errorxplus"
	"strings"
	"time"
)

type StreamConnConf struct {
	Seeds            []string `json:",env=NATS_URLS"`
	ClientName       string   `json:",optional,env=NATS_CLIENT_NAME"`
	RootCAs          string   `json:",optional,env=NATS_ROOT_CAS"`
	CertFile         string   `json:",optional,env=NATS_CERT_FILE"`
	KeyFile          string   `json:",optional,env=NATS_KEY_FILE"`
	ReconnectWait    int32    `json:",optional,env=NATS_RECONNECT_WAIT"`
	MaxReconnects    int      `json:",optional,env=NATS_MAX_RECONNECTS"`
	PingInterval     int32    `json:",optional,env=NATS_PING_INTERVAL"`
	ReconnectBufSize int      `json:",optional,env=NATS_RECONNECT_BUF_SIZE"`
	TimeOut          int      `json:",optional,env=NATS_TIME_OUT"`
	FlusherTimeout   int      `json:",optional,env=NATS_FLUSHER_TIMEOUT"`
	DrainTimeout     int      `json:",optional,env=NATS_DRAIN_TIMEOUT"`
	User             string   `json:",optional,env=NATS_USER"`
	Pass             string   `json:",optional,env=NATS_PASS"`
}

func NewStreamConnConf(seeds []string) StreamConnConf {
	return StreamConnConf{
		Seeds: seeds,
	}
}
func (s StreamConnConf) NewStreamConn() (*nats.Conn, error) {
	var options []nats.Option
	if len(s.ClientName) > 0 {
		options = append(options, nats.Name(s.ClientName))
	}
	if len(s.RootCAs) > 0 &&
		len(s.KeyFile) > 0 &&
		len(s.CertFile) > 0 {
		options = append(options, nats.RootCAs(s.RootCAs))
		options = append(options, nats.ClientCert(s.KeyFile, s.CertFile))
	}
	if s.ReconnectWait > 0 {
		options = append(options, nats.ReconnectWait(time.Duration(s.ReconnectWait)*time.Second))
	}
	if s.MaxReconnects > 0 {
		options = append(options, nats.MaxReconnects(s.MaxReconnects))
	}
	if s.PingInterval > 0 {
		options = append(options, nats.PingInterval(time.Duration(s.PingInterval)*time.Second))
	}
	if s.ReconnectBufSize > 0 {
		options = append(options, nats.ReconnectBufSize(s.ReconnectBufSize))
	}
	if s.TimeOut > 0 {
		options = append(options, nats.Timeout(time.Duration(s.TimeOut)*time.Second))
	}
	if s.FlusherTimeout > 0 {
		options = append(options, nats.FlusherTimeout(time.Duration(s.FlusherTimeout)*time.Second))
	}
	if s.DrainTimeout > 0 {
		options = append(options, nats.DrainTimeout(time.Duration(s.DrainTimeout)*time.Second))
	}
	if len(strings.TrimSpace(s.User)) > 0 && len(strings.TrimSpace(s.Pass)) > 0 {
		options = append(options, nats.UserInfo(s.User, s.Pass))
	}
	urls := strings.Join(s.Seeds, ",")
	conn, err := nats.Connect(urls, options...)
	if err != nil {
		return nil, errorxplus.NewApiInternalError(err.Error())
	}

	return conn, nil
}
