package clientconf

type WsConnConf struct {
}
