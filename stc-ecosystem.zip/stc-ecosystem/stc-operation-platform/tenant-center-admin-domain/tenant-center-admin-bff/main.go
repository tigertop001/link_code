package main

import (
	"flag"
	"fmt"
	"github.com/dtm-labs/client/workflow"
	"github.com/dtm-labs/dtm-examples/dtmutil"
	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/rest"
	"global-admin-common/nacos/confmgr"
	"global-admin-common/nacos/discoverymgr"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/config"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/handler"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/svc"
)

var configFile = flag.String("f", "etc/conf.yaml", "the config filemgr")

func main() {
	flag.Parse()

	var c config.Config
	//conf.MustLoad(*configFile, &c, conf.UseEnv())
	discoverymgr.MustRegisterAPI(confmgr.MustLoad(*configFile, &c, conf.UseEnv()), &c.RestConf)
	server := rest.MustNewServer(c.RestConf)

	defer server.Stop()
	defer logx.Close()
	ctx := svc.NewServiceContext(c, confmgr.MustLoad(*configFile, &c, conf.UseEnv()))
	handler.RegisterHandlers(server, ctx)
	logx.MustSetup(logx.LogConf{Stat: false})
	// 事务编排初始化
	workflow.InitHTTP(dtmutil.DefaultHTTPServer, "discover://"+"/workflow/resume")
	fmt.Printf("Starting server at %s:%d...\n", c.Host, c.Port)
	server.Start()
}
