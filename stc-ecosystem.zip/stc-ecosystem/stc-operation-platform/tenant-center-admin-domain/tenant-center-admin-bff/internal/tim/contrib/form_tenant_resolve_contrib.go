package contrib

import (
	"github.com/go-saas/saas"
	"net/http"
)

type FormTenantResolveContrib struct {
	Key     string
	request *http.Request
}

func NewFormTenantResolveContrib(key string, r *http.Request) *FormTenantResolveContrib {
	return &FormTenantResolveContrib{
		Key:     key,
		request: r,
	}
}

func (f *FormTenantResolveContrib) Name() string {
	return "Form"
}

func (f *FormTenantResolveContrib) Resolve(ctx *saas.Context) error {
	v := f.request.FormValue(f.Key)
	if v == "" {
		return nil
	}
	ctx.TenantIdOrName = v
	return nil
}
