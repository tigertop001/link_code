package tenant

import (
	"context"
	"encoding/json"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/utils/errorxplus"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/svc"
	"tenant-center-admin-domain/tenant-center-admin-bff/internal/types"
	"tenant-center-admin-domain/tenant-center-admin-dependency/tenantcenter"
)

type CreateTenantLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCreateTenantLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateTenantLogic {
	return &CreateTenantLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *CreateTenantLogic) CreateTenant(req *types.AddTenantReq) (resp *types.BaseMsgResp, err error) {

	createTenantReq := &tenantcenter.CreateTenantReq{
		Name:        *req.Name,
		DisplayName: *req.DisplayName,
		Region:      *req.Region,
		Logo:        *req.Logo,
		SeparateDb:  *req.SeparateDb,
	}

	tenant, err := l.svcCtx.TenantCenterRpc.CreateTenant(l.ctx, createTenantReq)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, tenant)
	}
	var msg string
	if tenant != nil {
		msg = ""
	} else {
		marshal, err := json.Marshal(tenant)
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, tenant)
		}
		msg = string(marshal)
	}

	return &types.BaseMsgResp{
		Code: 200,
		Msg:  l.svcCtx.Trans.Trans(l.ctx, msg),
	}, nil
}
