package model

import (
	gorm2 "github.com/go-saas/saas/gorm"
	"gorm.io/gorm"
)

const TableNamePost = "post"

type Post struct {
	gorm.Model
	Title       string `json:"title"`
	Description string `json:"description"`
	gorm2.MultiTenancy
}

func (*Post) TableName() string {
	return TableNamePost
}
