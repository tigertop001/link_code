package logic

import (
	"context"
	"tenant-center-admin-domain/tenant-center-admin-dependency/tenantcenter"

	"github.com/zeromicro/go-zero/core/logx"
	"tenant-center-admin-domain/tenant-center-admin-rpc/internal/svc"
)

type UpdateTenantLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateTenantLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateTenantLogic {
	return &UpdateTenantLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *UpdateTenantLogic) UpdateTenant(in *tenantcenter.UpdateTenantReq) (*tenantcenter.UpdateTenantResp, error) {
	// todo: add your logic here and delete this line

	return &tenantcenter.UpdateTenantResp{}, nil
}
