package config

import (
	"github.com/zeromicro/go-zero/zrpc"
	"global-admin-common/config"
)

type Config struct {
	zrpc.RpcServerConf
	DatabaseConf struct {
		Datasource string
	}
	DtmGrpcConf config.DtmGrpcConf
	RedisConf   config.RedisConf
}
