package svc

import (
	"context"
	"github.com/go-saas/saas"
	"github.com/go-saas/saas/seed"
	"gorm.io/gorm"
	"tenant-center-admin-domain/tenant-center-admin-rpc/internal/config"
	gorm2 "tenant-center-admin-domain/tenant-center-admin-rpc/internal/tenantgorm"
)

type ServiceContext struct {
	Config     config.Config
	DbProvider saas.DbProvider[*gorm.DB]
	Seeder     seed.Seeder
	ConnStrGen saas.ConnStrGenerator
}

func NewServiceContext(c config.Config) *ServiceContext {

	DbProvider := gorm2.GormDbProvider(c.DatabaseConf.Datasource)

	connStrGen := gorm2.ConnstrGen(c.DatabaseConf.Datasource)
	seeder := seed.NewDefaultSeeder(gorm2.NewMigrationSeeder(DbProvider), gorm2.NewSeed(DbProvider, connStrGen))
	err := seeder.Seed(context.Background(), seed.AddHost(), seed.AddTenant("1", "2", "3"))

	if err != nil {
		panic(err)
	}
	return &ServiceContext{
		Config:     c,
		DbProvider: DbProvider,
		Seeder:     seeder,
		ConnStrGen: connStrGen,
	}

}
