package main

import (
	"flag"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/nacos/confmgr"
	"global-admin-common/nacos/discoverymgr"
	"tenant-center-admin-domain/tenant-center-admin-dependency/tenantcenter"

	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/core/service"
	"github.com/zeromicro/go-zero/zrpc"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"tenant-center-admin-domain/tenant-center-admin-rpc/internal/config"
	"tenant-center-admin-domain/tenant-center-admin-rpc/internal/server"
	"tenant-center-admin-domain/tenant-center-admin-rpc/internal/svc"
)

var configFile = flag.String("f", "etc/conf.yaml", "the config filemgr")

func main() {
	flag.Parse()

	var c config.Config
	//conf.MustLoad(*configFile, &c, conf.UseEnv())
	discoverymgr.MustRegister(confmgr.MustLoad(*configFile, &c, conf.UseEnv()), &c.RpcServerConf)
	ctx := svc.NewServiceContext(c)

	s := zrpc.MustNewServer(c.RpcServerConf, func(grpcServer *grpc.Server) {
		//defer func() {
		// workflow.initGrpc
		//	workflow.InitGrpc(c.DtmGrpcConf.Host, c.DtmGrpcConf.Target, grpcServer)
		//}()
		tenantcenter.RegisterTenantcenterServer(grpcServer, server.NewTenantcenterServer(ctx))
		if c.Mode == service.DevMode || c.Mode == service.TestMode {
			reflection.Register(grpcServer)
		}
	})
	defer s.Stop()
	logx.MustSetup(logx.LogConf{Stat: false})
	fmt.Printf("Starting rpc server at %s...\n", c.ListenOn)
	s.Start()
}
