package logic

import (
	"context"
	"operation-qq-id-domain/operation-qq-id-dependency/opqqidcenter"
	"operation-qq-id-domain/operation-qq-id-rpc/internal/qqid"

	"github.com/zeromicro/go-zero/core/logx"
	"operation-qq-id-domain/operation-qq-id-rpc/internal/svc"
)

type GetOpQqidLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetOpQqidLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetOpQqidLogic {
	return &GetOpQqidLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *GetOpQqidLogic) GetOpQqid(in *opqqidcenter.Empty) (*opqqidcenter.OpIDResp, error) {
	_ = in
	seqNum := qqid.NextId()
	return &opqqidcenter.OpIDResp{
		Code: 2000,
		Qqid: &seqNum,
		Msg:  "success",
	}, nil
}
