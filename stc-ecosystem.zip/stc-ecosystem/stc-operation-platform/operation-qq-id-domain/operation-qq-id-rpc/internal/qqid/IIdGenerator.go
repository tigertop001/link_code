package qqid

type IIdGenerator interface {
	NewLong() uint64
}
