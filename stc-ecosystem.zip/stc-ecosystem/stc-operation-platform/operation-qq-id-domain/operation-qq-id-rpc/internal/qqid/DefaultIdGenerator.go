package qqid

import (
	"strconv"
	"time"
)

type DefaultIdGenerator struct {
	Options              *IdGeneratorOptions
	SnowWorker           ISnowWorker
	IdGeneratorException IdGeneratorException
}

func NewDefaultIdGenerator(options *IdGeneratorOptions) *DefaultIdGenerator {
	if options == nil {
		panic("dig.Options error.")
	}

	minTime := int64(631123200000)
	if options.BaseTime < minTime || options.BaseTime > time.Now().UnixNano()/1e6 {
		panic("BaseTime error.")
	}
	if options.WorkerIdBitLength <= 0 {
		panic("WorkerIdBitLength error.(range:[1,21)])")
	}
	if options.WorkerIdBitLength+options.SeqBitLength > 22 {
		panic("error：WorkerIdBitLength + SeqBitLength <= 22")
	}

	maxWorkerIdNumber := uint16(1<<options.WorkerIdBitLength) - 1
	if maxWorkerIdNumber == 0 {
		maxWorkerIdNumber = 63
	}

	if options.WorkerId < 0 || options.WorkerId > maxWorkerIdNumber {
		panic("WorkerId error. (range:[0, " + strconv.FormatUint(uint64(maxWorkerIdNumber), 10) + "]")
	}

	if options.SeqBitLength < 2 || options.SeqBitLength > 21 {
		panic("SeqBitLength error. (range:[2, 21])")
	}

	maxSeqNumber := uint32(1<<options.SeqBitLength) - 1
	if maxSeqNumber == 0 {
		maxSeqNumber = 63
	}

	if options.MaxSeqNumber < 0 || options.MaxSeqNumber > maxSeqNumber {
		panic("MaxSeqNumber error. (range:[1, " + strconv.FormatUint(uint64(maxSeqNumber), 10) + "]")
	}

	if options.MinSeqNumber < 5 || options.MinSeqNumber > maxSeqNumber {
		panic("MinSeqNumber error. (range:[5, " + strconv.FormatUint(uint64(maxSeqNumber), 10) + "]")
	}

	if options.TopOverCostCount < 0 || options.TopOverCostCount > 10000 {
		panic("TopOverCostCount error. (range:[0, 10000]")
	}

	var snowWorker ISnowWorker
	switch options.Method {
	case 1:
		snowWorker = NewSnowWorkerM1(options)
	case 2:
		snowWorker = NewSnowWorkerM2(options)
	default:
		snowWorker = NewSnowWorkerM1(options)

	}
	if options.Method == 1 {
		time.Sleep(time.Duration(500) * time.Microsecond)
	}
	return &DefaultIdGenerator{
		Options:    options,
		SnowWorker: snowWorker,
	}
}

func (d DefaultIdGenerator) NewLong() int64 {
	return d.SnowWorker.NextId()
}

func (d DefaultIdGenerator) ExtractTime(id int64) time.Time {
	return time.UnixMilli(id>>(d.Options.WorkerIdBitLength+d.Options.SeqBitLength) + d.Options.BaseTime)
}
