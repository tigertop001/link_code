package qqid

import (
	"github.com/zeromicro/go-zero/core/logx"
)

type IdGeneratorException struct {
	message string
	error   error
}

func (e IdGeneratorException) IdGeneratorException(msg string, err error) {
	logx.Errorw(msg, logx.Field("detail", err.Error()))
}
