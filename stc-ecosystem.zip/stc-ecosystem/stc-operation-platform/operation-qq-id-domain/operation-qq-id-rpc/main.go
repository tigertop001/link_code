package main

import (
	"flag"
	"fmt"
	"operation-qq-id-domain/operation-qq-id-dependency/opqqidcenter"

	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/core/service"
	"github.com/zeromicro/go-zero/zrpc"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"operation-qq-id-domain/operation-qq-id-rpc/internal/config"
	"operation-qq-id-domain/operation-qq-id-rpc/internal/server"
	"operation-qq-id-domain/operation-qq-id-rpc/internal/svc"
)

var configFile = flag.String("f", "etc/conf.yaml", "the config filemgr")

func main() {
	flag.Parse()

	var c config.Config
	conf.MustLoad(*configFile, &c)
	ctx := svc.NewServiceContext(c)

	s := zrpc.MustNewServer(c.RpcServerConf, func(grpcServer *grpc.Server) {
		opqqidcenter.RegisterOpQqidcenterServer(grpcServer, server.NewOpQqidcenterServer(ctx))

		if c.Mode == service.DevMode || c.Mode == service.TestMode {
			reflection.Register(grpcServer)
		}
	})
	defer s.Stop()

	fmt.Printf("Starting rpc server at %s...\n", c.ListenOn)
	s.Start()
}
