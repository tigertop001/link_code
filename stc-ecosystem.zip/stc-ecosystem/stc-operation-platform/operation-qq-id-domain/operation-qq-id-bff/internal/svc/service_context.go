package svc

import (
	"github.com/zeromicro/go-zero/zrpc"
	"operation-qq-id-domain/operation-qq-id-bff/internal/config"
	qqidclient "operation-qq-id-domain/operation-qq-id-dependency/op_qqidcenter_client"
)

type ServiceContext struct {
	Config          config.Config
	OpqqidCenterRpc qqidclient.OpQqidcenter
}

func NewServiceContext(c config.Config) *ServiceContext {
	return &ServiceContext{
		Config:          c,
		OpqqidCenterRpc: qqidclient.NewOpQqidcenter(zrpc.MustNewClient(c.QqidCenterRpcConf)),
	}
}
