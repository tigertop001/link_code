package qqid

import (
	"context"
	"operation-qq-id-domain/operation-qq-id-dependency/opqqidcenter"

	"operation-qq-id-domain/operation-qq-id-bff/internal/svc"
	"operation-qq-id-domain/operation-qq-id-bff/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetQqidv1Logic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetQqidv1Logic(ctx context.Context, svcCtx *svc.ServiceContext) *GetQqidv1Logic {
	return &GetQqidv1Logic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetQqidv1Logic) GetQqidv1(req *types.Empty) (resp *types.OpIDResp, err error) {

	qqid, err := l.svcCtx.OpqqidCenterRpc.GetOpQqid(l.ctx, &opqqidcenter.Empty{})
	if err != nil {
		return nil, err
	}

	return &types.OpIDResp{
		Code: 2000,
		Msg:  "success",
		Qqid: qqid.Qqid,
	}, nil
}
