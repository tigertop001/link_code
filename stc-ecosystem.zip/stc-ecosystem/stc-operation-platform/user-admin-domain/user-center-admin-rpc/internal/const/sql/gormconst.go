package sql

const (
	LIKE_BLURRY_PLACEHOLDER = "%"
)
