package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type GetApiByIdLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetApiByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetApiByIdLogic {
	return &GetApiByIdLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: api
func (l *GetApiByIdLogic) GetApiById(in *usercenter2.IDReq) (*usercenter2.ApiInfo, error) {

	sysApiRepo := query.SysAPI
	result, err := sysApiRepo.WithContext(l.ctx).Where(sysApiRepo.ID.Eq(int64(in.Id))).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	uId := new(uint64)
	*uId = uint64(result.ID)
	return &usercenter2.ApiInfo{
		Id:          uId,
		CreatedAt:   pointy.GetPointer(result.CreatedAt.UnixMilli()),
		UpdatedAt:   pointy.GetPointer(result.UpdatedAt.UnixMilli()),
		Path:        &result.Path,
		Description: &result.Description,
		ApiGroup:    &result.APIGroup,
		Method:      &result.Method,
		IsRequired:  &result.IsRequired,
		ServiceName: &result.ServiceName,
	}, nil
}
