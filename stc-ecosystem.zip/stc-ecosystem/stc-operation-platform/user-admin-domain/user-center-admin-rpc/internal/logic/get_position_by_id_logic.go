package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetPositionByIdLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetPositionByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetPositionByIdLogic {
	return &GetPositionByIdLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: position
func (l *GetPositionByIdLogic) GetPositionById(in *usercenter.IDReq) (*usercenter.PositionInfo, error) {
	sysPositionRepo := query.SysPosition
	result, err := sysPositionRepo.WithContext(l.ctx).Where(sysPositionRepo.ID.Eq(int64(in.Id))).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	uId := new(uint64)
	*uId = uint64(result.ID)
	uStatus := new(uint32)
	*uStatus = uint32(*result.Status)
	return &usercenter.PositionInfo{
		Id:        uId,
		CreatedAt: pointy.GetPointer(result.CreatedAt.UnixMilli()),
		UpdatedAt: pointy.GetPointer(result.UpdatedAt.UnixMilli()),
		Status:    uStatus,
		Sort:      uStatus,
		Name:      &result.Name,
		Code:      &result.Code,
		Remark:    result.Remark,
	}, nil
}
