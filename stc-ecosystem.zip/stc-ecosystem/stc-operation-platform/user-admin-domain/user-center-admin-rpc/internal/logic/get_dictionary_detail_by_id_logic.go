package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetDictionaryDetailByIdLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetDictionaryDetailByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetDictionaryDetailByIdLogic {
	return &GetDictionaryDetailByIdLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: dictionarydetail
func (l *GetDictionaryDetailByIdLogic) GetDictionaryDetailById(in *usercenter.IDReq) (*usercenter.DictionaryDetailInfo, error) {
	sysDictionaryDetailRepo := query.SysDictionaryDetail
	result, err := sysDictionaryDetailRepo.WithContext(l.ctx).Where(sysDictionaryDetailRepo.ID.Eq(int64(in.Id))).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	uId := new(uint64)
	*uId = uint64(result.ID)
	uStatus := new(uint32)
	*uStatus = uint32(*result.Status)
	uSort := new(uint32)
	*uSort = uint32(result.Sort)
	uDictionaryId := new(uint64)
	*uDictionaryId = uint64(*result.DictionaryID)
	return &usercenter.DictionaryDetailInfo{
		Id:           uId,
		CreatedAt:    pointy.GetPointer(result.CreatedAt.UnixMilli()),
		UpdatedAt:    pointy.GetPointer(result.UpdatedAt.UnixMilli()),
		Status:       uStatus,
		Title:        &result.Title,
		Key:          &result.Key,
		Value:        &result.Value,
		Sort:         uSort,
		DictionaryId: uDictionaryId,
	}, nil
}
