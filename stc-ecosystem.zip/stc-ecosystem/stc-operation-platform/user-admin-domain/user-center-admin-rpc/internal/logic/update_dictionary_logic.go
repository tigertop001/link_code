package logic

import (
	"context"
	"errors"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type UpdateDictionaryLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateDictionaryLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateDictionaryLogic {
	return &UpdateDictionaryLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: dictionary
func (l *UpdateDictionaryLogic) UpdateDictionary(in *usercenter2.DictionaryInfo) (*usercenter2.BaseResp, error) {

	if in.Id == nil {
		return nil, errorxplus.DefaultGormError(l.Logger, errors.New("update id empty"), in)
	}

	sysDictionaryPo := &model.SysDictionary{}
	if in.Status != nil {
		uStatus := new(int32)
		*uStatus = int32(*in.Status)
		sysDictionaryPo.Status = uStatus
	}
	if in.Title != nil && len(strings.TrimSpace(*in.Title)) > 0 {
		sysDictionaryPo.Title = *in.Title
	}
	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysDictionaryPo.Name = *in.Name
	}
	if in.Desc != nil && len(strings.TrimSpace(*in.Desc)) > 0 {
		sysDictionaryPo.Desc = in.Desc
	}

	sysDictionaryRepo := query.SysDictionary
	_, err := sysDictionaryRepo.WithContext(l.ctx).Where(sysDictionaryRepo.ID.Eq(int64(*in.Id))).Updates(sysDictionaryPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, errors.New("update id empty"), in)
	}
	return &usercenter2.BaseResp{Msg: admini18nconst.UpdateSuccess}, nil
}
