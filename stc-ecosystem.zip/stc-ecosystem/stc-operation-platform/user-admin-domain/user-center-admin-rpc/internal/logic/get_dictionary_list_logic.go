package logic

import (
	"context"
	"errors"
	"global-admin-common/gormutils"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/const/sql"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetDictionaryListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetDictionaryListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetDictionaryListLogic {
	return &GetDictionaryListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: dictionary
func (l *GetDictionaryListLogic) GetDictionaryList(in *usercenter.DictionaryListReq) (*usercenter.DictionaryListResp, error) {

	if in.Name != nil || len(strings.TrimSpace(*in.Name)) <= 0 {
		return nil, errorxplus.DefaultGormError(l.Logger, errors.New("name empty"), in)
	}

	sysDictionaryRepo := query.SysDictionary
	var sysDictionaryDo query.ISysDictionaryDo
	limit, offset := gormutils.PaginateLimitOffsetNum(int(in.Page), int(in.PageSize))
	safeName, _ := gormutils.Escape(*in.Name)
	sysDictionaryDo = sysDictionaryRepo.WithContext(l.ctx).Where(sysDictionaryRepo.Name.Like(gormutils.LikeExpPercentJoiner(safeName, sql.LIKE_BLURRY_PLACEHOLDER)))
	total, err := sysDictionaryDo.Count()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	result, err := sysDictionaryDo.Offset(offset).
		Limit(limit).
		Order(sysDictionaryRepo.ID.Asc()).
		Find()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	resp := &usercenter.DictionaryListResp{}
	resp.Total = uint64(total)
	for _, v := range result {
		uId := new(uint64)
		*uId = uint64(v.ID)
		uStatus := new(uint32)
		*uStatus = uint32(*v.Status)
		resp.Data = append(resp.Data, &usercenter.DictionaryInfo{
			Id:        uId,
			CreatedAt: pointy.GetPointer(v.CreatedAt.UnixMilli()),
			UpdatedAt: pointy.GetPointer(v.UpdatedAt.UnixMilli()),
			Status:    uStatus,
			Title:     &v.Title,
			Name:      &v.Name,
			Desc:      v.Desc,
		})
	}
	return resp, nil
}
