package logic

import (
	"context"
	"global-admin-common/gormutils"
	"global-admin-common/smops"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/const/sql"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetUserListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetUserListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetUserListLogic {
	return &GetUserListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: user
func (l *GetUserListLogic) GetUserList(in *usercenter.UserListReq) (*usercenter.UserListResp, error) {

	var userIds []string
	iRoleIds, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.RoleIds)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	userRoleRepo := query.UserRole
	sysRoleRepo := query.SysRole

	err = userRoleRepo.WithContext(l.ctx).Select(userRoleRepo.UserID).
		Join(sysRoleRepo, sysRoleRepo.ID.EqCol(userRoleRepo.RoleID)).
		Where(sysRoleRepo.ID.In(iRoleIds...)).Scan(&userIds)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	var positionIds []string
	iPositionIds, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.PositionIds)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	userPositionRepo := query.UserPosition
	sysPositionRepo := query.SysPosition

	err = userPositionRepo.WithContext(l.ctx).Select(userPositionRepo.UserID).
		Join(sysPositionRepo, sysPositionRepo.ID.EqCol(userPositionRepo.PositionID)).
		Where(sysPositionRepo.ID.In(iPositionIds...)).Scan(&positionIds)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	sysUserRepo := query.SysUser
	var sysUserDo query.ISysUserDo
	if in.Mobile != nil && len(strings.TrimSpace(*in.Mobile)) > 0 {
		sysUserDo = sysUserRepo.WithContext(l.ctx).Where(sysUserRepo.Mobile.Eq(*in.Mobile))

	}
	if in.Username != nil && len(strings.TrimSpace(*in.Username)) > 0 {
		safeUsername, _ := gormutils.Escape(*in.Username)
		if sysUserDo != nil {
			sysUserDo = sysUserDo.WithContext(l.ctx).Where(sysUserRepo.Username.Like(gormutils.LikeExpPercentJoiner(safeUsername, sql.LIKE_BLURRY_PLACEHOLDER)))
		}
	}
	if in.Email != nil && len(strings.TrimSpace(*in.Email)) > 0 {
		if sysUserDo != nil {
			sysUserDo = sysUserDo.WithContext(l.ctx).Where(sysUserRepo.Email.Eq(*in.Email))
		}
	}
	if in.Nickname != nil && len(strings.TrimSpace(*in.Nickname)) > 0 {
		safeNickname, _ := gormutils.Escape(*in.Nickname)
		if sysUserDo != nil {
			sysUserDo = sysUserDo.WithContext(l.ctx).Where(sysUserRepo.Nickname.Like(gormutils.LikeExpPercentJoiner(safeNickname, sql.LIKE_BLURRY_PLACEHOLDER)))

		}
	}
	if len(userIds) > 0 {
		if sysUserDo != nil {
			sysUserDo = sysUserDo.WithContext(l.ctx).Where(sysUserRepo.ID.In(userIds...))
		}
	}
	if in.DepartmentId != nil {
		if sysUserDo != nil {
			sysUserDo = sysUserDo.WithContext(l.ctx).Where(sysUserRepo.DepartmentID.Eq(int64(*in.DepartmentId)))
		}
	}
	if len(positionIds) > 0 {
		if sysUserDo != nil {
			sysUserDo = sysUserDo.WithContext(l.ctx).Where(sysUserRepo.ID.In(positionIds...))
		}
	}
	if sysUserDo != nil {
		sysUserDo = sysUserDo.WithContext(l.ctx).Where(sysUserRepo.DeletedAt.IsNull())
	}

	if sysUserDo != nil {
		limit, offset := gormutils.PaginateLimitOffsetNum(int(in.Page), int(in.PageSize))
		total, err := sysUserDo.Count()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		result, err := sysUserDo.Offset(offset).
			Limit(limit).
			Order(sysRoleRepo.ID.Asc()).
			Find()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}

		resp := &usercenter.UserListResp{}
		resp.Total = uint64(total)

		var sysRoles []*model.SysRole
		if len(userIds) > 0 {
			rSysRoleRepo := query.SysRole
			rUserRoleRepo := query.UserRole
			sysRoles, err = rSysRoleRepo.WithContext(l.ctx).
				Join(rUserRoleRepo, rUserRoleRepo.RoleID.
					EqCol(rSysRoleRepo.ID)).
				Where(rUserRoleRepo.UserID.In(userIds...)).Find()
			if err != nil {
				return nil, errorxplus.DefaultGormError(l.Logger, err, in)
			}
		}

		var sysPositions []*model.SysPosition
		if len(positionIds) > 0 {
			rSysPositionRepo := query.SysPosition
			rUserPositionRepo := query.UserPosition
			sysPositions, err = rSysPositionRepo.WithContext(l.ctx).Select(rSysPositionRepo.ALL, rUserPositionRepo.UserID).
				Join(rUserPositionRepo, rUserPositionRepo.PositionID.EqCol(rSysPositionRepo.ID)).
				Where(rUserPositionRepo.UserID.In(positionIds...)).Find()
			if err != nil {
				return nil, errorxplus.DefaultGormError(l.Logger, err, in)
			}
		}
		for _, v := range result {
			uStatus := new(uint32)
			*uStatus = uint32(*v.Status)
			uDepartmentId := new(uint64)
			*uDepartmentId = uint64(*v.DepartmentID)
			resp.Data = append(resp.Data, &usercenter.UserInfo{
				Id:           &v.ID,
				Avatar:       v.Avatar,
				RoleIds:      GetRoleIds(sysRoles),
				RoleCodes:    GetRoleCodes(sysRoles),
				Mobile:       v.Mobile,
				Email:        v.Email,
				Status:       uStatus,
				Username:     &v.Username,
				Nickname:     &v.Nickname,
				HomePath:     &v.HomePath,
				Description:  v.Description,
				DepartmentId: uDepartmentId,
				PositionIds:  GetPositionIds(sysPositions),
				CreatedAt:    pointy.GetPointer(v.CreatedAt.UnixMilli()),
				UpdatedAt:    pointy.GetPointer(v.UpdatedAt.UnixMilli()),
			})
		}

		return resp, nil

	}

	return nil, errorxplus.DefaultGormError(l.Logger, err, in)
}
