package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/config"
	"global-admin-common/enum/common"
	"global-admin-common/msg/logmsg"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"time"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateTokenLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateTokenLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateTokenLogic {
	return &UpdateTokenLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: token
func (l *UpdateTokenLogic) UpdateToken(in *usercenter.TokenInfo) (*usercenter.BaseResp, error) {
	sysTokenPo := &model.SysToken{}
	if in.Status != nil {
		uStatus := new(int32)
		*uStatus = int32(*in.Status)
		sysTokenPo.Status = uStatus
	}
	if in.Source != nil && len(strings.TrimSpace(*in.Source)) > 0 {
		sysTokenPo.Source = *in.Source
	}
	if in.UpdatedAt != nil {
		sysTokenPo.UpdatedAt = *pointy.GetTimeMilliPointer(in.UpdatedAt)
	} else {
		sysTokenPo.UpdatedAt = time.Now()
	}

	sysTokenRepo := query.SysToken

	_, err := sysTokenRepo.WithContext(l.ctx).Where(sysTokenRepo.ID.Eq(*in.Id)).Updates(sysTokenPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	token, err := sysTokenRepo.WithContext(l.ctx).Where(sysTokenRepo.ID.Eq(*in.Id)).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	if uint8(*in.Status) == common.StatusBanned {
		if token != nil {
			expiredTime := token.ExpiredAt.Sub(time.Now())
			if expiredTime > 0 {
				err = l.svcCtx.Redis.Set(l.ctx, config.RedisTokenPrefix+token.Token, "1", expiredTime).Err()
				if err != nil {
					logx.Errorw(logmsg.RedisError, logx.Field("detail", err.Error()))
					return nil, errorxplus.NewInternalError(admini18nconst.RedisError)
				}
			}
		}
	} else if uint8(*in.Status) == common.StatusNormal {
		err := l.svcCtx.Redis.Del(l.ctx, config.RedisTokenPrefix+token.Token).Err()
		if err != nil {
			logx.Errorw(logmsg.RedisError, logx.Field("detail", err.Error()))
			return nil, errorxplus.NewInternalError(admini18nconst.RedisError)
		}
	}
	return &usercenter.BaseResp{Msg: admini18nconst.UpdateSuccess}, nil
}
