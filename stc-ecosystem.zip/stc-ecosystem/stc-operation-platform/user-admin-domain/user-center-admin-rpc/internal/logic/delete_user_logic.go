package logic

import (
	"context"
	"errors"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type DeleteUserLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDeleteUserLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteUserLogic {
	return &DeleteUserLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: user
func (l *DeleteUserLogic) DeleteUser(in *usercenter.UUIDsReq) (*usercenter.BaseResp, error) {

	if len(in.Ids) <= 0 {
		return nil, errorxplus.DefaultGormError(l.Logger, errors.New("delete user invalid request param"), in)
	}
	sysUserRepo := query.SysUser
	_, err := sysUserRepo.WithContext(l.ctx).Where(sysUserRepo.ID.In(in.Ids...)).Delete()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.DeleteSuccess}, nil
}
