package logic

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"global-admin-common/admini18nconst"
	"global-admin-common/msg/logmsg"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"golang.org/x/oauth2"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"gorm.io/gorm"
	"io"
	"net/http"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type OauthCallbackLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

type userInfo struct {
	Email    string `json:"email"`
	NickName string `json:"nickName"`
	Picture  string `json:"picture"`
}

func NewOauthCallbackLogic(ctx context.Context, svcCtx *svc.ServiceContext) *OauthCallbackLogic {
	return &OauthCallbackLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: oauthprovider
func (l *OauthCallbackLogic) OauthCallback(in *usercenter.CallbackReq) (*usercenter.UserInfo, error) {

	provider := strings.Split(in.State, "-")[1]
	if _, ok := providerConfig[provider]; !ok {
		sysOauthProviderRepo := query.SysOauthProvider
		p, err := sysOauthProviderRepo.WithContext(l.ctx).Where(sysOauthProviderRepo.Name.Eq(provider)).First()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		providerConfig[provider] = oauth2.Config{
			ClientID:     p.ClientID,
			ClientSecret: p.ClientSecret,
			Endpoint: oauth2.Endpoint{
				AuthURL:   replaceKeywords(p.AuthURL, p),
				TokenURL:  p.TokenURL,
				AuthStyle: oauth2.AuthStyle(p.AuthStyle),
			},
			RedirectURL: p.RedirectURL,
			Scopes:      strings.Split(p.Scopes, " "),
		}
		if _, ok := userInfoURL[p.Name]; !ok {
			userInfoURL[p.Name] = p.InfoURL
		}
	}
	// get user information
	content, err := getUserInfo(providerConfig[provider], userInfoURL[provider], in.Code)
	if err != nil {
		return nil, errorxplus.NewInvalidArgumentError(err.Error())
	}

	var u userInfo
	err = json.Unmarshal(content, &u)
	if err != nil {
		return nil, errorxplus.NewInternalError(err.Error())
	}

	if len(strings.TrimSpace(u.Email)) > 0 {
		sysUserRepo := query.SysUser
		result, err := sysUserRepo.WithContext(l.ctx).Where(sysUserRepo.Email.Eq(u.Email)).First()
		if err != nil {
			switch {
			case errors.Is(err, gorm.ErrRecordNotFound):
				logx.Errorw(err.Error(), logx.Field("detail", in))
				return nil, errorxplus.NewInvalidArgumentError("login.userNotExist")
			default:
				logx.Errorw(logmsg.DatabaseError, logx.Field("detail", err.Error()))
			}
		}
		var sysRoles []*model.SysRole
		if result != nil && len(result.ID) > 0 {
			sysRoleRepo := query.SysRole
			userRoleRepo := query.UserRole
			sysRoles, err = sysRoleRepo.WithContext(l.ctx).Select(sysRoleRepo.ALL, userRoleRepo.UserID).
				Join(userRoleRepo, userRoleRepo.RoleID.EqCol(sysRoleRepo.ID)).
				Where(userRoleRepo.UserID.In(result.ID)).Find()
			if err != nil {
				return nil, errorxplus.DefaultGormError(l.Logger, err, in)
			}
		}

		if result != nil {
			uDepartmentId := new(uint64)
			*uDepartmentId = uint64(*result.DepartmentID)
			uStatus := new(uint32)
			*uStatus = uint32(*result.Status)
			return &usercenter.UserInfo{
				Nickname:     &result.Nickname,
				Avatar:       result.Avatar,
				RoleIds:      GetRoleIds(sysRoles),
				RoleCodes:    GetRoleCodes(sysRoles),
				Mobile:       result.Mobile,
				Email:        result.Email,
				Status:       uStatus,
				Id:           &result.ID,
				Username:     &result.Username,
				HomePath:     &result.HomePath,
				Description:  result.Description,
				DepartmentId: uDepartmentId,
				CreatedAt:    pointy.GetPointer(result.CreatedAt.UnixMilli()),
				UpdatedAt:    pointy.GetPointer(result.UpdatedAt.UnixMilli()),
			}, nil
		}

	}
	return nil, status.Error(codes.InvalidArgument, admini18nconst.Failed)
}
func getUserInfo(c oauth2.Config, infoURL string, code string) ([]byte, error) {
	token, err := c.Exchange(context.Background(), code)
	if err != nil {
		return nil, fmt.Errorf("code exchange failed: %s", err.Error())
	}
	var response *http.Response

	if c.Endpoint.AuthStyle == 1 {
		response, err = http.Get(strings.ReplaceAll(infoURL, "TOKEN", token.AccessToken))
		if err != nil {
			return nil, fmt.Errorf("failed to get user's information: %s", err.Error())
		}
	} else if c.Endpoint.AuthStyle == 2 {
		client := &http.Client{}
		request, err := http.NewRequest("GET", infoURL, nil)
		if err != nil {
			return nil, status.Error(codes.Internal, err.Error())
		}
		request.Header.Set("Accept", "application/json")
		request.Header.Set("Authorization", "Bearer "+token.AccessToken)
		response, err = client.Do(request)
		if err != nil {
			return nil, fmt.Errorf("failed to get user's information: %s", err.Error())
		}
	}
	defer response.Body.Close()
	contents, err := io.ReadAll(response.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %s", err.Error())
	}
	return contents, nil
}

func replaceKeywords(urlData string, oauthData *model.SysOauthProvider) (result string) {
	result = strings.ReplaceAll(urlData, "CLIENT_ID", oauthData.ClientID)
	result = strings.ReplaceAll(result, "SECRET", oauthData.ClientSecret)
	result = strings.ReplaceAll(result, "REDIRECT_URL", oauthData.RedirectURL)
	result = strings.ReplaceAll(result, "SCOPE", oauthData.Scopes)
	return result
}
