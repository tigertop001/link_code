package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type CreateDictionaryDetailLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateDictionaryDetailLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateDictionaryDetailLogic {
	return &CreateDictionaryDetailLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// DictionaryDetail management
func (l *CreateDictionaryDetailLogic) CreateDictionaryDetail(in *usercenter2.DictionaryDetailInfo) (*usercenter2.BaseIDResp, error) {
	sysDictionaryDetailPo := &model.SysDictionaryDetail{}
	if in.Status != nil {
		uStatus := new(int32)
		*uStatus = int32(*in.Status)
		sysDictionaryDetailPo.Status = uStatus
	}
	if in.Title != nil && len(strings.TrimSpace(*in.Title)) > 0 {
		sysDictionaryDetailPo.Title = *in.Title
	}
	if in.Key != nil && len(strings.TrimSpace(*in.Key)) > 0 {
		sysDictionaryDetailPo.Key = *in.Key
	}
	if in.Value != nil && len(strings.TrimSpace(*in.Value)) > 0 {
		sysDictionaryDetailPo.Value = *in.Value
	}
	if in.Sort != nil {
		sysDictionaryDetailPo.Sort = int32(*in.Sort)
	}
	if in.DictionaryId != nil {
		uDictionaryId := new(int64)
		*uDictionaryId = int64(*in.DictionaryId)
		sysDictionaryDetailPo.DictionaryID = uDictionaryId
	}
	sysDictionaryDetailRepo := query.SysDictionaryDetail
	err := sysDictionaryDetailRepo.WithContext(l.ctx).Create(sysDictionaryDetailPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter2.BaseIDResp{Id: uint64(sysDictionaryDetailPo.ID), Msg: admini18nconst.CreateSuccess}, nil
}
