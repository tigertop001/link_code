package logic

import (
	"context"
	"errors"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateDepartmentLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateDepartmentLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateDepartmentLogic {
	return &UpdateDepartmentLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: department
func (l *UpdateDepartmentLogic) UpdateDepartment(in *usercenter.DepartmentInfo) (*usercenter.BaseResp, error) {
	sysDepartmentPo := &model.SysDepartment{}
	db := l.svcCtx.DB
	db.Raw("WITH RECURSIVE `ancestors` AS (SELECT `sys_departments`.`id`, `sys_departments`.`parent_id`, 1 as level FROM `sys_departments` WHERE `id` = ? UNION ALL SELECT `sys_departments`.`id`, `sys_departments`.`parent_id`, ancestors.level + 1 as level FROM `sys_departments` JOIN `ancestors` ON `sys_departments`.`id` = `ancestors`.`parent_id`) SELECT `ancestors`.`id` FROM `ancestors`", in.ParentId).Scan(sysDepartmentPo)

	if in.Id == nil {
		return nil, errorxplus.DefaultGormError(l.Logger, errors.New("update id empty"), in)
	} else {
		sysDepartmentPo.ID = int64(*in.Id)
	}

	if in.Sort != nil {
		sysDepartmentPo.Sort = int32(*in.Sort)
	}
	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysDepartmentPo.Name = *in.Name
	}
	if in.Ancestors != nil && len(strings.TrimSpace(*in.Ancestors)) > 0 {
		sysDepartmentPo.Ancestors = in.Ancestors
	}
	if in.Leader != nil && len(strings.TrimSpace(*in.Leader)) > 0 {
		sysDepartmentPo.Leader = in.Leader
	}
	if in.Phone != nil && len(strings.TrimSpace(*in.Phone)) > 0 {
		sysDepartmentPo.Phone = in.Phone
	}
	if in.Email != nil && len(strings.TrimSpace(*in.Email)) > 0 {
		sysDepartmentPo.Email = in.Email
	}
	if in.Remark != nil && len(strings.TrimSpace(*in.Remark)) > 0 {
		sysDepartmentPo.Remark = in.Remark
	}
	if in.ParentId != nil {
		dParentId := new(int64)
		*dParentId = int64(*in.ParentId)
		sysDepartmentPo.ParentID = dParentId
	}

	sysDepartmentRepo := query.SysDepartment
	_, err := sysDepartmentRepo.WithContext(l.ctx).Where(sysDepartmentRepo.ID.Eq(int64(*in.Id))).Updates(sysDepartmentPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, errors.New("update id empty"), in)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.UpdateSuccess}, nil
}
