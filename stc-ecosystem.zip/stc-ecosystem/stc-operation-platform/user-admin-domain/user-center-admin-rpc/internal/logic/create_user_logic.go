package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/smops"
	"global-admin-common/utils/errorxplus"
	"gorm.io/gorm/clause"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateUserLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateUserLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateUserLogic {
	return &CreateUserLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// User management
func (l *CreateUserLogic) CreateUser(in *usercenter.UserInfo) (*usercenter.BaseUUIDResp, error) {

	sysUserTx := query.Use(l.svcCtx.DB)
	var resultId *string
	err := sysUserTx.Transaction(func(tx *query.Query) error {
		sysUserPo := &model.SysUser{}
		if in.Username != nil && len(strings.TrimSpace(*in.Username)) > 0 {
			sysUserPo.Username = *in.Username
		}
		if in.Password != nil && len(strings.TrimSpace(*in.Password)) > 0 {
			sysUserPo.Password = *in.Password
		}
		if in.Nickname != nil && len(strings.TrimSpace(*in.Nickname)) > 0 {
			sysUserPo.Nickname = *in.Nickname
		}
		if in.Email != nil && len(strings.TrimSpace(*in.Email)) > 0 {
			sysUserPo.Email = in.Email
		}
		if in.Mobile != nil && len(strings.TrimSpace(*in.Mobile)) > 0 {
			sysUserPo.Mobile = in.Mobile
		}
		if in.Avatar != nil && len(strings.TrimSpace(*in.Avatar)) > 0 {
			sysUserPo.Avatar = in.Avatar
		}
		if in.HomePath != nil && len(strings.TrimSpace(*in.HomePath)) > 0 {
			sysUserPo.HomePath = *in.HomePath
		}
		if in.Description != nil && len(strings.TrimSpace(*in.Description)) > 0 {
			sysUserPo.Description = in.Description
		}
		if in.DepartmentId != nil {
			uDepartmentId := new(int64)
			*uDepartmentId = int64(*in.DepartmentId)
			sysUserPo.DepartmentID = uDepartmentId
		}

		err := tx.SysUser.WithContext(l.ctx).Create(sysUserPo)
		if err != nil {
			return err
		}
		resultId = &sysUserPo.ID

		iRoleIds, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.RoleIds)
		if err != nil {
			return err
		}

		userRoles := make([]*model.UserRole, 0)
		for _, iRoleId := range iRoleIds {
			userRoles = append(userRoles, &model.UserRole{
				UserID: sysUserPo.ID,
				RoleID: iRoleId,
			})
		}

		err = tx.UserRole.WithContext(l.ctx).Clauses(clause.OnConflict{
			UpdateAll: true,
		}).CreateInBatches(userRoles, len(userRoles))
		if err != nil {
			return err
		}

		iPositionIds, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.PositionIds)
		if err != nil {
			return err
		}

		userPositions := make([]*model.UserPosition, 0)
		for _, iPositionId := range iPositionIds {
			userPositions = append(userPositions, &model.UserPosition{
				UserID:     sysUserPo.ID,
				PositionID: iPositionId,
			})
		}

		err = tx.UserPosition.WithContext(l.ctx).Clauses(clause.OnConflict{
			UpdateAll: true,
		}).CreateInBatches(userPositions, len(userPositions))

		if err != nil {
			return err
		}
		return nil
	})
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseUUIDResp{
		Id:  *resultId,
		Msg: admini18nconst.CreateSuccess}, nil
}
