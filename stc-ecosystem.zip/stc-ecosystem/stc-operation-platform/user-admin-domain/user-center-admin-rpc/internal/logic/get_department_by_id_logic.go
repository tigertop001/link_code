package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type GetDepartmentByIdLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetDepartmentByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetDepartmentByIdLogic {
	return &GetDepartmentByIdLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: department
func (l *GetDepartmentByIdLogic) GetDepartmentById(in *usercenter.IDReq) (*usercenter.DepartmentInfo, error) {

	sysDepartmentRepo := query.SysDepartment
	result, err := sysDepartmentRepo.WithContext(l.ctx).Where(sysDepartmentRepo.ID.Eq(int64(in.Id))).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	uId := new(uint64)
	*uId = uint64(result.ID)
	uSort := new(uint32)
	*uSort = uint32(result.Sort)
	uParentId := new(uint64)
	*uParentId = uint64(*result.ParentID)
	return &usercenter.DepartmentInfo{
		Id:        uId,
		CreatedAt: pointy.GetPointer(result.CreatedAt.UnixMilli()),
		UpdatedAt: pointy.GetPointer(result.UpdatedAt.UnixMilli()),
		Status:    pointy.GetPointer(uint32(*result.Status)),
		Sort:      uSort,
		Name:      &result.Name,
		Ancestors: result.Ancestors,
		Leader:    result.Leader,
		Phone:     result.Phone,
		Email:     result.Email,
		Remark:    result.Remark,
		ParentId:  uParentId,
	}, nil
}
