package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/smops"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type DeleteDictionaryLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDeleteDictionaryLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteDictionaryLogic {
	return &DeleteDictionaryLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: dictionary
func (l *DeleteDictionaryLogic) DeleteDictionary(in *usercenter2.IDsReq) (*usercenter2.BaseResp, error) {

	dictionaryTx := query.Use(l.svcCtx.DB)
	err := dictionaryTx.Transaction(func(tx *query.Query) error {
		sysDictionaryRepo := tx.SysDictionary
		sysDictionaryDetailRepo := tx.SysDictionaryDetail
		iIds, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.Ids)
		if err != nil {
			return err
		}
		subQuery := sysDictionaryRepo.WithContext(l.ctx).Select(sysDictionaryRepo.ID).Where(sysDictionaryRepo.ID.In(iIds...))
		_, err = sysDictionaryDetailRepo.WithContext(l.ctx).Where(subQuery).Delete()
		if err != nil {
			return err
		}
		_, err = sysDictionaryRepo.WithContext(l.ctx).Where(sysDictionaryRepo.ID.In(iIds...)).Delete()
		if err != nil {
			return err
		}
		return nil
	})
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter2.BaseResp{Msg: admini18nconst.DeleteSuccess}, nil
}
