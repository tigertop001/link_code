package logic

import (
	"context"
	"errors"
	"global-admin-common/gormutils"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/const/sql"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetOauthProviderListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetOauthProviderListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetOauthProviderListLogic {
	return &GetOauthProviderListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: oauthprovider
func (l *GetOauthProviderListLogic) GetOauthProviderList(in *usercenter.OauthProviderListReq) (*usercenter.OauthProviderListResp, error) {

	sysOauthProviderRepo := query.SysOauthProvider
	var sysOauthProviderDo query.ISysOauthProviderDo
	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		safeName, _ := gormutils.Escape(*in.Name)
		sysOauthProviderDo = sysOauthProviderRepo.WithContext(l.ctx).Where(sysOauthProviderRepo.Name.Like(gormutils.LikeExpPercentJoiner(safeName, sql.LIKE_BLURRY_PLACEHOLDER)))
	}
	if sysOauthProviderDo != nil {

		total, err := sysOauthProviderDo.Count()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		limit, offset := gormutils.PaginateLimitOffsetNum(int(in.Page), int(in.PageSize))
		result, err := sysOauthProviderDo.WithContext(l.ctx).Offset(offset).
			Limit(limit).
			Order(sysOauthProviderRepo.ID.Asc()).Find()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		resp := &usercenter.OauthProviderListResp{}
		resp.Total = uint64(total)
		for _, v := range result {
			uId := new(uint64)
			*uId = uint64(v.ID)
			uAuthStyle := new(uint64)
			*uAuthStyle = uint64(v.AuthStyle)
			resp.Data = append(resp.Data, &usercenter.OauthProviderInfo{
				Id:           uId,
				CreatedAt:    pointy.GetPointer(v.CreatedAt.UnixMilli()),
				UpdatedAt:    pointy.GetPointer(v.UpdatedAt.UnixMilli()),
				Name:         &v.Name,
				ClientId:     &v.ClientID,
				ClientSecret: &v.ClientSecret,
				RedirectUrl:  &v.RedirectURL,
				Scopes:       &v.Scopes,
				AuthUrl:      &v.AuthURL,
				TokenUrl:     &v.TokenURL,
				AuthStyle:    uAuthStyle,
				InfoUrl:      &v.InfoURL,
			})
		}
		return resp, nil
	}

	return nil, errorxplus.DefaultGormError(l.Logger, errors.New("OauthProvider nil pointer"), in)
}
