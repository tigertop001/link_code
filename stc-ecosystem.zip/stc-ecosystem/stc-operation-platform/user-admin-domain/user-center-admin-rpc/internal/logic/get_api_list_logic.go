package logic

import (
	"context"
	"errors"
	"global-admin-common/gormutils"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/const/sql"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetApiListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetApiListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetApiListLogic {
	return &GetApiListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: api
func (l *GetApiListLogic) GetApiList(in *usercenter.ApiListReq) (*usercenter.ApiListResp, error) {

	sysApiRepo := query.SysAPI
	var sysApiDo query.ISysAPIDo

	if in.Path != nil && len(strings.TrimSpace(*in.Path)) > 0 {
		safePath, _ := gormutils.Escape(*in.Path)
		sysApiDo = sysApiRepo.WithContext(l.ctx).Where(sysApiRepo.Path.Like(gormutils.LikeExpPercentJoiner(safePath, sql.LIKE_BLURRY_PLACEHOLDER)))
	}

	if in.Description != nil && len(strings.TrimSpace(*in.Description)) > 0 {
		safeDescription, _ := gormutils.Escape(*in.Description)
		sysApiDo = sysApiRepo.WithContext(l.ctx).Where(sysApiRepo.Description.Like(gormutils.LikeExpPercentJoiner(safeDescription, sql.LIKE_BLURRY_PLACEHOLDER)))
	}

	if in.ApiGroup != nil && len(strings.TrimSpace(*in.ApiGroup)) > 0 {
		safeApiGroup, _ := gormutils.Escape(*in.ApiGroup)
		sysApiDo = sysApiRepo.WithContext(l.ctx).Where(sysApiRepo.APIGroup.Like(gormutils.LikeExpPercentJoiner(safeApiGroup, sql.LIKE_BLURRY_PLACEHOLDER)))
	}

	if in.Method != nil && len(strings.TrimSpace(*in.Method)) > 0 {
		sysApiDo = sysApiRepo.WithContext(l.ctx).Where(sysApiRepo.Method.Eq(*in.Method))
	}

	if in.ServiceName != nil && len(strings.TrimSpace(*in.ServiceName)) > 0 {
		safeServiceName, _ := gormutils.Escape(*in.ServiceName)
		sysApiDo = sysApiRepo.WithContext(l.ctx).Where(sysApiRepo.ServiceName.Like(gormutils.LikeExpPercentJoiner(safeServiceName, sql.LIKE_BLURRY_PLACEHOLDER)))
	}

	if sysApiDo != nil {
		limit, offset := gormutils.PaginateLimitOffsetNum(int(in.Page), int(in.PageSize))
		results, err := sysApiDo.Offset(offset).Limit(limit).Order(sysApiRepo.ID.Asc()).Find()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		total, err := sysApiDo.Count()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}

		resp := &usercenter.ApiListResp{}
		resp.Total = uint64(total)

		for _, v := range results {
			uId := new(uint64)
			*uId = uint64(v.ID)
			resp.Data = append(resp.Data, &usercenter.ApiInfo{
				Id:          uId,
				CreatedAt:   pointy.GetPointer(v.CreatedAt.UnixMilli()),
				Path:        &v.Path,
				Description: &v.Description,
				ApiGroup:    &v.APIGroup,
				Method:      &v.Method,
				IsRequired:  &v.IsRequired,
				ServiceName: &v.ServiceName,
			})
		}
		return resp, nil
	}

	return nil, errorxplus.DefaultGormError(l.Logger, errors.New("request data is empty"), in)

}
