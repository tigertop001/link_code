package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type UpdateDictionaryDetailLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateDictionaryDetailLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateDictionaryDetailLogic {
	return &UpdateDictionaryDetailLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: dictionarydetail
func (l *UpdateDictionaryDetailLogic) UpdateDictionaryDetail(in *usercenter.DictionaryDetailInfo) (*usercenter.BaseResp, error) {

	sysDictionaryDetailPo := &model.SysDictionaryDetail{}
	if in.Status != nil {
		uStatus := new(int32)
		*uStatus = int32(*in.Status)
		sysDictionaryDetailPo.Status = uStatus
	}
	if in.Title != nil && len(strings.TrimSpace(*in.Title)) > 0 {
		sysDictionaryDetailPo.Title = *in.Title
	}
	if in.Key != nil && len(strings.TrimSpace(*in.Key)) > 0 {
		sysDictionaryDetailPo.Key = *in.Key
	}
	if in.Value != nil && len(strings.TrimSpace(*in.Value)) > 0 {
		sysDictionaryDetailPo.Value = *in.Value
	}
	if in.Sort != nil {
		sysDictionaryDetailPo.Sort = int32(*in.Sort)
	}
	if in.DictionaryId != nil {
		uDictionaryID := new(int64)
		*uDictionaryID = int64(*in.DictionaryId)
		sysDictionaryDetailPo.DictionaryID = uDictionaryID
	}

	sysDictionaryDetailRepo := query.SysDictionaryDetail
	_, err := sysDictionaryDetailRepo.WithContext(l.ctx).Where(sysDictionaryDetailRepo.ID.Eq(int64(*in.Id))).Updates(sysDictionaryDetailPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{}, nil
}
