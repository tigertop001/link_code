package logic

import (
	"context"
	"errors"
	"global-admin-common/gormutils"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/const/sql"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetPositionListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetPositionListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetPositionListLogic {
	return &GetPositionListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: position
func (l *GetPositionListLogic) GetPositionList(in *usercenter.PositionListReq) (*usercenter.PositionListResp, error) {

	sysPositionRepo := query.SysPosition
	var sysPositionDo query.ISysPositionDo
	if in.Name != nil && len(*in.Name) > 0 {
		safeName, _ := gormutils.Escape(*in.Name)
		sysPositionDo = sysPositionRepo.WithContext(l.ctx).Where(sysPositionRepo.Name.Like(gormutils.LikeExpPercentJoiner(safeName, sql.LIKE_BLURRY_PLACEHOLDER)))
	}
	if in.Code != nil && len(*in.Code) > 0 {
		safeCode, _ := gormutils.Escape(*in.Code)
		sysPositionDo = sysPositionRepo.WithContext(l.ctx).Where(sysPositionRepo.Name.Like(gormutils.LikeExpPercentJoiner(safeCode, sql.LIKE_BLURRY_PLACEHOLDER)))
	}

	if in.Remark != nil && len(*in.Remark) > 0 {
		safeRemark, _ := gormutils.Escape(*in.Remark)
		sysPositionDo = sysPositionRepo.WithContext(l.ctx).Where(sysPositionRepo.Name.Like(gormutils.LikeExpPercentJoiner(safeRemark, sql.LIKE_BLURRY_PLACEHOLDER)))
	}

	if sysPositionDo != nil {
		limit, offset := gormutils.PaginateLimitOffsetNum(int(in.Page), int(in.PageSize))
		total, err := sysPositionDo.Count()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		results, err := sysPositionDo.Offset(offset).Limit(limit).Order(sysPositionRepo.ID.Asc()).Find()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}

		resp := &usercenter.PositionListResp{}
		resp.Total = uint64(total)
		for _, v := range results {
			uId := new(uint64)
			*uId = uint64(v.ID)
			uSort := new(uint32)
			*uSort = uint32(v.Sort)
			uStatus := new(uint32)
			*uStatus = uint32(*v.Status)
			resp.Data = append(resp.Data, &usercenter.PositionInfo{
				Id:        uId,
				CreatedAt: pointy.GetPointer(v.CreatedAt.UnixMilli()),
				UpdatedAt: pointy.GetPointer(v.UpdatedAt.UnixMilli()),
				Status:    uStatus,
				Sort:      uSort,
				Name:      &v.Name,
				Code:      &v.Code,
				Remark:    v.Remark,
			})
		}
		return resp, nil

	}

	return nil, errorxplus.DefaultGormError(l.Logger, errors.New("request param invalid"), in)
}
