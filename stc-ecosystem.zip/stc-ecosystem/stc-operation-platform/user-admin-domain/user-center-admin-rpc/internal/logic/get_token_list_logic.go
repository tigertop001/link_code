package logic

import (
	"context"
	"global-admin-common/gormutils"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetTokenListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetTokenListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetTokenListLogic {
	return &GetTokenListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: token
func (l *GetTokenListLogic) GetTokenList(in *usercenter.TokenListReq) (*usercenter.TokenListResp, error) {

	var sysTokens []*model.SysToken
	var total int64
	var err error
	sysTokenRepo := query.SysToken
	sysUserRepo := query.SysUser
	limit, offset := gormutils.PaginateLimitOffsetNum(int(in.Page), int(in.PageSize))
	if in.Username == nil && in.Uuid == nil && in.Nickname == nil && in.Email == nil {
		var sysTokenDo query.ISysTokenDo
		sysTokenDo = sysTokenRepo.WithContext(l.ctx)
		sysTokens, err = sysTokenDo.Limit(limit).Offset(offset).Find()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		total, err = sysTokenDo.Count()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}

	} else {
		var sysUserDo query.ISysUserDo
		if in.Uuid != nil && len(strings.TrimSpace(*in.Uuid)) > 0 {
			sysUserDo = sysUserRepo.WithContext(l.ctx).Where(sysUserRepo.ID.Eq(*in.Uuid))
		}
		if in.Email != nil && len(strings.TrimSpace(*in.Email)) > 0 {
			if sysUserDo != nil {
				sysUserDo.WithContext(l.ctx).Where(sysUserRepo.Email.Eq(*in.Email))
			}
		}
		if in.Nickname != nil && len(strings.TrimSpace(*in.Nickname)) > 0 {
			if sysUserDo != nil {
				sysUserDo.WithContext(l.ctx).Where(sysUserRepo.Nickname.Eq(*in.Nickname))
			}
		}

		if sysUserDo != nil {
			user, err := sysUserDo.WithContext(l.ctx).First()
			if err != nil {
				return nil, errorxplus.DefaultGormError(l.Logger, err, in)
			}
			var sysTokenDo query.ISysTokenDo
			sysTokenDo = sysTokenRepo.WithContext(l.ctx).Where(sysTokenRepo.UUID.Eq(user.ID))
			total, err = sysTokenDo.Count()
			if err != nil {
				return nil, errorxplus.DefaultGormError(l.Logger, err, in)
			}
			sysTokens, err = sysTokenDo.Limit(limit).Offset(offset).Find()
			if err != nil {
				return nil, errorxplus.DefaultGormError(l.Logger, err, in)
			}
		}

	}
	resp := &usercenter.TokenListResp{}

	resp.Total = uint64(total)
	for _, v := range sysTokens {
		uStatus := new(uint32)
		*uStatus = uint32(*v.Status)
		resp.Data = append(resp.Data, &usercenter.TokenInfo{
			Id:        &v.ID,
			Uuid:      &v.UUID,
			Token:     &v.Token,
			Status:    uStatus,
			Source:    &v.Source,
			Username:  &v.Username,
			ExpiredAt: pointy.GetPointer(v.ExpiredAt.UnixMilli()),
			CreatedAt: pointy.GetPointer(v.CreatedAt.UnixMilli()),
		})
	}

	return resp, nil
}
