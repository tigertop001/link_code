package logic

import (
	"context"
	"global-admin-common/gormutils"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetMenuListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetMenuListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetMenuListLogic {
	return &GetMenuListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: menu
func (l *GetMenuListLogic) GetMenuList(in *usercenter.PageInfoReq) (*usercenter.MenuInfoList, error) {

	sysMenuRepo := query.SysMenu
	var sysMenuDo query.ISysMenuDo
	var menuRoleUns []model.MenuRoleUn
	var total int64
	limit, offset := gormutils.PaginateLimitOffsetNum(int(in.Page), int(in.PageSize))
	sysMenuDo = sysMenuRepo.WithContext(l.ctx)
	total, err := sysMenuDo.Count()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	err = sysMenuDo.Offset(offset).
		Limit(limit).
		Order(sysMenuRepo.ID.Asc()).
		Scan(&menuRoleUns)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	resp := &usercenter.MenuInfoList{}
	resp.Total = uint64(total)
	for _, m := range menuRoleUns {
		uId := new(uint64)
		*uId = uint64(m.ID)
		uMenuType := new(uint32)
		*uMenuType = uint32(m.MenuType)
		uMenuLevel := new(uint32)
		*uMenuLevel = uint32(m.MenuLevel)
		uParentID := new(uint64)
		*uParentID = uint64(*m.ParentID)
		uSort := new(uint32)
		*uSort = uint32(m.Sort)
		uDynamicLevel := new(uint32)
		*uDynamicLevel = uint32(*m.DynamicLevel)
		resp.Data = append(resp.Data, &usercenter.MenuInfo{
			Id:          uId,
			CreatedAt:   pointy.GetPointer(m.CreatedAt.UnixMilli()),
			UpdatedAt:   pointy.GetPointer(m.UpdatedAt.UnixMilli()),
			MenuType:    uMenuType,
			Level:       uMenuLevel,
			ParentId:    uParentID,
			Path:        m.Path,
			Name:        &m.Name,
			Redirect:    m.Redirect,
			Component:   m.Component,
			Sort:        uSort,
			ServiceName: m.ServiceName,
			Meta: &usercenter.Meta{
				Title:              &m.Title,
				Icon:               &m.Icon,
				HideMenu:           m.HideMenu,
				HideBreadcrumb:     m.HideBreadcrumb,
				IgnoreKeepAlive:    m.IgnoreKeepAlive,
				HideTab:            m.HideTab,
				FrameSrc:           m.FrameSrc,
				CarryParam:         m.CarryParam,
				HideChildrenInMenu: m.HideChildrenInMenu,
				Affix:              m.Affix,
				DynamicLevel:       uDynamicLevel,
				RealPath:           m.RealPath,
			},
		})
	}

	return resp, nil
}
