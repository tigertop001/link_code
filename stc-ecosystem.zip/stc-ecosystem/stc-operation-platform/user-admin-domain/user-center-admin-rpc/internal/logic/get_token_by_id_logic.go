package logic

import (
	"context"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetTokenByIdLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetTokenByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetTokenByIdLogic {
	return &GetTokenByIdLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: token
func (l *GetTokenByIdLogic) GetTokenById(in *usercenter.UUIDReq) (*usercenter.TokenInfo, error) {
	sysTokenRepo := query.SysToken
	result, err := sysTokenRepo.WithContext(l.ctx).Where(sysTokenRepo.ID.Eq(in.Id)).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	uStatus := new(uint32)
	*uStatus = uint32(*result.Status)
	return &usercenter.TokenInfo{
		Id:        &result.ID,
		CreatedAt: pointy.GetPointer(result.CreatedAt.UnixMilli()),
		UpdatedAt: pointy.GetPointer(result.UpdatedAt.UnixMilli()),
		Status:    uStatus,
		Uuid:      &result.UUID,
		Token:     &result.Token,
		Source:    &result.Source,
		Username:  &result.Username,
		ExpiredAt: pointy.GetPointer(result.ExpiredAt.UnixMilli()),
	}, nil
}
