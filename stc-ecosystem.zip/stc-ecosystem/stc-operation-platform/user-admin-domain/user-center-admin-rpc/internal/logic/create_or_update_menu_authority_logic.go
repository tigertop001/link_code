package logic

import (
	"context"
	"errors"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"gorm.io/gorm/clause"
	"time"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateOrUpdateMenuAuthorityLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateOrUpdateMenuAuthorityLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateOrUpdateMenuAuthorityLogic {
	return &CreateOrUpdateMenuAuthorityLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: authority
func (l *CreateOrUpdateMenuAuthorityLogic) CreateOrUpdateMenuAuthority(in *usercenter.RoleMenuAuthorityReq) (*usercenter.BaseResp, error) {

	if in.RoleId == 0 {
		return nil, errorxplus.DefaultGormError(l.Logger, errors.New("role id empty"), in)
	}

	if len(in.MenuId) == 0 {
		return nil, errorxplus.DefaultGormError(l.Logger, errors.New("menuIds id empty"), in)
	}

	rmTx := query.Use(l.svcCtx.DB)
	err := rmTx.Transaction(func(tx *query.Query) error {
		_, err := tx.SysRole.WithContext(l.ctx).Where(tx.SysRole.ID.Eq(int64(in.RoleId))).Update(&tx.SysRole.UpdatedAt, time.Now())
		if err != nil {
			return err
		}
		_, err = tx.RoleMenu.WithContext(l.ctx).Where(tx.RoleMenu.RoleID.Eq(int64(in.RoleId))).Delete()
		if err != nil {
			return err
		}

		roleMenuPos := make([]*model.RoleMenu, 0)

		for _, id := range in.MenuId {
			roleMenuPos = append(roleMenuPos, &model.RoleMenu{
				RoleID: int64(in.RoleId),
				MenuID: int64(id),
			})
		}

		err = tx.RoleMenu.WithContext(l.ctx).Clauses(clause.OnConflict{
			UpdateAll: true,
		}).CreateInBatches(roleMenuPos, len(roleMenuPos))

		if err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{
		Msg: admini18nconst.UpdateSuccess,
	}, nil
}
