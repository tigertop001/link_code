package logic

import (
	"context"
	"errors"
	"global-admin-common/admini18nconst"
	"global-admin-common/enum/common"
	"global-admin-common/utils/encrypt"
	"global-admin-common/utils/errorxplus"
	"gorm.io/gorm/clause"
	"strings"
	"time"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateUserLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateUserLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateUserLogic {
	return &UpdateUserLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: user
func (l *UpdateUserLogic) UpdateUser(in *usercenter.UserInfo) (*usercenter.BaseResp, error) {

	updateUserTx := query.Use(l.svcCtx.DB)
	err := updateUserTx.Transaction(func(tx *query.Query) error {
		sysUserPo := &model.SysUser{}
		if in.Id != nil && len(strings.TrimSpace(*in.Id)) > 0 {
			sysUserPo.ID = *in.Id
			_, err := tx.UserRole.WithContext(l.ctx).Where(tx.UserRole.UserID.Eq(*in.Id)).Delete()
			if err != nil {
				return err
			}
			_, err = tx.UserPosition.WithContext(l.ctx).Where(tx.UserPosition.UserID.Eq(*in.Id)).Delete()
			if err != nil {
				return err
			}
		} else {
			return errors.New("request id empty")
		}

		if in.Username != nil && len(strings.TrimSpace(*in.Username)) > 0 {
			sysUserPo.Username = *in.Username
		}
		if in.Nickname != nil && len(strings.TrimSpace(*in.Nickname)) > 0 {
			sysUserPo.Nickname = *in.Nickname
		}
		if in.Email != nil && len(strings.TrimSpace(*in.Email)) > 0 {
			sysUserPo.Email = in.Email
		}
		if in.Mobile != nil && len(strings.TrimSpace(*in.Mobile)) > 0 {
			sysUserPo.Mobile = in.Mobile
		}
		if in.Avatar != nil && len(strings.TrimSpace(*in.Avatar)) > 0 {
			sysUserPo.Avatar = in.Avatar
		}
		if in.HomePath != nil && len(strings.TrimSpace(*in.HomePath)) > 0 {
			sysUserPo.HomePath = *in.HomePath
		}
		if in.Description != nil && len(strings.TrimSpace(*in.Description)) > 0 {
			sysUserPo.Description = in.Description
		}
		if in.DepartmentId != nil {
			uDepartmentId := new(int64)
			*uDepartmentId = int64(*in.DepartmentId)
			sysUserPo.DepartmentID = uDepartmentId
		}
		if in.Status != nil {
			uStatus := new(int32)
			*uStatus = int32(*in.Status)
			sysUserPo.Status = uStatus
			_, err := tx.SysToken.WithContext(l.ctx).Where(tx.SysToken.ID.Eq(*in.Id)).UpdateSimple(tx.SysToken.UpdatedAt.Value(time.Now()), tx.SysToken.Status.Value(*uStatus))
			if err != nil {
				return err
			}
		}
		if in.Password != nil && len(strings.TrimSpace(*in.Password)) > 0 {
			sysUserPo.Password = encrypt.BcryptEncrypt(*in.Password)
		}

		_, err := tx.SysUser.WithContext(l.ctx).Where(tx.SysUser.ID.Eq(*in.Id)).Updates(sysUserPo)
		if err != nil {
			return err
		}

		if len(in.PositionIds) > 0 {
			var userPositions []*model.UserPosition
			for _, id := range in.PositionIds {
				userPositions = append(userPositions, &model.UserPosition{
					UserID:     *in.Id,
					PositionID: int64(id),
				})
			}

			err := tx.UserPosition.WithContext(l.ctx).Clauses(clause.OnConflict{
				UpdateAll: true,
			}).CreateInBatches(userPositions, len(userPositions))
			if err != nil {
				return err
			}
		}

		if len(in.RoleIds) > 0 {
			var userRoles []*model.UserRole
			for _, id := range in.RoleIds {
				userRoles = append(userRoles, &model.UserRole{
					UserID: *in.Id,
					RoleID: int64(id),
				})
			}

			err := tx.UserRole.WithContext(l.ctx).Clauses(clause.OnConflict{
				UpdateAll: true,
			}).CreateInBatches(userRoles, len(userRoles))
			if err != nil {
				return err
			}
		}
		if in.Password != nil || in.RoleIds != nil || in.PositionIds != nil || (in.Status != nil && uint8(*in.Status) != common.StatusNormal) {
			_, err := NewBlockUserAllTokenLogic(l.ctx, l.svcCtx).BlockUserAllToken(&usercenter.UUIDReq{Id: *in.Id})
			if err != nil {
				return err
			}
		}
		return nil
	})
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.UpdateSuccess}, nil
}
