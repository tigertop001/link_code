package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/enum/common"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateMenuLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateMenuLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateMenuLogic {
	return &UpdateMenuLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: menu
func (l *UpdateMenuLogic) UpdateMenu(in *usercenter.MenuInfo) (*usercenter.BaseResp, error) {

	var menuLevel uint32
	sysMenuRepo := query.SysMenu
	if *in.ParentId != common.DefaultParentId {
		m, err := sysMenuRepo.WithContext(l.ctx).Where(sysMenuRepo.ID.Eq(int64(*in.ParentId))).First()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		menuLevel = uint32(m.MenuLevel + 1)
	} else {
		menuLevel = 1
	}

	sysMenuPo := &model.SysMenu{}
	sysMenuPo.MenuLevel = int32(menuLevel)
	if in.MenuType != nil {
		sysMenuPo.MenuType = int32(*in.MenuType)
	}
	if in.ParentId != nil {
		uParentID := new(int64)
		*uParentID = int64(*in.ParentId)
		sysMenuPo.ParentID = uParentID
	}
	if in.Path != nil && len(strings.TrimSpace(*in.Path)) > 0 {
		sysMenuPo.Path = in.Path
	}
	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysMenuPo.Name = *in.Name
	}
	if in.Redirect != nil && len(strings.TrimSpace(*in.Redirect)) > 0 {
		sysMenuPo.Redirect = in.Redirect
	}
	if in.Component != nil && len(strings.TrimSpace(*in.Component)) > 0 {
		sysMenuPo.Component = in.Component
	}
	if in.Sort != nil {
		sysMenuPo.Sort = int32(*in.Sort)
	}
	if in.Disabled != nil {
		sysMenuPo.Disabled = in.Disabled
	}
	if in.ServiceName != nil && len(strings.TrimSpace(*in.ServiceName)) > 0 {
		sysMenuPo.ServiceName = in.ServiceName
	}
	if in.Meta != nil {
		if in.Meta.Title != nil && len(strings.TrimSpace(*in.Meta.Title)) > 0 {
			sysMenuPo.Title = *in.Meta.Title
		}
		if in.Meta.Icon != nil && len(strings.TrimSpace(*in.Meta.Icon)) > 0 {
			sysMenuPo.Icon = *in.Meta.Icon
		}
		if in.Meta.HideMenu != nil {
			sysMenuPo.HideMenu = in.Meta.HideMenu
		}
		if in.Meta.HideBreadcrumb != nil {
			sysMenuPo.HideBreadcrumb = in.Meta.HideBreadcrumb
		}
		if in.Meta.IgnoreKeepAlive != nil {
			sysMenuPo.IgnoreKeepAlive = in.Meta.IgnoreKeepAlive
		}
		if in.Meta.HideTab != nil {
			sysMenuPo.HideTab = in.Meta.HideTab
		}
		if in.Meta.FrameSrc != nil && len(strings.TrimSpace(*in.Meta.FrameSrc)) > 0 {
			sysMenuPo.FrameSrc = in.Meta.FrameSrc
		}
		if in.Meta.Icon != nil && len(strings.TrimSpace(*in.Meta.Icon)) > 0 {
			sysMenuPo.Icon = *in.Meta.Icon
		}
		if in.Meta.CarryParam != nil {
			sysMenuPo.CarryParam = in.Meta.CarryParam
		}
		if in.Meta.HideChildrenInMenu != nil {
			sysMenuPo.HideChildrenInMenu = in.Meta.HideChildrenInMenu
		}
		if in.Meta.Affix != nil {
			sysMenuPo.Affix = in.Meta.Affix
		}
		if in.Meta.DynamicLevel != nil {
			uDynamicLevel := new(int32)
			*uDynamicLevel = int32(*in.Meta.DynamicLevel)
			sysMenuPo.DynamicLevel = uDynamicLevel
		}
		if in.Meta.RealPath != nil && len(strings.TrimSpace(*in.Meta.RealPath)) > 0 {
			sysMenuPo.RealPath = in.Meta.RealPath
		}
	}

	_, err := sysMenuRepo.WithContext(l.ctx).Where(sysMenuRepo.ID.Eq(int64(*in.Id))).Updates(sysMenuPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.UpdateSuccess}, nil
}
