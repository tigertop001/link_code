package logic

import (
	"context"
	"errors"
	"global-admin-common/gormutils"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/const/sql"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetDictionaryDetailListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetDictionaryDetailListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetDictionaryDetailListLogic {
	return &GetDictionaryDetailListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: dictionarydetail
func (l *GetDictionaryDetailListLogic) GetDictionaryDetailList(in *usercenter.DictionaryDetailListReq) (*usercenter.DictionaryDetailListResp, error) {

	sysDictionaryDetailRepo := query.SysDictionaryDetail
	var sysDictionaryDetailDo query.ISysDictionaryDetailDo
	if in.DictionaryId != nil {
		sysDictionaryDetailDo = sysDictionaryDetailRepo.WithContext(l.ctx).Where(sysDictionaryDetailRepo.DictionaryID.Eq(int64(*in.DictionaryId)))
	}
	if in.Key != nil && len(strings.TrimSpace(*in.Key)) > 0 {
		if sysDictionaryDetailDo != nil {
			sysDictionaryDetailDo = sysDictionaryDetailDo.WithContext(l.ctx).Where(sysDictionaryDetailRepo.Key.Like(gormutils.LikeExpPercentJoiner(*in.Key, sql.LIKE_BLURRY_PLACEHOLDER)))

		} else {
			return nil, errorxplus.DefaultGormError(l.Logger, errors.New("sysDictionaryDetailDo nil pointer"), in)
		}
	}

	if sysDictionaryDetailDo != nil {
		total, err := sysDictionaryDetailDo.Count()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		limit, offset := gormutils.PaginateLimitOffsetNum(int(in.Page), int(in.PageSize))
		result, err := sysDictionaryDetailDo.Offset(offset).Limit(limit).Order(sysDictionaryDetailRepo.ID.Asc()).Find()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		resp := &usercenter.DictionaryDetailListResp{}
		resp.Total = uint64(total)
		for _, v := range result {
			uId := new(uint64)
			*uId = uint64(v.ID)
			uStatus := new(uint32)
			*uStatus = uint32(*v.Status)
			uDictionaryId := new(uint64)
			*uDictionaryId = uint64(v.ID)
			uSort := new(uint32)
			*uSort = uint32(v.Sort)
			resp.Data = append(resp.Data, &usercenter.DictionaryDetailInfo{
				Id:           uId,
				CreatedAt:    pointy.GetPointer(v.CreatedAt.UnixMilli()),
				UpdatedAt:    pointy.GetPointer(v.UpdatedAt.UnixMilli()),
				Status:       uStatus,
				Title:        &v.Title,
				Key:          &v.Key,
				Value:        &v.Value,
				DictionaryId: uDictionaryId,
				Sort:         uSort,
			})
		}
		return resp, nil
	}

	return nil, errorxplus.DefaultGormError(l.Logger, errors.New("sysDictionaryDetailDo invalid param"), in)
}
