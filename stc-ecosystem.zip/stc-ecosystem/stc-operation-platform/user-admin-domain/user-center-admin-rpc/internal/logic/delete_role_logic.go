package logic

import (
	"context"
	"errors"
	"global-admin-common/admini18nconst"
	"global-admin-common/smops"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type DeleteRoleLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDeleteRoleLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteRoleLogic {
	return &DeleteRoleLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: role
func (l *DeleteRoleLogic) DeleteRole(in *usercenter.IDsReq) (*usercenter.BaseResp, error) {
	userRoleRepo := query.UserRole
	sysRoleRepo := query.SysRole
	sysUserRepo := query.SysUser
	iIds, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.Ids)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	results, err := userRoleRepo.WithContext(l.ctx).Select(userRoleRepo.UserID).Join(sysRoleRepo, sysRoleRepo.ID.EqCol(userRoleRepo.RoleID)).
		Where(sysRoleRepo.ID.In(iIds...)).Find()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	ids := make([]string, 0)
	for _, result := range results {
		ids = append(ids, result.UserID)
	}
	if len(ids) <= 0 {
		return nil, errorxplus.DefaultGormError(l.Logger, errors.New("ids len is zero"), in)
	}
	var count int64
	err = sysUserRepo.WithContext(l.ctx).Select(sysUserRepo.ID.Count()).
		Where(sysUserRepo.ID.In(ids...), sysUserRepo.DeletedAt.IsNull()).Scan(&count)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	if count != 0 {
		return nil, errorxplus.NewInvalidArgumentError("role.userExists")
	}
	_, err = sysRoleRepo.WithContext(l.ctx).Where(sysRoleRepo.ID.In(iIds...)).Delete()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.DeleteSuccess}, nil
}
