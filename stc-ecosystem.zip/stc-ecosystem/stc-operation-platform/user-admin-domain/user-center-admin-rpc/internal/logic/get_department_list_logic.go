package logic

import (
	"context"
	"errors"
	"global-admin-common/gormutils"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/const/sql"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetDepartmentListLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetDepartmentListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetDepartmentListLogic {
	return &GetDepartmentListLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: department
func (l *GetDepartmentListLogic) GetDepartmentList(in *usercenter.DepartmentListReq) (*usercenter.DepartmentListResp, error) {

	sysDepartmentRepo := query.SysDepartment
	var sysDepartmentDo query.ISysDepartmentDo
	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		safeName, _ := gormutils.Escape(*in.Name)
		sysDepartmentDo = sysDepartmentRepo.WithContext(l.ctx).Where(sysDepartmentRepo.Name.Like(gormutils.LikeExpPercentJoiner(safeName, sql.LIKE_BLURRY_PLACEHOLDER)))
	}
	if in.Leader != nil && len(strings.TrimSpace(*in.Leader)) > 0 {
		if sysDepartmentDo != nil {
			safeLeader, _ := gormutils.Escape(*in.Leader)
			sysDepartmentDo = sysDepartmentDo.WithContext(l.ctx).Where(sysDepartmentRepo.Leader.Like(gormutils.LikeExpPercentJoiner(safeLeader, sql.LIKE_BLURRY_PLACEHOLDER)))

		}
	}

	if sysDepartmentDo != nil {
		limit, offset := gormutils.PaginateLimitOffsetNum(int(in.Page), int(in.PageSize))
		results, err := sysDepartmentDo.Offset(offset).Limit(limit).Order(sysDepartmentRepo.ID.Asc()).Find()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		total, err := sysDepartmentDo.Count()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}

		resp := &usercenter.DepartmentListResp{}
		resp.Total = uint64(total)

		for _, v := range results {
			uId := new(uint64)
			*uId = uint64(v.ID)
			uSort := new(uint32)
			*uSort = uint32(v.Sort)
			uParentId := new(uint64)
			*uParentId = uint64(*v.ParentID)
			resp.Data = append(resp.Data, &usercenter.DepartmentInfo{
				Id:        uId,
				CreatedAt: pointy.GetPointer(v.CreatedAt.UnixMilli()),
				UpdatedAt: pointy.GetPointer(v.UpdatedAt.UnixMilli()),
				Status:    pointy.GetPointer(uint32(*v.Status)),
				Sort:      uSort,
				Name:      &v.Name,
				Ancestors: v.Ancestors,
				Leader:    v.Leader,
				Phone:     v.Phone,
				Email:     v.Email,
				Remark:    v.Remark,
				ParentId:  uParentId,
			})
		}
		return resp, nil
	}

	return nil, errorxplus.DefaultGormError(l.Logger, errors.New("args is empty"), in)
}
