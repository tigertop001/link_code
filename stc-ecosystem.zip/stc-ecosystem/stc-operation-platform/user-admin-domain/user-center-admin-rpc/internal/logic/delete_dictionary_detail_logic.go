package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/smops"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type DeleteDictionaryDetailLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewDeleteDictionaryDetailLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteDictionaryDetailLogic {
	return &DeleteDictionaryDetailLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: dictionarydetail
func (l *DeleteDictionaryDetailLogic) DeleteDictionaryDetail(in *usercenter.IDsReq) (*usercenter.BaseResp, error) {
	uIds, err := smops.PrimitiveTypesSliceNumConvert[uint64, int64](in.Ids)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	sysDictionaryDetailRepo := query.SysDictionaryDetail
	_, err = sysDictionaryDetailRepo.WithContext(l.ctx).Where(sysDictionaryDetailRepo.ID.In(uIds...)).Delete()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.DeleteSuccess}, nil
}
