package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	usercenter2 "user-admin-domain/user-grpc-admin-dependency/usercenter"

	"github.com/zeromicro/go-zero/core/logx"
	"user-admin-domain/user-center-admin-rpc/internal/svc"
)

type CreateDepartmentLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateDepartmentLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateDepartmentLogic {
	return &CreateDepartmentLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// Department management
func (l *CreateDepartmentLogic) CreateDepartment(in *usercenter2.DepartmentInfo) (*usercenter2.BaseIDResp, error) {

	sysDepartmentPo := &model.SysDepartment{}

	if in.Status != nil {
		// unsafe.Pointer() 指针转换
		hStatus := new(int32)
		*hStatus = int32(*in.Status)
		sysDepartmentPo.Status = hStatus
	}
	if in.Sort != nil {
		hSort := new(int32)
		*hSort = int32(*in.Sort)
		sysDepartmentPo.Sort = *hSort
	}
	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysDepartmentPo.Name = *in.Name
	}
	if in.Ancestors != nil && len(strings.TrimSpace(*in.Ancestors)) > 0 {
		sysDepartmentPo.Ancestors = in.Ancestors
	}

	if in.Leader != nil && len(strings.TrimSpace(*in.Leader)) > 0 {
		sysDepartmentPo.Leader = in.Leader
	}

	if in.Phone != nil && len(strings.TrimSpace(*in.Phone)) > 0 {
		sysDepartmentPo.Phone = in.Phone
	}

	if in.Email != nil && len(strings.TrimSpace(*in.Email)) > 0 {
		sysDepartmentPo.Email = in.Email
	}
	if in.Remark != nil && len(strings.TrimSpace(*in.Remark)) > 0 {
		sysDepartmentPo.Remark = in.Remark
	}
	if in.ParentId != nil {
		hParentId := new(int64)
		*hParentId = int64(*in.ParentId)
		sysDepartmentPo.ParentID = hParentId
	}

	sysDepartmentRepo := query.SysDepartment
	err := sysDepartmentRepo.WithContext(l.ctx).Create(sysDepartmentPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	return &usercenter2.BaseIDResp{
		Id:  uint64(sysDepartmentPo.ID),
		Msg: admini18nconst.CreateSuccess,
	}, nil
}
