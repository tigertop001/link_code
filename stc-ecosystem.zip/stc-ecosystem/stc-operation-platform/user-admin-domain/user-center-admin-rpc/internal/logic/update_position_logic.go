package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdatePositionLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdatePositionLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdatePositionLogic {
	return &UpdatePositionLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: position
func (l *UpdatePositionLogic) UpdatePosition(in *usercenter.PositionInfo) (*usercenter.BaseResp, error) {
	sysPositionPo := &model.SysPosition{}
	if in.Status != nil {
		uStatus := new(int32)
		*uStatus = int32(*in.Status)
		sysPositionPo.Status = uStatus
	}
	if in.Sort != nil {
		uSort := new(int32)
		*uSort = int32(*in.Sort)
		sysPositionPo.Status = uSort
	}
	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysPositionPo.Name = *in.Name
	}
	if in.Code != nil && len(strings.TrimSpace(*in.Code)) > 0 {
		sysPositionPo.Code = *in.Code
	}
	if in.Remark != nil && len(strings.TrimSpace(*in.Remark)) > 0 {
		sysPositionPo.Remark = in.Remark
	}

	sysPositionRepo := query.SysPosition
	_, err := sysPositionRepo.WithContext(l.ctx).Where(sysPositionRepo.ID.Eq(int64(*in.Id))).Updates(sysPositionPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	return &usercenter.BaseResp{Msg: admini18nconst.UpdateSuccess}, nil
}
