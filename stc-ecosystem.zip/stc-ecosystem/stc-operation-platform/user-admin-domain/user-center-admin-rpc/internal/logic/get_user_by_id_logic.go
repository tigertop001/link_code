package logic

import (
	"context"
	"github.com/elliotchance/pie/v2"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetUserByIdLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewGetUserByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetUserByIdLogic {
	return &GetUserByIdLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: user
func (l *GetUserByIdLogic) GetUserById(in *usercenter.UUIDReq) (*usercenter.UserInfo, error) {
	sysUserRepo := query.SysUser
	result, err := sysUserRepo.WithContext(l.ctx).Where(sysUserRepo.ID.Eq(in.Id)).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}

	var departmentName *string
	if result != nil && result.DepartmentID != nil {
		sysDepartmentRepo := query.SysDepartment
		sysDepartments, err := sysDepartmentRepo.WithContext(l.ctx).Where(sysDepartmentRepo.ID.Eq(*result.DepartmentID)).First()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}
		departmentName = &sysDepartments.Name
	}
	var sysRoles []*model.SysRole
	if result != nil && len(strings.TrimSpace(result.ID)) > 0 {
		sysRoleRepo := query.SysRole
		userRoleRepo := query.UserRole
		sysRoles, err = sysRoleRepo.WithContext(l.ctx).Select(sysRoleRepo.ALL, userRoleRepo.UserID).
			Join(userRoleRepo, userRoleRepo.RoleID.EqCol(sysRoleRepo.ID)).
			Where(userRoleRepo.UserID.In(result.ID)).Find()
		if err != nil {
			return nil, errorxplus.DefaultGormError(l.Logger, err, in)
		}

	}

	if result != nil {
		uStatus := new(uint32)
		*uStatus = uint32(*result.Status)
		uDepartmentId := new(uint64)
		*uDepartmentId = uint64(*result.DepartmentID)
		return &usercenter.UserInfo{
			Nickname:       &result.Nickname,
			Avatar:         result.Avatar,
			RoleIds:        GetRoleIds(sysRoles),
			RoleName:       GetRoleNames(sysRoles),
			Mobile:         result.Mobile,
			Email:          result.Email,
			Status:         uStatus,
			Id:             &result.ID,
			Username:       &result.Username,
			HomePath:       &result.HomePath,
			Password:       &result.Password,
			Description:    result.Description,
			DepartmentId:   uDepartmentId,
			DepartmentName: departmentName,
			CreatedAt:      pointy.GetPointer(result.CreatedAt.UnixMilli()),
			UpdatedAt:      pointy.GetPointer(result.UpdatedAt.UnixMilli()),
		}, nil
	}
	return nil, errorxplus.DefaultGormError(l.Logger, err, in)
}

func GetRoleNames(sysRoles []*model.SysRole) []string {

	if sysRoles == nil || len(sysRoles) <= 0 {
		return []string{}
	}
	return pie.Map(sysRoles, func(t *model.SysRole) string {
		return t.Name
	})
}

func GetRoleIds(sysRoles []*model.SysRole) []uint64 {
	if sysRoles == nil || len(sysRoles) <= 0 {
		return []uint64{}
	}
	return pie.Map(sysRoles, func(t *model.SysRole) uint64 {
		return uint64(t.ID)
	})
}
