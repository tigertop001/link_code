package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateTokenLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreateTokenLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateTokenLogic {
	return &CreateTokenLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// Token management
func (l *CreateTokenLogic) CreateToken(in *usercenter.TokenInfo) (*usercenter.BaseUUIDResp, error) {
	sysTokenPo := &model.SysToken{}
	if in.Status != nil {
		iStatus := new(int32)
		*iStatus = int32(*in.Status)
		sysTokenPo.Status = iStatus
	}
	if in.Id != nil && len(strings.TrimSpace(*in.Id)) != 0 {
		sysTokenPo.ID = *in.Id
	}
	if in.Uuid != nil && len(strings.TrimSpace(*in.Uuid)) != 0 {
		sysTokenPo.UUID = *in.Uuid
	}
	if in.Token != nil && len(strings.TrimSpace(*in.Token)) != 0 {
		sysTokenPo.Token = *in.Token
	}
	if in.Source != nil && len(strings.TrimSpace(*in.Source)) != 0 {
		sysTokenPo.Source = *in.Source
	}
	if in.Username != nil && len(strings.TrimSpace(*in.Username)) != 0 {
		sysTokenPo.Username = *in.Username
	}
	if in.ExpiredAt != nil {
		sysTokenPo.ExpiredAt = *pointy.GetTimeMilliPointer(in.ExpiredAt)
	}
	sysTokenRePo := query.SysToken
	err := sysTokenRePo.WithContext(l.ctx).Create(sysTokenPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseUUIDResp{Id: sysTokenPo.ID, Msg: admini18nconst.CreateSuccess}, nil
}
