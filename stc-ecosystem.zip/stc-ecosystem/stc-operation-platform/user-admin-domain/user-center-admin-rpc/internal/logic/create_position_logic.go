package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreatePositionLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewCreatePositionLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreatePositionLogic {
	return &CreatePositionLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// Position management
func (l *CreatePositionLogic) CreatePosition(in *usercenter.PositionInfo) (*usercenter.BaseIDResp, error) {
	sysPositionPo := &model.SysPosition{}
	if in.Status != nil {
		uStatus := new(int32)
		*uStatus = int32(*in.Status)
		sysPositionPo.Status = uStatus
	}
	if in.Sort != nil {
		sysPositionPo.Sort = int32(*in.Sort)
	}

	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysPositionPo.Name = *in.Name
	}
	if in.Code != nil && len(strings.TrimSpace(*in.Code)) > 0 {
		sysPositionPo.Code = *in.Code
	}
	if in.Remark != nil && len(strings.TrimSpace(*in.Remark)) > 0 {
		sysPositionPo.Remark = in.Remark
	}

	sysPositionRepo := query.SysPosition
	err := sysPositionRepo.WithContext(l.ctx).Create(sysPositionPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	return &usercenter.BaseIDResp{Id: uint64(sysPositionPo.ID), Msg: admini18nconst.CreateSuccess}, nil
}
