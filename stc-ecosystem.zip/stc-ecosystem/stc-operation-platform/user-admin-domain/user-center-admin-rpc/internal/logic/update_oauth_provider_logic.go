package logic

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-center-admin-rpc/internal/model"
	"user-admin-domain/user-center-admin-rpc/internal/query"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-center-admin-rpc/internal/svc"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateOauthProviderLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateOauthProviderLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateOauthProviderLogic {
	return &UpdateOauthProviderLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

// group: oauthprovider
func (l *UpdateOauthProviderLogic) UpdateOauthProvider(in *usercenter.OauthProviderInfo) (*usercenter.BaseResp, error) {
	sysOauthProviderPo := &model.SysOauthProvider{}

	if in.Name != nil && len(strings.TrimSpace(*in.Name)) > 0 {
		sysOauthProviderPo.Name = *in.Name
	}
	if in.ClientId != nil && len(strings.TrimSpace(*in.ClientId)) > 0 {
		sysOauthProviderPo.ClientID = *in.ClientId
	}
	if in.ClientSecret != nil && len(strings.TrimSpace(*in.ClientSecret)) > 0 {
		sysOauthProviderPo.ClientSecret = *in.ClientSecret
	}
	if in.RedirectUrl != nil && len(strings.TrimSpace(*in.RedirectUrl)) > 0 {
		sysOauthProviderPo.RedirectURL = *in.RedirectUrl
	}
	if in.Scopes != nil && len(strings.TrimSpace(*in.Scopes)) > 0 {
		sysOauthProviderPo.Scopes = *in.Scopes
	}
	if in.AuthUrl != nil && len(strings.TrimSpace(*in.AuthUrl)) > 0 {
		sysOauthProviderPo.AuthURL = *in.AuthUrl
	}
	if in.TokenUrl != nil && len(strings.TrimSpace(*in.TokenUrl)) > 0 {
		sysOauthProviderPo.TokenURL = *in.TokenUrl
	}
	if in.AuthStyle != nil {
		sysOauthProviderPo.AuthStyle = int64(*in.AuthStyle)
	}
	if in.InfoUrl != nil && len(strings.TrimSpace(*in.InfoUrl)) > 0 {
		sysOauthProviderPo.InfoURL = *in.InfoUrl
	}
	sysOauthProviderRepo := query.SysOauthProvider
	_, err := sysOauthProviderRepo.WithContext(l.ctx).Where(sysOauthProviderRepo.ID.Eq(int64(*in.Id))).Updates(sysOauthProviderPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, in)
	}
	if _, ok := providerConfig[*in.Name]; ok {
		delete(providerConfig, *in.Name)
	}
	return &usercenter.BaseResp{Msg: admini18nconst.UpdateSuccess}, nil
}
