package tasklog

import (
	"net/http"

	"github.com/zeromicro/go-zero/rest/httpx"
	"user-admin-domain/user-domain-app-bff/internal/logic/tasklog"
	"user-admin-domain/user-domain-app-bff/internal/svc"
	"user-admin-domain/user-domain-app-bff/internal/types"
)

func CreateTaskLogHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req types.TaskLogInfo
		if err := httpx.Parse(r, &req); err != nil {
			httpx.ErrorCtx(r.Context(), w, err)
			return
		}

		l := tasklog.NewCreateTaskLogLogic(r.Context(), svcCtx)
		resp, err := l.CreateTaskLog(&req)
		if err != nil {
			err = svcCtx.Trans.TransError(r.Context(), err)
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
