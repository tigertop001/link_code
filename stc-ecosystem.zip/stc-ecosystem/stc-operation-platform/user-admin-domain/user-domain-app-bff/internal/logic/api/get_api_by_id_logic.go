package api

import (
	"context"
	"global-admin-common/admini18nconst"
	"user-admin-domain/user-grpc-admin-dependency/usercenter_client"

	"user-admin-domain/user-domain-app-bff/internal/svc"
	"user-admin-domain/user-domain-app-bff/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetApiByIdLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetApiByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetApiByIdLogic {
	return &GetApiByIdLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetApiByIdLogic) GetApiById(req *types.IDReq) (resp *types.ApiInfoResp, err error) {
	data, err := l.svcCtx.UserCenterRpc.GetApiById(l.ctx, &usercenter_client.IDReq{Id: req.Id})
	if err != nil {
		return nil, err
	}
	return &types.ApiInfoResp{
		BaseDataInfo: types.BaseDataInfo{
			Code: 0,
			Msg:  l.svcCtx.Trans.Trans(l.ctx, admini18nconst.Success),
		},
		Data: types.ApiInfo{
			BaseIDInfo: types.BaseIDInfo{
				Id:        data.Id,
				CreatedAt: data.CreatedAt,
				UpdatedAt: data.UpdatedAt,
			},
			Trans:       l.svcCtx.Trans.Trans(l.ctx, *data.Description),
			Path:        data.Path,
			Description: data.Description,
			Group:       data.ApiGroup,
			Method:      data.Method,
			IsRequired:  data.IsRequired,
			ServiceName: data.ServiceName,
		},
	}, nil
}
