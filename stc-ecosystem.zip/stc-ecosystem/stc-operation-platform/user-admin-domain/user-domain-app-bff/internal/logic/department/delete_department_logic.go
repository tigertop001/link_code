package department

import (
	"context"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-domain-app-bff/internal/svc"
	"user-admin-domain/user-domain-app-bff/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type DeleteDepartmentLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewDeleteDepartmentLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteDepartmentLogic {
	return &DeleteDepartmentLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *DeleteDepartmentLogic) DeleteDepartment(req *types.IDsReq) (resp *types.BaseMsgResp, err error) {
	result, err := l.svcCtx.UserCenterRpc.DeleteDepartment(l.ctx, &usercenter.IDsReq{
		Ids: req.Ids,
	})
	if err != nil {
		return nil, err
	}

	return &types.BaseMsgResp{Msg: l.svcCtx.Trans.Trans(l.ctx, result.Msg)}, nil
}
