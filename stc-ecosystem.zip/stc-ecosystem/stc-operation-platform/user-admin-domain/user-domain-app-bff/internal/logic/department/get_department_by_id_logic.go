package department

import (
	"context"
	"global-admin-common/admini18nconst"

	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-domain-app-bff/internal/svc"
	"user-admin-domain/user-domain-app-bff/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetDepartmentByIdLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetDepartmentByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetDepartmentByIdLogic {
	return &GetDepartmentByIdLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetDepartmentByIdLogic) GetDepartmentById(req *types.IDReq) (resp *types.DepartmentInfoResp, err error) {
	data, err := l.svcCtx.UserCenterRpc.GetDepartmentById(l.ctx, &usercenter.IDReq{Id: req.Id})
	if err != nil {
		return nil, err
	}

	return &types.DepartmentInfoResp{
		BaseDataInfo: types.BaseDataInfo{
			Code: 0,
			Msg:  l.svcCtx.Trans.Trans(l.ctx, admini18nconst.Success),
		},
		Data: types.DepartmentInfo{
			BaseIDInfo: types.BaseIDInfo{
				Id:        data.Id,
				CreatedAt: data.CreatedAt,
				UpdatedAt: data.UpdatedAt,
			},
			Status:    data.Status,
			Sort:      data.Sort,
			Name:      data.Name,
			Ancestors: data.Ancestors,
			Leader:    data.Leader,
			Phone:     data.Phone,
			Email:     data.Email,
			Remark:    data.Remark,
			ParentId:  data.ParentId,
		},
	}, nil
}
