package authority

import (
	"context"
	"global-admin-common/admini18nconst"

	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-grpc-admin-dependency/usercenter"

	"user-admin-domain/user-domain-app-bff/internal/svc"
	"user-admin-domain/user-domain-app-bff/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateOrUpdateApiAuthorityLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCreateOrUpdateApiAuthorityLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateOrUpdateApiAuthorityLogic {
	return &CreateOrUpdateApiAuthorityLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *CreateOrUpdateApiAuthorityLogic) CreateOrUpdateApiAuthority(req *types.CreateOrUpdateApiAuthorityReq) (resp *types.BaseMsgResp, err error) {

	data, err := l.svcCtx.UserCenterRpc.GetRoleById(l.ctx, &usercenter.IDReq{Id: req.RoleId})
	if err != nil {
		return nil, err
	}
	// clear old policies
	var oldPolicies [][]string
	oldPolicies, err = l.svcCtx.Casbin.GetFilteredPolicy(0, *data.Code)
	if err != nil {
		logx.Error("failed to get old Casbin policy", logx.Field("detail", err))
		return nil, errorxplus.NewInternalError(err.Error())
	}

	if len(oldPolicies) != 0 {
		removeResult, err := l.svcCtx.Casbin.RemoveFilteredPolicy(0, *data.Code)
		if err != nil {
			l.Logger.Errorw("failed to remove roles policy", logx.Field("roleCode", data.Code), logx.Field("detail", err.Error()))
			return nil, errorxplus.NewInvalidArgumentError(err.Error())
		}
		if !removeResult {
			return nil, errorxplus.NewInvalidArgumentError("casbin.removeFailed")
		}
	}
	// add new policies
	var policies [][]string
	for _, v := range req.Data {
		policies = append(policies, []string{*data.Code, v.Path, v.Method})
	}
	addResult, err := l.svcCtx.Casbin.AddPolicies(policies)
	if err != nil {
		return nil, errorxplus.NewInvalidArgumentError("casbin.addFailed")
	}
	if addResult {
		return &types.BaseMsgResp{Msg: l.svcCtx.Trans.Trans(l.ctx, admini18nconst.UpdateSuccess)}, nil
	} else {
		return &types.BaseMsgResp{Msg: l.svcCtx.Trans.Trans(l.ctx, admini18nconst.UpdateFailed)}, nil
	}
}
