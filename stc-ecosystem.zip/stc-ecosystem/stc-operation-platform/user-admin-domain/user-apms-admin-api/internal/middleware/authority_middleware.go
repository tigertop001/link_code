package middleware

import (
	"context"
	"errors"
	"github.com/casbin/casbin/v2"
	"github.com/redis/go-redis/v9"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/rest/httpx"
	"global-admin-common/config"
	"global-admin-common/enum/errorcode"
	"global-admin-common/i18n"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/jwt"
	"net/http"
	"strings"
)

type AuthorityMiddleware struct {
	Cbn   *casbin.Enforcer
	Rds   redis.UniversalClient
	Trans *i18n.Translator
}

func NewAuthorityMiddleware(cbn *casbin.Enforcer, rds redis.UniversalClient, trans *i18n.Translator) *AuthorityMiddleware {
	return &AuthorityMiddleware{
		Cbn:   cbn,
		Rds:   rds,
		Trans: trans,
	}
}

func (m *AuthorityMiddleware) Handle(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {

		obj := r.URL.Path

		act := r.Method

		roleIdFromCtx := r.Context().Value("roleId")

		if roleIdFromCtx == nil || len(strings.TrimSpace(roleIdFromCtx.(string))) == 0 {
			logx.Errorw("request absent param roleId", logx.Field("detail", "absent roleId"))
			httpx.Error(w, errorxplus.NewApiErrorWithoutMsg(http.StatusNotAcceptable))
			return
		}
		roleIds := roleIdFromCtx.(string)

		jwtResult, err := m.Rds.Get(context.Background(), config.RedisTokenPrefix+jwt.StripBearerPrefixFromToken(r.Header.Get("Authorization"))).Result()

		if err != nil && !errors.Is(err, redis.Nil) {
			logx.Errorw("redis error in jwt", logx.Field("detail", err.Error()))
			httpx.Error(w, errorxplus.NewApiError(http.StatusInternalServerError, err.Error()))
			return
		}

		if jwtResult == "1" {
			logx.Errorw("token in blacklist", logx.Field("detail", r.Header.Get("Authorization")))
			httpx.Error(w, errorxplus.NewApiErrorWithoutMsg(http.StatusUnauthorized))
			return
		}

		result := batchCheck(m.Cbn, roleIds, act, obj)

		if result {
			var userId string
			if r.Context().Value("userId") == nil {
				userId = ""
			} else {
				userId = r.Context().Value("userId").(string)
			}
			logx.Infow("HTTP/HTTPS Request", logx.Field("UUID", userId), logx.Field("path", obj), logx.Field("method", act))
			next(w, r)
			return
		} else {
			logx.Errorw("the role is not permitted to access the API", logx.Field("roleId", roleIds),
				logx.Field("path", obj), logx.Field("method", act))
			httpx.Error(w, errorxplus.NewCodeError(errorcode.PermissionDenied, m.Trans.Trans(
				context.WithValue(context.Background(), "lang", r.Header.Get("Accept-Language")), "common.permissionDeny")))
			return
		}

	}
}

func batchCheck(cbn *casbin.Enforcer, roleIds, act, obj string) bool {

	var checkReq [][]any

	for _, v := range strings.Split(roleIds, ",") {
		checkReq = append(checkReq, []any{v, obj, act})
	}

	result, err := cbn.BatchEnforce(checkReq)

	if err != nil {
		logx.Errorw("Casbin enforce error", logx.Field("detail", err.Error()))
		return false
	}

	for _, v := range result {
		if v {
			return true
		}
	}
	return false
}
