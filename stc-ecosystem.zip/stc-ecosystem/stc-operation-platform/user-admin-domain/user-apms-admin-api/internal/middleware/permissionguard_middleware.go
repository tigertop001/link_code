package middleware

import (
	"context"
	"errors"
	"fmt"
	"github.com/redis/go-redis/v9"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/rest/httpx"
	"global-admin-common/config"
	"global-admin-common/utils/errorxplus"
	"net/http"
	"strconv"
	"strings"
)

type PermissionGuardMiddleware struct {
	Redis       redis.UniversalClient
	ServiceName string
}

func NewPermissionGuardMiddleware(r redis.UniversalClient, serviceName string) *PermissionGuardMiddleware {
	return &PermissionGuardMiddleware{
		Redis:       r,
		ServiceName: serviceName,
	}
}

func (m *PermissionGuardMiddleware) Handle(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		path := r.URL.Path
		method := r.Method
		var userId string
		if r.Context().Value("userId") == nil {
			httpx.Error(w, errorxplus.NewApiUnauthorizedError("userid param absent"))
			logx.Errorw("userid param absent", logx.Field("path", path), logx.Field("method", method))
		} else {
			userId = r.Context().Value("userId").(string)
		}
		redisKey := fmt.Sprintf("%s%s:%s%s:%s", config.RedisApiPermissionCountPrefix, strings.ToLower(m.ServiceName), userId, method, path)

		data, err := m.Redis.Get(context.Background(), redisKey).Result()

		if err != nil {
			if errors.Is(err, redis.Nil) {
				httpx.Error(w, errorxplus.NewApiUnauthorizedError("Your balance is not enough | 您的余额已用完"))
				logx.Errorw("user's balance is not enough", logx.Field("userId", userId), logx.Field("path", path), logx.Field("method", method))
			} else {
				httpx.Error(w, errorxplus.NewApiInternalError("redis error"))
				logx.Errorw("redis error", logx.Field("detail", err.Error()))
			}
			return
		}

		balance, err := strconv.Atoi(data)

		if err != nil {
			httpx.Error(w, errorxplus.NewApiInternalError("convert error"))
			logx.Errorw("balance convert failed", logx.Field("detail", err.Error()))
			return
		}

		if balance <= 0 {
			httpx.Error(w, errorxplus.NewApiUnauthorizedError("Your balance is not enough | 您的余额已用完"))
			logx.Error("user's balance is not enough", logx.Field("userId", userId), logx.Field("path", path), logx.Field("method", method))
			return
		} else {
			err := m.Redis.Decr(context.Background(), redisKey).Err()
			if err != nil {
				httpx.Error(w, errorxplus.NewApiInternalError("redis error"))
				logx.Errorw("redis error", logx.Field("detail", err.Error()))
				return
			}
			next(w, r)
		}

	}
}
