package operationlog

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"user-admin-domain/user-apms-admin-api/internal/query"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type DeleteOperationLogLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewDeleteOperationLogLogic(ctx context.Context, svcCtx *svc.ServiceContext) *DeleteOperationLogLogic {
	return &DeleteOperationLogLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *DeleteOperationLogLogic) DeleteOperationLog(req *types.UUIDsReq) (resp *types.BaseMsgResp, err error) {
	apmsOperationLogRepo := query.ApmsOperationLog
	_, err = apmsOperationLogRepo.WithContext(l.ctx).Where(apmsOperationLogRepo.ID.In(req.Ids...)).Delete()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}

	return &types.BaseMsgResp{Msg: l.svcCtx.Trans.Trans(l.ctx, admini18nconst.DeleteSuccess)}, nil
}
