package operationlog

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"strings"
	"user-admin-domain/user-apms-admin-api/internal/model"
	"user-admin-domain/user-apms-admin-api/internal/query"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateOperationLogLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewUpdateOperationLogLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateOperationLogLogic {
	return &UpdateOperationLogLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *UpdateOperationLogLogic) UpdateOperationLog(req *types.OperationLogInfo) (resp *types.BaseMsgResp, err error) {

	apmsOperationLogOp := new(model.ApmsOperationLog)

	if req.UserId != nil && len(strings.TrimSpace(*req.UserId)) > 0 {
		apmsOperationLogOp.UserID = *req.UserId
	}

	if req.OperatorId != nil && len(strings.TrimSpace(*req.OperatorId)) > 0 {
		apmsOperationLogOp.OperatorID = *req.OperatorId
	}
	if req.Change != nil {
		apmsOperationLogOp.Change = int64(*req.Change)
	}
	if req.Remark != nil && len(strings.TrimSpace(*req.Remark)) > 0 {
		apmsOperationLogOp.Remark = req.Remark
	}

	if req.PermissionId != nil && len(strings.TrimSpace(*req.PermissionId)) > 0 {
		apmsOperationLogOp.PermissionID = *req.PermissionId
	}

	apmsOperationLogRepo := query.ApmsOperationLog
	_, err = apmsOperationLogRepo.WithContext(l.ctx).Where(apmsOperationLogRepo.ID.Eq(*req.Id)).Updates(apmsOperationLogOp)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}
	return &types.BaseMsgResp{Msg: l.svcCtx.Trans.Trans(l.ctx, admini18nconst.UpdateSuccess)}, nil
}
