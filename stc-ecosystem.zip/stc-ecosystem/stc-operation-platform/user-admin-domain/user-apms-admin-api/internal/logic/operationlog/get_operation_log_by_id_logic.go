package operationlog

import (
	"context"
	"global-admin-common/admini18nconst"
	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"user-admin-domain/user-apms-admin-api/internal/query"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetOperationLogByIdLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetOperationLogByIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetOperationLogByIdLogic {
	return &GetOperationLogByIdLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetOperationLogByIdLogic) GetOperationLogById(req *types.UUIDReq) (resp *types.OperationLogInfoResp, err error) {
	apmsOperationLogRepo := query.ApmsOperationLog
	data, err := apmsOperationLogRepo.WithContext(l.ctx).Where(apmsOperationLogRepo.ID.Eq(req.Id)).First()
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}
	changePoint := new(int)
	changeInt := int(data.Change)
	changePoint = &changeInt
	return &types.OperationLogInfoResp{
		BaseDataInfo: types.BaseDataInfo{
			Code: 0,
			Msg:  l.svcCtx.Trans.Trans(l.ctx, admini18nconst.Success),
		},
		Data: types.OperationLogInfo{
			BaseUUIDInfo: types.BaseUUIDInfo{
				Id:        pointy.GetPointer(data.ID),
				CreatedAt: pointy.GetPointer(data.CreatedAt.UnixMilli()),
				UpdatedAt: pointy.GetPointer(data.UpdatedAt.UnixMilli()),
			},
			UserId:       pointy.GetPointer(data.UserID),
			OperatorId:   pointy.GetPointer(data.OperatorID),
			PermissionId: pointy.GetPointer(data.PermissionID),
			Change:       changePoint,
			Remark:       data.Remark,
		},
	}, nil
}
