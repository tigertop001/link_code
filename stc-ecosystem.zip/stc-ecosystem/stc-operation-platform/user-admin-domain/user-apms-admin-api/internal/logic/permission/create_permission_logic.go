package permission

import (
	"context"
	"global-admin-common/admini18nconst"

	"global-admin-common/utils/errorxplus"
	"global-admin-common/utils/pointy"
	"strings"
	"time"
	"user-admin-domain/user-apms-admin-api/internal/logic/operationlog"
	"user-admin-domain/user-apms-admin-api/internal/model"
	"user-admin-domain/user-apms-admin-api/internal/query"
	"user-admin-domain/user-apms-admin-api/internal/utils/permdata"

	"user-admin-domain/user-apms-admin-api/internal/svc"
	"user-admin-domain/user-apms-admin-api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreatePermissionLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCreatePermissionLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreatePermissionLogic {
	return &CreatePermissionLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *CreatePermissionLogic) CreatePermission(req *types.PermissionInfo) (resp *types.BaseMsgResp, err error) {

	apmsPermissionPo := new(model.ApmsPermission)

	if req.State != nil {
		apmsPermissionPo.State = req.State
	}
	if req.UserId != nil && len(strings.TrimSpace(*req.UserId)) > 0 {
		apmsPermissionPo.UserID = *req.UserId
	}
	if req.Method != nil && len(strings.TrimSpace(*req.Method)) > 0 {
		apmsPermissionPo.Method = *req.Method
	}

	if req.Path != nil && len(strings.TrimSpace(*req.Path)) > 0 {
		apmsPermissionPo.Path = *req.Path
	}
	if req.Balance != nil {
		apmsPermissionPo.Balance = int64(*req.Balance)
	}
	if req.ExpiredAt != nil {

		apmsPermissionPo.ExpiredAt = time.UnixMilli(*req.ExpiredAt)
	}
	if req.ServiceName != nil && len(strings.TrimSpace(*req.ServiceName)) > 0 {
		apmsPermissionPo.ServiceName = *req.ServiceName
	}

	apmsPermissionRepo := query.ApmsPermission
	err = apmsPermissionRepo.WithContext(l.ctx).Create(apmsPermissionPo)
	if err != nil {
		return nil, errorxplus.DefaultGormError(l.Logger, err, req)
	}

	// update redis
	err = permdata.SetUserApiBalance(l.svcCtx.Redis, *req.UserId, *req.Method, *req.Path, *req.ServiceName, *req.Balance)
	if err != nil {
		return nil, err
	}

	// add log
	operatorId := l.ctx.Value("userId").(string)

	_, err = operationlog.NewCreateOperationLogLogic(l.ctx, l.svcCtx).CreateOperationLog(&types.OperationLogInfo{
		UserId:       req.UserId,
		OperatorId:   &operatorId,
		PermissionId: pointy.GetPointer(apmsPermissionPo.ID),
		Change:       pointy.GetPointer(int(*req.Balance)),
		Remark:       pointy.GetPointer("Create"),
	})

	if err != nil {
		return nil, err
	}

	return &types.BaseMsgResp{Msg: l.svcCtx.Trans.Trans(l.ctx, admini18nconst.CreateSuccess)}, nil
}
