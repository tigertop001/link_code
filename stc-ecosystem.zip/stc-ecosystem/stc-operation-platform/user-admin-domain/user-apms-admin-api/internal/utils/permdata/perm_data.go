package permdata

import (
	"context"
	"fmt"
	"github.com/redis/go-redis/v9"
	"global-admin-common/config"
	"strconv"
	"strings"
)

func GetUserApiBalance(r redis.UniversalClient, userId, method, path, serviceName string) (int, error) {
	data, err := r.Get(context.Background(), GetRedisKey(userId, method, path, serviceName)).Result()
	if err != nil {
		return 0, err
	}
	balance, err := strconv.Atoi(data)
	if err != nil {
		return 0, err
	}
	return balance, err
}

func SetUserApiBalance(r redis.UniversalClient, userId, method, path, serviceName string, balance uint64) error {
	err := r.Set(context.Background(), GetRedisKey(userId, method, path, serviceName), balance, 0).Err()
	return err
}

func DelUserApiBalance(r redis.UniversalClient, userId, method, path, serviceName string) error {
	err := r.Del(context.Background(), GetRedisKey(userId, method, path, serviceName)).Err()
	return err
}

func GetRedisKey(userId, method, path, serviceName string) string {
	return fmt.Sprintf("%s%s:%s:%s:%s", config.RedisApiPermissionCountPrefix, strings.ToLower(serviceName), userId, method, path)
}
