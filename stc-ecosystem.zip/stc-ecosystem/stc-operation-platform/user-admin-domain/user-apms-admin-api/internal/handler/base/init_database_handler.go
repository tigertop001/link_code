package base

import (
	"net/http"

	"github.com/zeromicro/go-zero/rest/httpx"
	"user-admin-domain/user-apms-admin-api/internal/logic/base"
	"user-admin-domain/user-apms-admin-api/internal/svc"
)

func InitDatabaseHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		l := base.NewInitDatabaseLogic(r.Context(), svcCtx)
		resp, err := l.InitDatabase()
		if err != nil {
			err = svcCtx.Trans.TransError(r.Context(), err)
			httpx.ErrorCtx(r.Context(), w, err)
		} else {
			httpx.OkJsonCtx(r.Context(), w, resp)
		}
	}
}
