package svc

import (
	"github.com/casbin/casbin/v2"
	"github.com/redis/go-redis/v9"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/rest"
	"github.com/zeromicro/go-zero/zrpc"
	"global-admin-common/i18n"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"time"
	"user-admin-domain/user-apms-admin-api/internal/config"
	i18n2 "user-admin-domain/user-apms-admin-api/internal/i18n"
	"user-admin-domain/user-apms-admin-api/internal/middleware"
	"user-admin-domain/user-apms-admin-api/internal/query"
	userCenterClient "user-admin-domain/user-grpc-admin-dependency/usercenter_client"
)

type ServiceContext struct {
	Config          config.Config
	Authority       rest.Middleware
	PermissionGuard rest.Middleware
	Casbin          *casbin.Enforcer
	DB              *gorm.DB
	Trans           *i18n.Translator
	UserCenterRpc   userCenterClient.Usercenter
	Redis           redis.UniversalClient
}

func NewServiceContext(c config.Config) *ServiceContext {

	rds := c.RedisConf.MustNewUniversalRedis()

	cbn := c.CasbinConf.MustNewCasbinWithOriginalRedisWatcher(c.CasbinDatabaseConf.Type, c.CasbinDatabaseConf.GetDSN(), c.RedisConf)

	trans := i18n.NewTranslator(i18n2.LocaleFS)

	DB, err := gorm.Open(mysql.Open(c.DatabaseConf.Datasource), &gorm.Config{
		SkipDefaultTransaction: true,
		PrepareStmt:            true,
		Logger:                 settingLogConfig(),
	})
	logx.Must(err)
	query.SetDefault(DB)

	return &ServiceContext{
		Config:          c,
		Authority:       middleware.NewAuthorityMiddleware(cbn, rds, trans).Handle,
		PermissionGuard: middleware.NewPermissionGuardMiddleware(rds, c.ProjectConf.ServiceName).Handle,
		Trans:           trans,
		UserCenterRpc:   userCenterClient.NewUsercenter(zrpc.MustNewClient(c.UserCenterRpc)),
		Redis:           rds,
		DB:              DB,
	}
}

type Writer struct{}

func (w Writer) Printf(format string, args ...interface{}) {
	logx.Infof(format)
}
func settingLogConfig() logger.Interface {
	newLogger := logger.New(Writer{}, logger.Config{
		SlowThreshold:             200 * time.Millisecond, // 慢SQL的阈值
		LogLevel:                  logger.Info,            // 日志级别
		IgnoreRecordNotFoundError: true,                   // 忽略ErrRecordNotFound error for logger
		Colorful:                  true,                   // 禁用颜色
	})
	return newLogger
}
