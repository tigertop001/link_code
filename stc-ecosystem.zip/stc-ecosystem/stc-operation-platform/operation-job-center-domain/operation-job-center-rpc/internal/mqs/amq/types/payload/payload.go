package payload

type HelloWorldPayload struct {
	Name string `json:"name"`
}
