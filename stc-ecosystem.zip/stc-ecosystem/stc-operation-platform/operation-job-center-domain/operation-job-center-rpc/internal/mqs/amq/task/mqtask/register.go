package mqtask

import (
	"github.com/hibiken/asynq"
	"operation-job-center-domain/operation-job-center-rpc/internal/mqs/amq/handler/amq/base"
	"operation-job-center-domain/operation-job-center-rpc/internal/mqs/amq/types/pattern"
)

func (m *MQTask) Register() {
	mux := asynq.NewServeMux()

	mux.Handle(pattern.RecordHelloWorld, base.NewHelloWorldHandler(m.svcCtx))
	m.mux = mux
}
