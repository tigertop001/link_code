package periodicconfig

import (
	"fmt"
	"github.com/hibiken/asynq"
	"github.com/zeromicro/go-zero/core/logx"
	"global-admin-common/enum/common"
	"gorm.io/gorm"
	"operation-job-center-domain/operation-job-center-rpc/internal/model"
)

type GormConfProvider struct {
	DB *gorm.DB
}

func NewGormConfProvider(db *gorm.DB) *GormConfProvider {
	return &GormConfProvider{
		DB: db,
	}
}

func (g *GormConfProvider) GetConfigs() ([]*asynq.PeriodicTaskConfig, error) {
	var taskConfigs []model.SysTask
	err := g.DB.Find(&taskConfigs, "status = ?", common.StatusNormal).Error
	if err != nil {
		fmt.Printf("database error: %s, make sure the database confmgr is correct and database has been initialized \n", err.Error())
		logx.Errorw("database error", logx.Field("detail", err.Error()),
			logx.Field("recommend", "you maybe need to  initialize the database"))
		return nil, nil
	}

	var result []*asynq.PeriodicTaskConfig
	for _, v := range taskConfigs {
		result = append(result, &asynq.PeriodicTaskConfig{
			Cronspec: v.CronExpression,
			Task:     asynq.NewTask(v.Pattern, []byte(v.Payload)),
			Opts:     nil,
		})
	}
	return result, nil
}
