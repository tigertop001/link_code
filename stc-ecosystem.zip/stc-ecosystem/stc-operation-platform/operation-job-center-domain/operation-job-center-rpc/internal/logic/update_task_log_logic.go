package logic

import (
	"context"

	"operation-job-center-domain/operation-job-center-rpc/internal/svc"
	"operation-job-center-domain/operation-job-center-rpc/jobcenter"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateTaskLogLogic struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func NewUpdateTaskLogLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateTaskLogLogic {
	return &UpdateTaskLogLogic{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

func (l *UpdateTaskLogLogic) UpdateTaskLog(in *jobcenter.TaskLogInfo) (*jobcenter.BaseResp, error) {
	// todo: add your logic here and delete this line

	return &jobcenter.BaseResp{}, nil
}
