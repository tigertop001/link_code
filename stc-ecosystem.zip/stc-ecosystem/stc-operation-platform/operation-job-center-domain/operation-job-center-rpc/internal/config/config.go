package config

import (
	"github.com/zeromicro/go-zero/zrpc"
	"global-admin-common/config"
	"global-admin-common/plugins/mq/asynq"
)

type Config struct {
	zrpc.RpcServerConf
	RedisConf    config.RedisConf
	AsynqConf    asynq.AsynqConf
	TaskConf     TaskConf
	DatabaseConf struct {
		Datasource string
	}
}

type TaskConf struct {
	EnableScheduledTask bool `json:",default=true"`
	EnableDPTask        bool `json:",default=true"`
}
