package main

import (
	"flag"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"operation-job-center-domain/operation-job-center-rpc/internal/mqs/amq/task/dynamicperiodictask"
	"operation-job-center-domain/operation-job-center-rpc/internal/mqs/amq/task/mqtask"
	"operation-job-center-domain/operation-job-center-rpc/internal/mqs/amq/task/scheduletask"

	"operation-job-center-domain/operation-job-center-rpc/internal/config"
	"operation-job-center-domain/operation-job-center-rpc/internal/server"
	"operation-job-center-domain/operation-job-center-rpc/internal/svc"
	"operation-job-center-domain/operation-job-center-rpc/jobcenter"

	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/core/service"
	"github.com/zeromicro/go-zero/zrpc"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

var configFile = flag.String("f", "etc/conf.yaml", "the config filemgr")

func main() {
	flag.Parse()

	var c config.Config
	conf.MustLoad(*configFile, &c, conf.UseEnv())
	ctx := svc.NewServiceContext(c)

	logx.MustSetup(logx.LogConf{
		Stat: false,
	})
	s := zrpc.MustNewServer(c.RpcServerConf, func(grpcServer *grpc.Server) {
		jobcenter.RegisterJobcenterServer(grpcServer, server.NewJobcenterServer(ctx))

		if c.Mode == service.DevMode || c.Mode == service.TestMode {
			reflection.Register(grpcServer)
		}
	})

	serviceGroup := service.NewServiceGroup()
	defer func() {
		serviceGroup.Stop()
		logx.Close()
	}()
	serviceGroup.Add(s)
	serviceGroup.Add(mqtask.NewMQTask(ctx))
	if c.TaskConf.EnableDPTask {
		serviceGroup.Add(dynamicperiodictask.NewDPTask(ctx))
	}
	if c.TaskConf.EnableScheduledTask {
		serviceGroup.Add(scheduletask.NewSchedulerTask(ctx))
	}

	fmt.Printf("Starting rpc server at %s...\n", c.ListenOn)
	serviceGroup.Start()
}
